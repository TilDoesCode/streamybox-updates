package dev.streamybox.design

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.roundToInt

object SharedState {
    private fun authorities(context: Context): List<String> {
        val home = context.packageManager.resolveActivity(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        return (listOfNotNull(home?.takeIf { it.startsWith("dev.streamybox.launcher") }) + listOf("dev.streamybox.launcher.debug", "dev.streamybox.launcher")).distinct().map { "$it.state" }
    }
    fun read(context: Context): Bundle = authorities(context).firstNotNullOfOrNull { authority ->
        runCatching { context.contentResolver.call(Uri.parse("content://$authority"), "read", null, null) }.getOrNull()
    } ?: Bundle()
    fun write(context: Context, method: String, value: String) {
        val result = authorities(context).firstNotNullOfOrNull { authority ->
            runCatching { context.contentResolver.call(Uri.parse("content://$authority"), method, value, null) }.getOrNull()
        }
        check(result?.getBoolean("ok") == true)
    }
}

fun TextView.setTextIfChanged(value: String) { if (text.toString() != value) text = value }

data class FocusStyle(val fill: Int, val stroke: Int?, val focusFill: Int, val radii: FloatArray, val zoom: Float, val ring: Int? = null, val ringWidth: Float = 1.5f, val lift: Float = 0f)

object Fonts {
    private val cache = HashMap<String, Typeface>()
    fun get(context: Context, weight: Int, display: Boolean = false): Typeface = cache.getOrPut("$weight/$display") {
        runCatching { Typeface.Builder(context.assets, "fonts/Inter.ttf").setFontVariationSettings("'wght' $weight, 'opsz' ${if (display) 32 else 16}").setWeight(weight).build() }
            .getOrNull() ?: Typeface.create(Typeface.SANS_SERIF, weight, false)
    }
}

class TvDesign(val context: Context, val light: Boolean = false, val scale: Float = 1f) {
    companion object {
        const val RADIUS_S = 8f; const val RADIUS_M = 14f; const val RADIUS_L = 20f; const val RADIUS_XL = 26f; const val PILL = 999f
        const val SPACE_XS = 4f; const val SPACE_S = 8f; const val SPACE_M = 12f; const val SPACE_L = 16f; const val SPACE_XL = 24f; const val SPACE_XXL = 32f; const val SPACE_XXXL = 48f
        const val TYPE_DISPLAY = 38f; const val TYPE_H1 = 28f; const val TYPE_H2 = 20f; const val TYPE_TITLE = 16f; const val TYPE_BODY = 14f; const val TYPE_CAPTION = 12f; const val TYPE_EYEBROW = 11f
        const val FOCUS_MS = Motion.FOCUS
    }
    enum class Trail { NONE, CHEVRON, CHIP, ON, OFF }
    private fun pick(dark: String, bright: String) = Color.parseColor(if (light) bright else dark)
    val background = pick("#07090E", "#EEF1F5")
    val backgroundTop = pick("#0E131C", "#F9FAFC")
    val surface = pick("#10141C", "#FFFFFF")
    val surfaceHigh = pick("#1A2030", "#F1F3F7")
    val raised = pick("#11161F", "#FFFFFF")
    val raisedFocus = pick("#1D2432", "#E9EDF3")
    val border = pick("#222A38", "#DCE1E9")
    val hairline = if (light) Color.parseColor("#E1E5EC") else Color.argb(20, 255, 255, 255)
    val chip = pick("#1E2532", "#E7EAF0")
    val chipFocus = pick("#333C4E", "#D9DFE8")
    val foreground = pick("#F2F4F8", "#10151F")
    val muted = pick("#8D97A8", "#5D6778")
    val faint = pick("#5B6577", "#9099A8")
    val accent = pick("#8CC4FF", "#2F6BDE")
    val onAccent = pick("#07111F", "#FFFFFF")
    val ring = if (light) Color.argb(215, 16, 21, 31) else Color.argb(235, 255, 255, 255)
    val softRing = if (light) Color.argb(60, 16, 21, 31) else Color.argb(64, 255, 255, 255)
    val glow = if (light) Color.BLACK else Color.parseColor("#9CC4FF")
    val track = pick("#2B3446", "#CBD2DC")
    fun dp(value: Float) = (value * scale * context.resources.displayMetrics.density).roundToInt()
    fun radii(top: Float, bottom: Float = top) = dp(top).toFloat().let { t -> dp(bottom).toFloat().let { b -> floatArrayOf(t, t, t, t, b, b, b, b) } }
    fun shape(fill: Int = surface, radius: Float = RADIUS_M, stroke: Int? = null, width: Float = 1f) = shape(fill, radii(radius), stroke, width)
    fun shape(fill: Int, radii: FloatArray, stroke: Int? = null, width: Float = 1f) = GradientDrawable().apply {
        setColor(fill); cornerRadii = radii; if (stroke != null) setStroke(dp(width).coerceAtLeast(1), stroke)
    }
    fun gradient(orientation: GradientDrawable.Orientation, vararg colors: Int, radius: Float = 0f) = GradientDrawable(orientation, colors).apply { cornerRadius = dp(radius).toFloat() }
    fun backdrop(): Drawable {
        val base = gradient(GradientDrawable.Orientation.TOP_BOTTOM, backgroundTop, background, background)
        val bloom = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT; setGradientCenter(.12f, 0f); gradientRadius = dp(620f).toFloat()
            colors = intArrayOf(Color.argb(if (light) 18 else 22, Color.red(accent), Color.green(accent), Color.blue(accent)), Color.TRANSPARENT)
        }
        val vignette = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT; setGradientCenter(.5f, .42f); gradientRadius = dp(720f).toFloat()
            colors = intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(if (light) 14 else 110, 0, 0, 0))
        }
        return LayerDrawable(arrayOf(base, bloom, vignette))
    }
    fun text(value: String, size: Float = TYPE_BODY, tint: Int = foreground, bold: Boolean = false, weight: Int = if (bold) 600 else 400) = TextView(context).apply {
        text = value; textSize = size * scale; setTextColor(tint); includeFontPadding = false
        typeface = Fonts.get(context, weight, size >= TYPE_H1); if (size >= TYPE_H1) letterSpacing = -.015f
        gravity = Gravity.CENTER_VERTICAL
    }
    fun eyebrow(value: String, tint: Int = muted) = text(value.uppercase(context.resources.configuration.locales[0]), TYPE_EYEBROW, tint, weight = 600).apply { letterSpacing = .14f }
    fun glyph(kind: Glyph.Kind, tint: Int = foreground) = ImageView(context).apply { setImageDrawable(Glyph(kind, tint)); isFocusable = false }
    fun cardStyle(radius: Float = RADIUS_M, zoom: Float = 1.04f, fill: Int = surface) = FocusStyle(fill, hairline, fill, radii(radius), zoom, ring, 1.75f, 6f)
    fun tile(hue: Int): Drawable = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
        Ambience.mix(if (light) Color.WHITE else Color.parseColor("#171C26"), hue, if (light) .09f else .17f),
        Ambience.mix(if (light) Color.parseColor("#FBFCFD") else Color.parseColor("#0F131A"), hue, if (light) .035f else .07f)))
    fun tileBorder(hue: Int) = if (light) Ambience.mix(Color.parseColor("#E1E5EC"), hue, .18f) else Color.argb(24, 255, 255, 255)
    fun style(view: View, style: FocusStyle) {
        view.setTag(R.id.sb_focus, style)
        val fade = Motion.duration(Motion.FOCUS).toInt()
        view.background = states(shape(style.focusFill, style.radii, if (style.ring != null) null else style.stroke), shape(style.fill, style.radii, style.stroke), fade)
        val ring = style.ring?.let { shape(Color.TRANSPARENT, style.radii, it, style.ringWidth) }
        val edge = if (style.stroke != null && view is FrameLayout) shape(Color.TRANSPARENT, style.radii, style.stroke) else null
        view.foreground = if (ring == null && edge == null) null else states(ring, edge, fade)
        view.outlineAmbientShadowColor = glow; view.outlineSpotShadowColor = glow
        focus(view, view.isFocused || view.isSelected, false)
    }
    private fun states(on: Drawable?, off: Drawable?, fade: Int) = StateListDrawable().apply {
        setEnterFadeDuration(fade); setExitFadeDuration(Motion.duration(Motion.FOCUS_OUT).toInt())
        val active = on ?: ColorDrawable(Color.TRANSPARENT)
        addState(intArrayOf(android.R.attr.state_focused), active); addState(intArrayOf(android.R.attr.state_selected), active)
        addState(intArrayOf(), off ?: ColorDrawable(Color.TRANSPARENT))
    }
    /** Retargets scale and lift from wherever they are; skips views already heading to the target. */
    fun focus(view: View, selected: Boolean, animate: Boolean = true) {
        val style = view.getTag(R.id.sb_focus) as? FocusStyle ?: return style(view, cardStyle())
        val zoom = if (selected) style.zoom else 1f
        val lift = if (selected) dp(style.lift).toFloat() else 0f
        if (!animate || !Motion.animated) { view.animate().cancel(); view.scaleX = zoom; view.scaleY = zoom; view.translationZ = lift; view.setTag(R.id.sb_motion, zoom); return }
        if (view.getTag(R.id.sb_motion) == zoom) return
        view.setTag(R.id.sb_motion, zoom)
        view.animate().scaleX(zoom).scaleY(zoom).translationZ(lift).setStartDelay(0).setDuration(Motion.FOCUS)
            .setInterpolator(if (selected) Motion.decelerate else Motion.standard).start()
    }
    /** Short scale dip as press feedback, then back to the current focus state. */
    fun press(view: View) {
        val style = view.getTag(R.id.sb_focus) as? FocusStyle ?: return
        if (!Motion.moving || style.zoom == 1f) return
        view.setTag(R.id.sb_motion, null)
        view.animate().scaleX(style.zoom * .96f).scaleY(style.zoom * .96f).setStartDelay(0).setDuration(Motion.MICRO / 2).setInterpolator(Motion.accelerate)
            .withEndAction { focus(view, view.isFocused || view.isSelected) }.start()
    }
    private fun focusable(view: View, action: () -> Unit) {
        view.isFocusable = true; view.isFocusableInTouchMode = true; view.isClickable = true
        view.setOnFocusChangeListener { v, yes -> focus(v, yes) }
        view.setOnClickListener { press(view); action() }
    }
    fun chip(value: String, tint: Int = foreground, fill: Int = chip) = text(value, 13f, tint, weight = 500).apply {
        maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; maxWidth = dp(280f)
        setPadding(dp(12f), dp(6f), dp(12f), dp(6f)); background = shape(fill, PILL)
    }
    fun item(label: String, detail: String = "", value: String = "", trail: Trail = Trail.NONE, action: (() -> Unit)? = null): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL; isBaselineAligned = false; gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(54f)
        setPadding(dp(20f), dp(11f), dp(16f), dp(11f)); clipChildren = false
        val column = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        column.addView(text(label, 15.5f, weight = 500))
        if (detail.isNotEmpty()) column.addView(text(detail, 12.5f, muted).apply { setPadding(0, dp(5f), 0, 0); setLineSpacing(dp(3f).toFloat(), 1f) })
        addView(column, LinearLayout.LayoutParams(0, -2, 1f))
        when (trail) {
            Trail.CHIP -> addView(chip(value), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(12f) })
            Trail.ON, Trail.OFF -> addView(View(context).apply { background = SwitchDrawable(trail == Trail.ON, accent, onAccent, track, if (light) Color.WHITE else muted) },
                LinearLayout.LayoutParams(dp(42f), dp(24f)).apply { marginStart = dp(12f) })
            Trail.CHEVRON -> addView(glyph(Glyph.Kind.CHEVRON, faint), LinearLayout.LayoutParams(dp(18f), dp(18f)).apply { marginStart = dp(10f) })
            Trail.NONE -> Unit
        }
        setTag(R.id.sb_item, true)
        style(this, FocusStyle(raised, if (light) border else null, raisedFocus, radii(RADIUS_M), 1f, softRing))
        if (action != null) focusable(this, action)
    }
    fun row(label: String, detail: String = "", action: (() -> Unit)? = null) = item(label, detail, trail = if (action != null) Trail.CHEVRON else Trail.NONE, action = action)
    fun header(label: String) = eyebrow(label).apply { setPadding(dp(6f), dp(10f), 0, dp(10f)) }
    fun group(container: ViewGroup) {
        val views = (0 until container.childCount).map { container.getChildAt(it) }
        var start = 0
        while (start < views.size) {
            if (views[start].getTag(R.id.sb_item) != true) { start++; continue }
            var end = start
            while (end + 1 < views.size && views[end + 1].getTag(R.id.sb_item) == true) end++
            for (k in start..end) {
                val view = views[k]
                val style = view.getTag(R.id.sb_focus) as FocusStyle
                val corners = radii(if (k == start) RADIUS_L else 5f, if (k == end) RADIUS_L else 5f)
                if (!style.radii.contentEquals(corners)) style(view, style.copy(radii = corners))
                (view.layoutParams as? ViewGroup.MarginLayoutParams)?.let {
                    val margin = dp(if (k == end) 18f else 3f)
                    if (it.bottomMargin != margin) { it.bottomMargin = margin; view.layoutParams = it }
                }
            }
            start = end + 1
        }
    }
    fun nav(icon: Glyph.Kind, label: String, selected: Boolean, action: () -> Unit) = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16f), 0, dp(16f), 0)
        addView(glyph(icon), LinearLayout.LayoutParams(dp(20f), dp(20f)).apply { marginEnd = dp(14f) })
        addView(text(label, 15f, weight = 500).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(0, -2, 1f))
        focusable(this, action)
        setOnFocusChangeListener { v, yes -> focus(v, yes); paintNav(v as LinearLayout) }
        select(this, selected)
    }
    fun select(view: LinearLayout, selected: Boolean) {
        if (view.getTag(R.id.sb_nav) == selected) return
        view.setTag(R.id.sb_nav, selected)
        style(view, FocusStyle(if (selected) (if (light) raised else chip) else Color.TRANSPARENT, if (selected && light) border else null, if (light) chipFocus else chipFocus, radii(PILL), 1f))
        paintNav(view)
    }
    private fun paintNav(view: LinearLayout) {
        val active = view.getTag(R.id.sb_nav) == true
        ((view.getChildAt(0) as ImageView).drawable as Glyph).tint(if (active) accent else if (view.isFocused) foreground else muted)
        (view.getChildAt(1) as TextView).setTextColor(if (active || view.isFocused) foreground else muted)
    }
    fun key(label: String, kind: Int = 0, focusRing: Int = softRing, action: () -> Unit) = text(label, if (label.length == 1) 18f else 13.5f, if (kind == 2) onAccent else foreground, weight = if (kind == 0) 500 else 600).apply {
        gravity = Gravity.CENTER; maxLines = 1
        val fill = when (kind) { 2 -> accent; 1 -> chip; else -> surfaceHigh }
        style(this, FocusStyle(fill, null, if (kind == 2) fill else chipFocus, radii(RADIUS_S + 2f), 1.06f, focusRing))
        focusable(this, action)
    }
    fun button(label: String, action: () -> Unit) = key(label, 0, action = action)
    fun pill(label: String, active: Boolean) = text(label, 13f, if (active) foreground else muted, weight = if (active) 600 else 500).apply {
        gravity = Gravity.CENTER; maxLines = 1; setPadding(dp(16f), 0, dp(16f), 0)
        style(this, FocusStyle(if (active) chip else Color.TRANSPARENT, null, chipFocus, radii(PILL), 1f, softRing, 1f))
    }
    fun dialogBody() = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(28f), dp(26f), dp(28f), dp(22f))
        background = shape(raised, RADIUS_XL, if (light) border else hairline); clipChildren = false; clipToPadding = false
    }
    /** Modal backdrop colour; the quick menu reuses it with its own lighter alphas. */
    fun scrim(alpha: Int = if (light) 112 else 168) = Color.argb(alpha, 4, 6, 10)
    /** Shows [content] as a [width]-wide card over a full-screen scrim; [top] pins it below the top edge instead of centring. */
    fun present(dialog: Dialog, width: Float, content: View, top: Float? = null) {
        val window = dialog.window ?: return
        window.setBackgroundDrawableResource(android.R.color.transparent); window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND); Motion.dialog(dialog)
        (content.parent as? android.view.ViewGroup)?.removeView(content)
        dialog.setContentView(android.widget.FrameLayout(context).apply {
            addView(View(context).apply { setBackgroundColor(scrim()) }, android.widget.FrameLayout.LayoutParams(-1, -1))
            addView(content, android.widget.FrameLayout.LayoutParams(dp(width), -2, if (top == null) android.view.Gravity.CENTER else android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL).apply { setMargins(0, dp(top ?: 12f), 0, dp(12f)) })
        })
        dialog.show(); ControllerNavigation.install(window); window.setLayout(-1, -1)
        if (Motion.moving) { content.scaleX = .96f; content.scaleY = .96f; content.animate().scaleX(1f).scaleY(1f).setDuration(Motion.EMPHASIZED).setInterpolator(Motion.decelerate).start() }
    }
    fun panel(title: String, options: List<Pair<String, () -> Unit>>, message: String = "", focus: Int = 0): Dialog = card(title, options, message, focus = focus)
    fun toggle(label: String, enabled: Boolean, change: (Boolean) -> Unit) = item(label, trail = if (enabled) Trail.ON else Trail.OFF) { change(!enabled) }
    fun slider(label: String, value: Int, minimum: Int, maximum: Int, step: Int, change: (Int) -> Unit): View {
        val row = item(label, value = "‹  $value  ›", trail = Trail.CHIP) { }
        row.setOnKeyListener { _, code, event ->
            if (event.action != android.view.KeyEvent.ACTION_DOWN || code !in listOf(android.view.KeyEvent.KEYCODE_DPAD_LEFT, android.view.KeyEvent.KEYCODE_DPAD_RIGHT)) false
            else { change((value + if (code == android.view.KeyEvent.KEYCODE_DPAD_RIGHT) step else -step).coerceIn(minimum, maximum)); true }
        }
        return row
    }
}

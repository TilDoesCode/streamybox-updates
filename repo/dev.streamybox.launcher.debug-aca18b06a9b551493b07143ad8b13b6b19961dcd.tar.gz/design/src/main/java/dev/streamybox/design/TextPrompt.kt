package dev.streamybox.design

import android.app.Dialog
import android.graphics.drawable.StateListDrawable
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.inputmethod.InputMethodManager
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout

/** Title plus one plain text field above the system keyboard; secrets are cleared on dismissal. */
class TextPrompt(private val ui: TvDesign, title: String, secret: Boolean, hint: String = "", private val done: (String) -> Unit) : Dialog(ui.context) {
    val field = EditText(ui.context).apply {
        textSize = 20f * ui.scale; typeface = Fonts.get(context, 500); includeFontPadding = false
        setTextColor(ui.foreground); setHintTextColor(ui.faint); this.hint = hint; isSingleLine = true
        setPadding(ui.dp(18f), 0, ui.dp(18f), 0); gravity = Gravity.CENTER_VERTICAL
        background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), ui.shape(ui.background, TvDesign.RADIUS_M, ui.accent, 2f))
            addState(intArrayOf(), ui.shape(ui.background, TvDesign.RADIUS_M, ui.border))
        }
        textCursorDrawable = ui.shape(ui.accent, 1f).apply { setSize(ui.dp(2f), -1) }
        inputType = InputType.TYPE_CLASS_TEXT or if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
        setOnEditorActionListener { _, action, event ->
            when {
                action == EditorInfo.IME_ACTION_DONE || event?.action == KeyEvent.ACTION_UP -> { submit(); true }
                else -> event != null
            }
        }
    }
    private val body = ui.dialogBody()
    init {
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        body.addView(ui.text(title, 22f, weight = 600).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(ui.dp(2f), 0, 0, ui.dp(16f)) })
        body.addView(field, LinearLayout.LayoutParams(-1, ui.dp(52f)))
        setContentView(body)
        window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        setOnDismissListener { field.text.clear() }
    }
    fun open() {
        ui.present(this, 720f, body, 64f)
        field.requestFocus(); field.post { context.getSystemService(InputMethodManager::class.java).showSoftInput(field, 0) }
    }
    private fun submit() { val value = field.text.toString(); dismiss(); done(value) }
}

package dev.streamybox.launcher

import org.junit.Assert.*
import org.junit.Test

class HomeLayoutTest {
    private val full = HomeLayout.parse(null)
    private val favourites = HomeLayout.parse(HomeLayout.FAVORITES)

    @Test fun unknownOrMissingValuesKeepTheFullLayout() {
        assertFalse(full.favoritesOnly)
        assertFalse(HomeLayout.parse("bogus").favoritesOnly)
        assertFalse(HomeLayout.parse(HomeLayout.FULL).favoritesOnly)
        assertTrue(favourites.favoritesOnly)
        assertEquals(listOf("full", "favorites"), HomeLayout.values)
    }
    @Test fun favouritesOnlyDropsTheAllAppsRowAndItsFocusRow() {
        assertNotNull(full.all)
        assertNull(favourites.all)
        assertEquals(listOf(6, 5, 20), full.lengths(6, 5, 20))
        assertEquals(listOf(6, 5), favourites.lengths(6, 5, 20))
    }
    @Test fun cursorNeverLandsOnAHiddenRow() {
        val cursor = RemoteCursor(1, 2)
        repeat(3) { cursor.move(0, 1, favourites.lengths(6, 5, 20)) }
        assertEquals(1 to 2, cursor.row to cursor.column)
        repeat(2) { cursor.move(0, -1, favourites.lengths(6, 5, 20)) }
        assertEquals(0, cursor.row)
        cursor.move(0, 1, favourites.lengths(6, 1, 20))
        assertEquals(1 to 0, cursor.row to cursor.column)
    }
    @Test fun heroGrowsIntoTheFreedSpaceAndEverythingFitsTheCanvas() {
        assertTrue(favourites.heroHeight > full.heroHeight)
        assertTrue(favourites.nameSize > full.nameSize)
        assertTrue(favourites.iconSize > full.iconSize)
        assertTrue(favourites.pinned.titleY > full.pinned.titleY)
        for (layout in listOf(full, favourites)) {
            assertTrue(layout.buttonsY + layout.buttonsHeight + 8f <= layout.pinned.titleY)
            assertTrue(layout.hintY >= layout.nameY + layout.nameHeight - 4f)
            assertTrue(HomeLayout.NAME_X + layout.nameWidth + 16f <= layout.iconX)
            layout.rows.zipWithNext().forEach { (upper, lower) -> assertTrue(upper.bottom + 8f <= lower.titleY) }
            assertTrue(layout.rows.last().bottom + 24f <= 540f)
        }
    }
    @Test fun favouriteCardsKeepSixteenByNineAndAlwaysCarryANameLine() {
        for (row in listOf(full.pinned, favourites.pinned)) {
            assertEquals(16f / 9f, row.width / row.height, .02f)
            assertTrue(row.label > 0 && row.labelHeight > row.label)
        }
        assertEquals(0f, full.all!!.labelHeight, 0f)
    }
    @Test fun focusedCardStaysInsideTheViewport() {
        for (row in listOfNotNull(full.pinned, full.all, favourites.pinned)) {
            assertTrue(row.lead >= 1)
            assertTrue(row.lead * row.step + row.width <= 848f)
        }
        assertEquals(3, full.pinned.lead)
        assertEquals(5, full.all!!.lead)
    }
}

@file:Suppress("DEPRECATION")
package dev.streamybox.launcher

import android.test.ActivityInstrumentationTestCase2
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup

class RenderingNavigationTest : ActivityInstrumentationTestCase2<MainActivity>(MainActivity::class.java) {
    private fun scene(): View = ((activity.findViewById<ViewGroup>(android.R.id.content).getChildAt(0)) as ViewGroup).getChildAt(0)
    private fun key(code: Int) { instrumentation.sendKeyDownUpSync(code); Thread.sleep(250) }
    private fun currentScene(): View { lateinit var value: View; instrumentation.runOnMainSync { value = scene() }; return value }
    private fun waitForCatalogue() {
        val loading = MainActivity::class.java.getDeclaredField("loading").apply { isAccessible = true }
        val deadline = android.os.SystemClock.uptimeMillis() + 30000
        while (android.os.SystemClock.uptimeMillis() < deadline) {
            var ready = false
            instrumentation.runOnMainSync { ready = !loading.getBoolean(activity) && scene().width > 0 }
            if (ready) { Thread.sleep(300); return }
            Thread.sleep(100)
        }
        fail("Launcher catalogue did not finish loading")
    }
    private fun openApps() {
        fun find(view: View): View? {
            if (view.isFocusable && view.contentDescription == activity.getString(R.string.apps)) return view
            if (view is ViewGroup) for (index in 0 until view.childCount) find(view.getChildAt(index))?.let { return it }
            return null
        }
        var clicked = false
        instrumentation.runOnMainSync { clicked = find(activity.window.decorView)?.performClick() == true }
        assertTrue("All-apps tab missing", clicked)
        Thread.sleep(400)
    }
    fun testHomeAndTabsReuseScenesWithoutLosingFocus() {
        val client = dev.streamybox.profiles.contract.ProfileClient
        client.status(instrumentation.targetContext)?.takeIf { it.optBoolean("pending") }?.let {
            client.call(instrumentation.targetContext, "switch", org.json.JSONObject().put("id", it.getString("current")))
        }
        setActivityIntent(android.content.Intent().addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK))
        val screen = activity
        waitForCatalogue()
        val home = currentScene()
        openApps()
        val apps = currentScene()
        assertNotSame(home, apps)
        var focus: View? = null
        instrumentation.runOnMainSync { focus = screen.currentFocus }
        assertNotNull(focus)
        key(KeyEvent.KEYCODE_BACK)
        Thread.sleep(300)
        assertSame(home, currentScene())
        openApps()
        assertSame(apps, currentScene())
        key(KeyEvent.KEYCODE_BACK)
    }
}

@file:Suppress("DEPRECATION", "UNCHECKED_CAST")
package dev.streamybox.launcher

import android.net.Uri
import android.test.ActivityInstrumentationTestCase2
import android.view.KeyEvent
import android.view.View
import android.widget.TextView

class HomeLayoutSwitchTest : ActivityInstrumentationTestCase2<MainActivity>(MainActivity::class.java) {
    private val ctx get() = instrumentation.targetContext
    private val uri get() = Uri.parse("content://${ctx.packageName}.state")
    private fun state(method: String, arg: String? = null) = requireNotNull(ctx.contentResolver.call(uri, method, arg, null))
    private var saved: String? = null
    private fun <T> field(name: String): T = MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.get(activity) as T

    override fun setUp() {
        super.setUp()
        val client = dev.streamybox.profiles.contract.ProfileClient
        client.status(ctx)?.takeIf { it.optBoolean("pending") }?.let { client.call(ctx, "switch", org.json.JSONObject().put("id", it.getString("current"))) }
        saved = state("read").getString("home_layout")
        setActivityIntent(android.content.Intent().addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK))
    }
    override fun tearDown() { saved?.let { state("home_layout", it) }; super.tearDown() }

    private fun launch() {
        val screen = activity
        val loading = MainActivity::class.java.getDeclaredField("loading").apply { isAccessible = true }
        val deadline = android.os.SystemClock.uptimeMillis() + 30000
        while (android.os.SystemClock.uptimeMillis() < deadline) {
            var ready = false
            instrumentation.runOnMainSync { ready = !loading.getBoolean(screen) && screen.window.decorView.width > 0 && field<Map<Pair<Int, Int>, View>>("cards").keys.any { it.first == 1 } }
            if (ready) { Thread.sleep(400); return }
            Thread.sleep(100)
        }
        fail("Launcher home did not finish loading")
    }
    private fun key(code: Int) { instrumentation.sendKeyDownUpSync(code); Thread.sleep(250) }
    private fun focusedKey(): Pair<Int, Int>? {
        var found: Pair<Int, Int>? = null
        instrumentation.runOnMainSync { val focus = activity.currentFocus; found = field<Map<Pair<Int, Int>, View>>("cards").entries.firstOrNull { it.value === focus }?.key }
        return found
    }
    private fun texts(view: View): List<String> = when (view) {
        is TextView -> listOf(view.text.toString()).filter { view.isShown }
        is android.view.ViewGroup -> (0 until view.childCount).flatMap { texts(view.getChildAt(it)) }
        else -> emptyList()
    }

    fun testProviderPersistsHomeLayoutAndRejectsUnknownValues() {
        state("home_layout", HomeLayout.FAVORITES)
        assertEquals(HomeLayout.FAVORITES, state("read").getString("home_layout"))
        state("home_layout", HomeLayout.FULL)
        assertEquals(HomeLayout.FULL, state("read").getString("home_layout"))
        assertTrue(runCatching { state("home_layout", "grid") }.isFailure)
        assertEquals(HomeLayout.FULL, state("read").getString("home_layout"))
    }

    fun testFavouritesOnlyHidesAllAppsAndKeepsFocusOnRealTargets() {
        state("home_layout", HomeLayout.FAVORITES)
        launch()
        var visible = emptyList<String>()
        instrumentation.runOnMainSync { visible = texts(activity.window.decorView) }
        assertFalse("All apps row still shown: $visible", activity.getString(R.string.allApps) in visible)
        assertTrue(activity.getString(R.string.pinned) in visible)
        instrumentation.runOnMainSync {
            val cards = field<Map<Pair<Int, Int>, View>>("cards"); val labels = field<Map<Pair<Int, Int>, TextView>>("labels")
            assertTrue(cards.keys.none { it.first == 2 })
            for (key in cards.keys.filter { it.first == 1 }) assertTrue("Favourite $key has no name", labels[key]?.text?.isNotBlank() == true && labels[key]!!.isShown)
        }
        assertEquals(1 to 0, focusedKey())
        repeat(3) { key(KeyEvent.KEYCODE_DPAD_DOWN) }
        assertEquals(1 to 0, focusedKey())
        key(KeyEvent.KEYCODE_DPAD_RIGHT)
        assertEquals(1 to 1, focusedKey())
        key(KeyEvent.KEYCODE_DPAD_UP)
        assertEquals(0, focusedKey()?.first)
        key(KeyEvent.KEYCODE_DPAD_DOWN)
        assertEquals(1, focusedKey()?.first)
    }

    fun testFullLayoutKeepsAllAppsAndNamesEveryFavourite() {
        state("home_layout", HomeLayout.FULL)
        launch()
        var visible = emptyList<String>()
        instrumentation.runOnMainSync { visible = texts(activity.window.decorView) }
        assertTrue(activity.getString(R.string.allApps) in visible)
        instrumentation.runOnMainSync {
            val cards = field<Map<Pair<Int, Int>, View>>("cards"); val labels = field<Map<Pair<Int, Int>, TextView>>("labels")
            assertTrue(cards.keys.any { it.first == 2 })
            for (key in cards.keys.filter { it.first == 1 }) assertTrue("Favourite $key has no name", labels[key]?.text?.isNotBlank() == true)
        }
        key(KeyEvent.KEYCODE_DPAD_DOWN)
        assertEquals(2, focusedKey()?.first)
    }
}

package dev.streamybox.launcher

/** Start page geometry in dp on the 960×540 canvas: the full layout or favourites only with a taller hero. */
data class HomeLayout(val favoritesOnly: Boolean) {
    val heroHeight = if (favoritesOnly) 440f else 332f
    val iconSize = if (favoritesOnly) 156f else 124f
    val iconX = if (favoritesOnly) 618f else 646f
    val iconY = if (favoritesOnly) 130f else 80f
    val eyebrowY = if (favoritesOnly) 120f else 88f
    val nameSize = if (favoritesOnly) 56f else 44f
    val nameY = if (favoritesOnly) 142f else 108f
    val nameHeight = if (favoritesOnly) 72f else 58f
    val nameWidth get() = iconX - NAME_X - 24f
    val hintSize = if (favoritesOnly) 16f else 15f
    val hintY = if (favoritesOnly) 220f else 170f
    val buttonsY = if (favoritesOnly) 258f else 204f
    val buttonsHeight = if (favoritesOnly) 38f else 34f
    val pinned = if (favoritesOnly) Row(334f, 192f, 108f, 16f, 15f) else Row(254f, 160f, 90f, 14f, 13.5f)
    val all: Row? = if (favoritesOnly) null else Row(408f, 112f, 68f, 12f, 0f)
    val rows get() = listOfNotNull(pinned, all)
    /** Row 0 is the top bar; with favourites only there is no "All apps" row to land on. */
    fun lengths(tabs: Int, favourites: Int, apps: Int) = if (favoritesOnly) listOf(tabs, favourites) else listOf(tabs, favourites, apps)

    /** One horizontal row of cards; [label] > 0 is the text size of the name below each card. */
    data class Row(val titleY: Float, val width: Float, val height: Float, val gap: Float, val label: Float) {
        val top get() = titleY + 16f
        val labelHeight get() = if (label > 0) label * 1.45f + LABEL_GAP else 0f
        val bottom get() = top + 10f + height + labelHeight
        val step get() = width + gap
        /** Cards the row may scroll past before the focused one would leave the 848 dp viewport. */
        val lead get() = ((848f - width) / step).toInt()
        companion object { const val LABEL_GAP = 7f }
    }

    companion object {
        const val NAME_X = 53f
        const val FULL = "full"
        const val FAVORITES = "favorites"
        val values = listOf(FULL, FAVORITES)
        fun parse(value: String?) = HomeLayout(value == FAVORITES)
    }
}

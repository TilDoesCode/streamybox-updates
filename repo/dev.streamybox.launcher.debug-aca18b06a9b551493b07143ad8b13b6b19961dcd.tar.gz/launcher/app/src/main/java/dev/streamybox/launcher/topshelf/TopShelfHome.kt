package dev.streamybox.launcher.topshelf

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import dev.streamybox.design.*
import dev.streamybox.launcher.AppEntry
import dev.streamybox.launcher.R
import dev.streamybox.profiles.contract.ProfileClient
import java.util.concurrent.Executors

internal class TopShelfHome(private val activity: Activity, private val profile: () -> String, private val changed: () -> Unit) {
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var resumed = false
    private var loading = false
    private var epoch = 0
    private var snapshot = ShelfSnapshot(ShelfData(), emptyMap(), null, false)
    private var host: FrameLayout? = null
    private var focusTag: Any? = null
    val populated get() = !snapshot.data.empty
    val visible get() = host?.isAttachedToWindow == true && !snapshot.data.empty
    private val profiles = object : android.database.ContentObserver(handler) { override fun onChange(selfChange: Boolean) { host?.visibility = View.INVISIBLE; snapshot = ShelfSnapshot(ShelfData(), emptyMap(), null, false); if (resumed) activity.recreate() } }
    init { activity.contentResolver.registerContentObserver(ProfileClient.uri, false, profiles) }
    private val periodic = object : Runnable { override fun run() { refresh(); if (resumed) handler.postDelayed(this, 120000) } }
    fun resume() { resumed = true; host?.visibility = View.VISIBLE; handler.removeCallbacks(periodic); periodic.run() }
    fun pause() { resumed = false; epoch++; handler.removeCallbacks(periodic); host?.visibility = View.INVISIBLE }
    fun close() { pause(); activity.contentResolver.unregisterContentObserver(profiles); worker.shutdownNow() }
    fun refresh() {
        if (!resumed || loading || worker.isShutdown) return
        loading = true
        host?.visibility = View.VISIBLE
        val scope = profile(); val version = epoch
        worker.execute {
            val store = ShelfStore(activity, scope)
            val source = JellyfinContentSource(activity, store)
            val cached = runCatching { source.refresh(cachedOnly = true) }.getOrNull()
            if (cached != null && !cached.data.empty) handler.post { if (!activity.isDestroyed && resumed && version == epoch && store.active()) { val different = snapshot.data != cached.data || snapshot.images.keys != cached.images.keys; snapshot = cached; if (different) changed() } }
            val next = runCatching { source.refresh() }.getOrDefault(ShelfSnapshot(ShelfData(), emptyMap(), null, true))
            handler.post {
                loading = false
                if (activity.isDestroyed || !resumed) return@post
                if (version != epoch) { refresh(); return@post }
                if (!store.active() || scope != profile()) { snapshot = ShelfSnapshot(ShelfData(), emptyMap(), null, false); host?.visibility = View.INVISIBLE; changed(); return@post }
                val different = next.data != snapshot.data || next.images.keys != snapshot.images.keys || (next.hero != null) != (snapshot.hero != null)
                snapshot = next
                if (different) { focusTag = activity.currentFocus?.tag; changed() }
            }
        }
    }
    fun dispatch(event: KeyEvent, fallback: () -> Boolean): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) return true
        if (event.keyCode == KeyEvent.KEYCODE_MENU) { if (event.action == KeyEvent.ACTION_UP) activity.currentFocus?.performLongClick(); return true }
        return fallback()
    }
    fun attach(stage: FrameLayout, ui: TvDesign, pinned: List<AppEntry>, apps: List<AppEntry>, open: (AppEntry) -> Unit, menu: (AppEntry) -> Unit, icon: (AppEntry) -> android.graphics.drawable.Drawable) {
        host = null; backdrops = null
        if (snapshot.data.empty) return
        for (index in 0 until stage.childCount) { val child = stage.getChildAt(index); val layout = child.layoutParams as FrameLayout.LayoutParams; if (layout.topMargin >= ui.dp(68f) || layout.height > ui.dp(100f)) child.visibility = View.GONE }
        val container = FrameLayout(activity).apply { background = android.graphics.drawable.ColorDrawable(ui.background); clipChildren = true }
        host = container
        stage.addView(container, FrameLayout.LayoutParams(-1, -1).apply { topMargin = ui.dp(68f) })
        val column = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false }
        val scroll = GlideScrollView(activity).apply { isVerticalScrollBarEnabled = false; clipChildren = false; clipToPadding = false; addView(column) }
        container.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        val hero = snapshot.data.resume.firstOrNull()
        var first: View? = null
        if (hero != null) {
            val frame = FrameLayout(activity)
            val base = snapshot.hero ?: snapshot.images[hero.id]
            backdrops = ImageView(activity).apply { setImageBitmap(base); scaleType = ImageView.ScaleType.CENTER_CROP } to ImageView(activity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0f }
            heroBackdrop = base; shownBackdrop = base
            frame.addView(backdrops!!.first, FrameLayout.LayoutParams(-1, -1)); frame.addView(backdrops!!.second, FrameLayout.LayoutParams(-1, -1))
            frame.addView(View(activity).apply { background = ui.gradient(GradientDrawable.Orientation.LEFT_RIGHT, ui.background, Color.argb(if (ui.light) 220 else 200, Color.red(ui.background), Color.green(ui.background), Color.blue(ui.background)), Color.TRANSPARENT) }, FrameLayout.LayoutParams(ui.dp(760f), -1))
            frame.addView(View(activity).apply { background = ui.gradient(GradientDrawable.Orientation.TOP_BOTTOM, Color.TRANSPARENT, ui.background) }, FrameLayout.LayoutParams(-1, ui.dp(90f), Gravity.BOTTOM))
            val words = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
            words.addView(ui.text(activity.getString(R.string.topshelf_resume), 12f, ui.muted, weight = 500))
            words.addView(ui.text(hero.title, 38f, weight = 650).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, ui.dp(8f), 0, 0) })
            words.addView(ui.text(label(hero), 14f, ui.muted).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, ui.dp(7f), 0, ui.dp(12f)) })
            words.addView(progress(ui, hero), LinearLayout.LayoutParams(ui.dp(250f), ui.dp(2f)))
            val play = ui.row(activity.getString(R.string.topshelf_play)) { play(hero) }.apply { tag = "hero" }
            words.addView(play, LinearLayout.LayoutParams(ui.dp(180f), ui.dp(43f)).apply { topMargin = ui.dp(14f) })
            frame.addView(words, FrameLayout.LayoutParams(ui.dp(570f), -2).apply { leftMargin = ui.dp(56f); topMargin = ui.dp(24f) })
            column.addView(frame, LinearLayout.LayoutParams(-1, ui.dp(236f))); first = play
        }
        fun section(title: String, views: List<View>, width: Float, height: Float) {
            if (views.isEmpty()) return
            column.addView(ui.text(title, 16f, weight = 600).apply { setPadding(ui.dp(56f), ui.dp(14f), ui.dp(56f), ui.dp(5f)) })
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }
            views.forEach { view -> row.addView(view, LinearLayout.LayoutParams(ui.dp(width), ui.dp(height)).apply { marginEnd = ui.dp(14f) }) }
            val horizontal = GlideHorizontalScrollView(activity).apply { isHorizontalScrollBarEnabled = false; clipChildren = false; clipToPadding = false; setPadding(ui.dp(56f), ui.dp(7f), ui.dp(42f), ui.dp(14f)); addView(row) }
            column.addView(horizontal, LinearLayout.LayoutParams(-1, -2))
            if (first == null) first = views.first()
        }
        fun appView(app: AppEntry) = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isFocusable = true; isFocusableInTouchMode = true; tag = "app:${app.packageName}"; contentDescription = app.label
            ui.style(this, ui.cardStyle(TvDesign.RADIUS_M, 1.04f)); setOnFocusChangeListener { view, yes -> ui.focus(view, yes) }
            addView(ImageView(activity).apply { setImageDrawable(icon(app)) }, LinearLayout.LayoutParams(ui.dp(36f), ui.dp(36f)))
            addView(ui.text(app.label, 12f, weight = 500).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(ui.dp(5f), ui.dp(8f), ui.dp(5f), 0) })
            setOnClickListener { open(app) }; setOnLongClickListener { menu(app); true }
        }
        section(activity.getString(R.string.pinned), pinned.map(::appView), 140f, 84f)
        for ((title, items) in listOf(R.string.topshelf_resume to snapshot.data.resume, R.string.topshelf_next to snapshot.data.next, R.string.topshelf_latest to snapshot.data.latest))
            section(activity.getString(title), items.take(12).map { item -> card(ui, item) }, 190f, 145f)
        section(activity.getString(R.string.allApps), apps.map(::appView), 112f, 80f)
        (focusTag?.let { container.findViewWithTag<View>(it) } ?: first)?.requestFocus()
    }
    private fun progress(ui: TvDesign, item: ShelfItem) = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 1000; progress = (item.progress * 1000).toInt(); progressTintList = android.content.res.ColorStateList.valueOf(ui.accent); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(ui.track)
        contentDescription = "${(item.progress * 100).toInt()}%"
    }
    private fun card(ui: TvDesign, item: ShelfItem): View = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL; isFocusable = true; isFocusableInTouchMode = true; tag = "item:${item.id}"; contentDescription = listOf(item.title, item.episode).filter { it.isNotEmpty() }.joinToString(". ")
        ui.style(this, ui.cardStyle(TvDesign.RADIUS_M, 1.04f)); setOnFocusChangeListener { view, yes -> ui.focus(view, yes); backdrop(if (yes) snapshot.images[item.id] else heroBackdrop) }
        addView(FrameLayout(activity).apply {
            addView(ImageView(activity).apply { setImageBitmap(snapshot.images[item.id]); scaleType = ImageView.ScaleType.CENTER_CROP; outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true; background = ui.shape(ui.surfaceHigh, TvDesign.RADIUS_M) }, FrameLayout.LayoutParams(-1, -1))
            if (item.position > 0) addView(progress(ui, item).apply { progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(110, 255, 255, 255)) }, FrameLayout.LayoutParams(-1, ui.dp(3f), Gravity.BOTTOM).apply { setMargins(ui.dp(10f), 0, ui.dp(10f), ui.dp(8f)) })
        }, LinearLayout.LayoutParams(-1, ui.dp(101f)))
        addView(ui.text(item.title, 13f, weight = 600).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(ui.dp(8f), ui.dp(6f), ui.dp(8f), 0) })
        addView(ui.text(label(item), 11f, ui.muted).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(ui.dp(8f), ui.dp(2f), ui.dp(8f), 0) })
        setOnClickListener { play(item) }
    }
    private var backdrops: Pair<ImageView, ImageView>? = null
    private var heroBackdrop: android.graphics.Bitmap? = null
    private var shownBackdrop: android.graphics.Bitmap? = null
    private var pendingBackdrop: Runnable? = null
    /** Series name is already the title; the card line starts at the season. */
    private fun label(item: ShelfItem) = item.episode.removePrefix("${item.title} · ")
    private fun backdrop(image: android.graphics.Bitmap?) {
        val (front, next) = backdrops ?: return
        pendingBackdrop?.let(handler::removeCallbacks)
        if (image == null || image === shownBackdrop) return
        pendingBackdrop = Runnable {
            shownBackdrop = image
            next.animate().cancel()
            if (!Motion.animated) { front.setImageBitmap(image); next.alpha = 0f; return@Runnable }
            next.setImageBitmap(image); next.alpha = 0f
            next.animate().alpha(1f).setDuration(Motion.duration(Motion.EMPHASIZED)).setInterpolator(Motion.standard).withEndAction { front.setImageBitmap(image); next.alpha = 0f }.start()
        }.also { handler.postDelayed(it, Motion.SETTLE) }
    }
    private fun play(item: ShelfItem) { activity.startActivity(Intent(activity, ShelfPlaybackActivity::class.java).putExtra("item", item.id).putExtra("profile", profile())) }
    companion object { fun connect(activity: Activity) { activity.startActivity(Intent(activity, JellyfinConnectActivity::class.java)) } }
}

@file:Suppress("DEPRECATION")
package dev.streamybox.launcher

import android.content.Intent
import android.test.InstrumentationTestCase
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo

class ProfileChoicesUiTest : InstrumentationTestCase() {
    private lateinit var appearance: android.os.Bundle
    private var added: String? = null
    override fun setUp() {
        super.setUp()
        val ctx = instrumentation.targetContext
        appearance = dev.streamybox.design.SharedState.read(ctx)
        dev.streamybox.design.SharedState.write(ctx, "language", "de")
        dev.streamybox.design.SharedState.write(ctx, "theme", "dark")
        val status = requireNotNull(dev.streamybox.profiles.contract.ProfileClient.status(ctx))
        val profiles = status.getJSONArray("profiles")
        if (profiles.length() < 2) {
            val original = profiles.getJSONObject(0).getString("id")
            val response = dev.streamybox.profiles.contract.ProfileClient.call(ctx, "add", org.json.JSONObject().put("name", "Regression fixture").put("color", -10453628)).getJSONArray("profiles")
            added = (0 until response.length()).map { response.getJSONObject(it).getString("id") }.first { it != original }
        }
    }
    override fun tearDown() {
        try {
            instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_HOME)
            val ctx = instrumentation.targetContext
            added?.let { dev.streamybox.profiles.contract.ProfileClient.call(ctx, "delete", org.json.JSONObject().put("id", it)) }
            dev.streamybox.design.SharedState.write(ctx, "language", appearance.getString("language", "en")!!)
            dev.streamybox.design.SharedState.write(ctx, "theme", if (appearance.getBoolean("light")) "light" else "dark")
        } finally { super.tearDown() }
    }
    private fun text(node: AccessibilityNodeInfo?): String {
        if(node==null)return ""
        return (node.text?.toString() ?: "")+"\n"+(0 until node.childCount).joinToString("\n") { text(node.getChild(it)) }
    }
    private fun open(developer: Boolean): String {
        Thread.sleep(450)
        val ctx=instrumentation.targetContext
        val monitor = instrumentation.addMonitor(MainActivity::class.java.name, null, false)
        try {
            ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setClass(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            val deadline = android.os.SystemClock.uptimeMillis() + 15000
            var stableSince = 0L
            while (android.os.SystemClock.uptimeMillis() < deadline) {
                var ready = false
                instrumentation.runOnMainSync {
                    ready = (monitor.lastActivity as? MainActivity)?.let { !it.isDestroyed && it.hasWindowFocus() && it.resources.configuration.locales[0].language == "de" } == true
                }
                if (!ready) stableSince = 0L else if (stableSince == 0L) stableSince = android.os.SystemClock.uptimeMillis()
                if (stableSince > 0 && android.os.SystemClock.uptimeMillis() - stableSince >= 500) break
                Thread.sleep(100)
            }
            assertTrue("German HOME did not settle before opening Profiles", stableSince > 0 && android.os.SystemClock.uptimeMillis() - stableSince >= 500)
        } finally { instrumentation.removeMonitor(monitor) }
        ctx.startActivity(Intent().setClassName("dev.streamybox.profiles","dev.streamybox.profiles.ProfilesActivity")
            .putExtra("developer",developer).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        Thread.sleep(1200)
        val count = requireNotNull(dev.streamybox.profiles.contract.ProfileClient.status(ctx)).getJSONArray("profiles").length()
        var found = false
        for (step in 0 until count + 8) {
            if ("App-Daten" in text(instrumentation.uiAutomation.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT))) { found = true; break }
            instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_DOWN); Thread.sleep(150)
        }
        assertTrue("App-Daten row unreachable with $count profiles; tree=${text(instrumentation.uiAutomation.rootInActiveWindow)}", found)
        instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_CENTER)
        val deadline=android.os.SystemClock.elapsedRealtime()+45000
        while(android.os.SystemClock.elapsedRealtime()<deadline) {
            val value=text(instrumentation.uiAutomation.rootInActiveWindow)
            if("System-Apps sind immer gemeinsam" in value)return value
            Thread.sleep(200)
        }
        fail("App-Daten did not render its footer");return ""
    }
    fun testDaemonFixtureRoundTrip() {
        val ctx = instrumentation.targetContext
        val client = dev.streamybox.profiles.contract.ProfileClient
        val initial = client.call(ctx, "status")
        val current = initial.getString("current")
        val profiles = initial.getJSONArray("profiles")
        val ids = (0 until profiles.length()).map { profiles.getJSONObject(it).getString("id") }.toSet()
        if (profiles.length() == 16) {
            assertTrue("Daemon accepted a seventeenth profile", runCatching { client.call(ctx, "add", org.json.JSONObject().put("name", "Regression capacity").put("color", -10453628)) }.isFailure)
            assertEquals(16, client.call(ctx, "invariants").getJSONArray("profiles").length())
            assertEquals(current, client.call(ctx, "status").getString("current"))
            return
        }
        var fixture: String? = null
        try {
            val after = client.call(ctx, "add", org.json.JSONObject().put("name", "Regression daemon").put("color", -10453628)).getJSONArray("profiles")
            fixture = (0 until after.length()).map { after.getJSONObject(it).getString("id") }.single { it !in ids }
            assertEquals(fixture, client.call(ctx, "switch", org.json.JSONObject().put("id", fixture)).getString("current"))
            assertEquals(fixture, client.call(ctx, "invariants").getString("current"))
            assertEquals("idle", client.call(ctx, "journal").getString("journal"))
            assertEquals(current, client.call(ctx, "switch", org.json.JSONObject().put("id", current)).getString("current"))
            assertEquals(current, client.call(ctx, "invariants").getString("current"))
        } finally {
            client.call(ctx, "switch", org.json.JSONObject().put("id", current))
            fixture?.let { client.call(ctx, "delete", org.json.JSONObject().put("id", it)) }
        }
        assertEquals(profiles.length(), client.call(ctx, "status").getJSONArray("profiles").length())
    }
    fun testOnlyActionableAppsAndDeveloperFixture() {
        val pm=instrumentation.targetContext.packageManager
        val fixture=pm.getApplicationLabel(pm.getApplicationInfo("dev.streamybox.profiletest",0)).toString()
        val normal=open(false)
        assertFalse("Internal fixture visible without developer unlock",fixture in normal)
        for(pkg in listOf("dev.streamybox.keyboard","dev.streamybox.settings")) {
            val apps = dev.streamybox.profiles.contract.ProfileClient.call(instrumentation.targetContext, "apps").getJSONArray("apps")
            val label = (0 until apps.length()).map { apps.getJSONObject(it) }.first { it.getString("package") == pkg }.getString("name")
            assertFalse("Always-shared app has a row: $pkg",label in normal)
        }
        assertFalse("Repeated system eligibility rows", "System-App: immer gemeinsam" in normal)
        fun focus() = instrumentation.uiAutomation.executeShellCommand("dumpsys window").use { descriptor ->
            android.os.ParcelFileDescriptor.AutoCloseInputStream(descriptor).use { it.readBytes().toString(Charsets.UTF_8).lineSequence().filter { line -> "mCurrentFocus=" in line }.joinToString("\n") }
        }
        assertTrue("Screenshot focus mismatch", "dev.streamybox.profiles.ProfilesActivity" in focus())
        val image=requireNotNull(instrumentation.uiAutomation.takeScreenshot())
        assertEquals(1920,image.width);assertEquals(1080,image.height)
        val output=java.io.File(instrumentation.targetContext.filesDir,"profile-ui-tests").apply { mkdirs() }
        java.io.File(output,"app-data-minimal-dark-de.png").outputStream().use { assertTrue(image.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it)) };image.recycle()
        assertTrue("Focus changed during screenshot", "dev.streamybox.profiles.ProfilesActivity" in focus())
        assertTrue("Developer fixture choice missing",fixture in open(true))
    }
}

pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "streamybox-launcher"
include(":app", ":design", ":profiles-contract", ":remote-contract")
project(":design").projectDir = file("../design")
project(":profiles-contract").projectDir = file("../profiles-contract")
project(":remote-contract").projectDir = file("../remote-contract")

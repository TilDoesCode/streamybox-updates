@file:Suppress("DEPRECATION")
package dev.streamybox.launcher

import android.test.AndroidTestCase
import android.net.Uri

class AppCurationDeviceTest : AndroidTestCase() {
    fun testCatalogAndProviderKeepDeveloperEscapeHatch() {
        val catalog = AppCatalog(context)
        val prefs = dev.streamybox.profiles.contract.ProfileClient.preferences(context)
        val originalHidden = prefs.getStringSet("hidden", emptySet())!!.toSet()
        val originalShown = prefs.getStringSet("shown", emptySet())!!.toSet()
        prefs.edit().putStringSet("hidden", emptySet()).putStringSet("shown", emptySet()).commit()
        val all = catalog.applications(true)
        assertTrue(all.any { it.packageName == "com.android.settings" })
        assertFalse(catalog.applications().any { AppCuration.hiddenByDefault(it.packageName) })
        val uri = Uri.parse("content://${context.packageName}.state")
        try {
            context.contentResolver.call(uri, "show", "com.android.settings", null)
            assertTrue(catalog.applications().any { it.packageName == "com.android.settings" })
            context.contentResolver.call(uri, "hide", "com.android.settings", null)
            assertFalse(catalog.applications().any { it.packageName == "com.android.settings" })
            assertTrue(catalog.applications(true).any { it.packageName == "com.android.settings" })
        } finally {
            prefs.edit().putStringSet("hidden", originalHidden).putStringSet("shown", originalShown).commit()
        }
    }
}

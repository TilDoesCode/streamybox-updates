@file:Suppress("DEPRECATION")
package dev.streamybox.launcher

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Debug
import android.os.SystemClock
import android.test.InstrumentationTestCase
import dev.streamybox.design.SharedState
import dev.streamybox.profiles.contract.ProfileClient
import java.lang.ref.WeakReference
import org.json.JSONObject

class LauncherLifecycleTest : InstrumentationTestCase() {
    private val activities = mutableListOf<WeakReference<MainActivity>>()
    @Volatile private var current = WeakReference<MainActivity>(null)
    private val callbacks = object : Application.ActivityLifecycleCallbacks {
        override fun onActivityCreated(activity: Activity, state: Bundle?) { if (activity is MainActivity) activities.add(WeakReference(activity)) }
        override fun onActivityResumed(activity: Activity) { if (activity is MainActivity) current = WeakReference(activity) }
        override fun onActivityStarted(activity: Activity) = Unit
        override fun onActivityPaused(activity: Activity) = Unit
        override fun onActivityStopped(activity: Activity) = Unit
        override fun onActivitySaveInstanceState(activity: Activity, state: Bundle) = Unit
        override fun onActivityDestroyed(activity: Activity) = Unit
    }
    private val ctx get() = instrumentation.targetContext
    private fun shell(command: String): String = instrumentation.uiAutomation.executeShellCommand(command).use { descriptor ->
        android.os.ParcelFileDescriptor.AutoCloseInputStream(descriptor).use { it.readBytes().toString(Charsets.UTF_8) }
    }
    private fun home() {
        LauncherTestHome.open(instrumentation)
    }
    private fun settings() {
        ctx.startActivity(Intent().setClassName("dev.streamybox.settings", "dev.streamybox.settings.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        val deadline = SystemClock.uptimeMillis() + 15000
        while (SystemClock.uptimeMillis() < deadline) {
            if (shell("dumpsys window").lineSequence().any { "mCurrentFocus=" in it && "dev.streamybox.settings.MainActivity}" in it }) return
            Thread.sleep(100)
        }
        fail("Settings did not gain focus")
    }
    private fun await(condition: () -> Boolean) {
        val deadline = SystemClock.uptimeMillis() + 15000
        while (SystemClock.uptimeMillis() < deadline) {
            var ready = false
            instrumentation.runOnMainSync { ready = condition() }
            if (ready) return
            Thread.sleep(100)
        }
        fail("Launcher lifecycle transition timed out")
    }
    private fun retained(): Int {
        var count = 0
        instrumentation.runOnMainSync { count = activities.count { it.get() != null } }
        return count
    }
    private fun collect() {
        val deadline = SystemClock.uptimeMillis() + 10000
        do {
            Runtime.getRuntime().gc(); System.runFinalization(); Runtime.getRuntime().gc()
            Thread.sleep(200)
        } while (retained() > 2 && SystemClock.uptimeMillis() < deadline)
        assertTrue("Destroyed HOME activities retained: ${retained()} of ${activities.size}", retained() <= 2)
    }
    fun testRealHomePathsReleaseDestroyedActivitiesAndBoundPss() {
        val application = ctx.applicationContext as Application
        val appearance = SharedState.read(ctx)
        val status = requireNotNull(ProfileClient.status(ctx))
        val original = status.getString("current")
        val ids = status.getJSONArray("profiles").let { array -> (0 until array.length()).map { array.getJSONObject(it).getString("id") }.toSet() }
        val density = shell("wm density")
        val override = Regex("Override density: (\\d+)").find(density)?.groupValues?.get(1)
        val originalDensity = (override ?: Regex("Physical density: (\\d+)").find(density)!!.groupValues[1]).toInt()
        var added: String? = null
        application.registerActivityLifecycleCallbacks(callbacks)
        try {
            ProfileClient.call(ctx, "switch", JSONObject().put("id", original))
            ctx.startActivity(Intent().setClass(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            home(); collect()
            val baseline = Debug.getPss()
            repeat(12) {
                val previous = current
                instrumentation.runOnMainSync { current.get()!!.recreate() }
                await { current.get() != null && current.get() !== previous.get() && current.get()?.hasWindowFocus() == true }
                Thread.sleep(200)
            }
            collect()
            repeat(12) { index ->
                settings()
                SharedState.write(ctx, "language", if (index % 2 == 0) "de" else "en")
                SharedState.write(ctx, "theme", if (index % 2 == 0) "light" else "dark")
                SharedState.write(ctx, "home_layout", if (index % 2 == 0) "favorites" else "full")
                home()
                await { current.get()?.resources?.configuration?.locales?.get(0)?.language == if (index % 2 == 0) "de" else "en" }
            }
            collect()
            val other = ids.firstOrNull { it != original } ?: run {
                val after = ProfileClient.call(ctx, "add", JSONObject().put("name", "Lifecycle regression").put("color", -10453628)).getJSONArray("profiles")
                (0 until after.length()).map { after.getJSONObject(it).getString("id") }.single { it !in ids }.also { added = it }
            }
            repeat(6) { index ->
                val profile = if (index % 2 == 0) other else original
                ProfileClient.call(ctx, "switch", JSONObject().put("id", profile))
                home()
                await { current.get()?.let { activity -> MainActivity::class.java.getDeclaredField("profileId").apply { isAccessible = true }.get(activity) == profile } == true }
            }
            collect()
            repeat(8) { settings(); home() }
            repeat(6) {
                instrumentation.runOnMainSync {
                    current.get()!!.let { activity -> activity.onConfigurationChanged(Configuration(activity.resources.configuration)) }
                }
                Thread.sleep(300)
            }
            repeat(4) { index ->
                val previous = current
                shell("wm density ${if (index % 2 == 0) originalDensity + 40 else originalDensity}")
                await { current.get() != null && current.get() !== previous.get() && current.get()?.hasWindowFocus() == true }
                Thread.sleep(300)
            }
            collect()
            val pss = Debug.getPss()
            assertTrue("Launcher PSS grew from $baseline to $pss KB", pss <= baseline + 64 * 1024 && pss <= 256 * 1024)
            assertTrue("Real paths did not recreate HOME", activities.size >= 25)
            instrumentation.sendStatus(0, Bundle().apply { putString("stream", "LIFECYCLE: created=${activities.size}, alive=${retained()}, baselinePss=$baseline KB, finalPss=$pss KB\n") })
        } finally {
            try {
                shell("wm density ${override ?: "reset"}")
                ProfileClient.call(ctx, "switch", JSONObject().put("id", original))
                added?.let { ProfileClient.call(ctx, "delete", JSONObject().put("id", it)) }
                SharedState.write(ctx, "language", appearance.getString("language", "en")!!)
                SharedState.write(ctx, "theme", if (appearance.getBoolean("light")) "light" else "dark")
                SharedState.write(ctx, "home_layout", appearance.getString("home_layout", "full")!!)
                SharedState.write(ctx, "motion", appearance.getString("motion", "full")!!)
                home()
            } finally { application.unregisterActivityLifecycleCallbacks(callbacks) }
        }
    }

    fun testOfflineTopShelfConnectDisconnectDoesNotRetainHome() {
        val application = ctx.applicationContext as Application
        val status = requireNotNull(ProfileClient.status(ctx))
        val original = status.getString("current")
        val ids = status.getJSONArray("profiles").let { array -> (0 until array.length()).map { array.getJSONObject(it).getString("id") }.toSet() }
        var added: String? = null
        application.registerActivityLifecycleCallbacks(callbacks)
        try {
            val profiles = ProfileClient.call(ctx, "add", JSONObject().put("name", "Shelf lifecycle regression").put("color", -10453628)).getJSONArray("profiles")
            added = (0 until profiles.length()).map { profiles.getJSONObject(it).getString("id") }.single { it !in ids }
            ProfileClient.call(ctx, "switch", JSONObject().put("id", added))
            ctx.startActivity(Intent().setClass(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            home(); collect()
            val baseline = Debug.getPss()
            val fixture = dev.streamybox.launcher.topshelf.TopShelfCalmFixture().apply { injectInstrumentation(this@LauncherLifecycleTest.instrumentation) }
            repeat(6) {
                fixture.testSeed()
                settings(); home()
                await { current.get()?.window?.decorView?.findViewWithTag<android.view.View>("hero")?.isShown == true }
                fixture.testClear()
                settings(); home()
                await { current.get()?.window?.decorView?.findViewWithTag<android.view.View>("hero")?.isShown != true }
            }
            collect()
            val pss = Debug.getPss()
            assertTrue("Top Shelf PSS grew from $baseline to $pss KB", pss <= baseline + 64 * 1024 && pss <= 256 * 1024)
            instrumentation.sendStatus(0, Bundle().apply { putString("stream", "SHELF LIFECYCLE: created=${activities.size}, alive=${retained()}, baselinePss=$baseline KB, finalPss=$pss KB\n") })
        } finally {
            try {
                added?.let { dev.streamybox.launcher.topshelf.ShelfStore(ctx, it).disconnect() }
                ProfileClient.call(ctx, "switch", JSONObject().put("id", original))
                added?.let { ProfileClient.call(ctx, "delete", JSONObject().put("id", it)) }
                home()
            } finally { application.unregisterActivityLifecycleCallbacks(callbacks) }
        }
    }
}

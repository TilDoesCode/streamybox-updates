@file:Suppress("DEPRECATION")
package dev.streamybox.launcher.topshelf

import android.content.Intent
import android.os.Bundle
import android.test.InstrumentationTestCase
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo
import dev.streamybox.design.SharedState
import dev.streamybox.profiles.contract.ProfileClient
import org.json.JSONObject

class TopShelfScenario : InstrumentationTestCase() {
    private val ctx get() = instrumentation.targetContext
    private fun tree(node: AccessibilityNodeInfo? = null): List<AccessibilityNodeInfo> = if (node == null) instrumentation.uiAutomation.windows.filter { it.isActive || it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_INPUT_METHOD }.flatMap { it.root?.let { root -> tree(root) } ?: emptyList() } else listOf(node) + (0 until node.childCount).flatMap { node.getChild(it)?.let { child -> tree(child) } ?: emptyList() }
    private fun waitFor(message: String, check: () -> Boolean) {
        val deadline = android.os.SystemClock.elapsedRealtime() + 45000
        while (android.os.SystemClock.elapsedRealtime() < deadline) { if (check()) return; Thread.sleep(150) }
        fail(message + ": " + tree().filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString(" / "))
    }
    private fun actionable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? { var target: AccessibilityNodeInfo? = node; while (target != null && !target.isClickable) target = target.parent; return target }
    private fun click(vararg labels: String) {
        waitFor("Missing action: ${labels.first()}") { tree().any { it.text?.toString() in labels } }
        val target = tree().firstNotNullOfOrNull { if (it.text?.toString() in labels) actionable(it) else null }
        assertTrue(target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true); Thread.sleep(350)
    }
    private fun status(label: String) { instrumentation.sendStatus(0, Bundle().apply { putString("stream", "TOP_SHELF_STAGE:$label\n") }) }
    fun testQuickConnectAndProfileIsolation() {
        instrumentation.uiAutomation.serviceInfo = instrumentation.uiAutomation.serviceInfo.apply { flags = flags or android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS }
        val fixture = JSONObject(instrumentation.uiAutomation.executeShellCommand("cat /data/local/tmp/top-shelf-fixture.json").use { android.os.ParcelFileDescriptor.AutoCloseInputStream(it).bufferedReader().use { reader -> reader.readText() } })
        var initial = ProfileClient.call(ctx, "status")
        val list = initial.getJSONArray("profiles")
        val original = (0 until list.length()).map { list.getJSONObject(it) }.first { !it.getString("name").startsWith("Shelf ") }.getString("id")
        val abandoned = (0 until list.length()).map { list.getJSONObject(it) }.filter { it.getString("name").startsWith("Shelf ") }
        for (entry in abandoned) { val id = entry.getString("id"); ProfileClient.call(ctx, "switch", JSONObject().put("id", id)); ShelfStore(ctx, id).disconnect() }
        ProfileClient.call(ctx, "switch", JSONObject().put("id", original))
        for (entry in abandoned) ProfileClient.call(ctx, "delete", JSONObject().put("id", entry.getString("id")))
        initial = ProfileClient.call(ctx, "status")
        val originalIds = (0 until initial.getJSONArray("profiles").length()).map { initial.getJSONArray("profiles").getJSONObject(it).getString("id") }.toSet()
        val added = mutableListOf<String>()
        try {
            for (role in listOf("a", "b")) {
                val after = ProfileClient.call(ctx, "add", JSONObject().put("name", "Shelf ${role.uppercase()}").put("color", -10453628)).getJSONArray("profiles")
                val id = (0 until after.length()).map { after.getJSONObject(it).getString("id") }.single { it !in originalIds && it !in added }
                added += id
                ProfileClient.call(ctx, "switch", JSONObject().put("id", id)); Thread.sleep(1500)
                val store = ShelfStore(ctx, id)
                assertNull(store.account()); assertTrue(store.data().empty)
                SharedState.write(ctx, "language", "en"); SharedState.write(ctx, "theme", "dark")
                ctx.startActivity(Intent(ctx, JellyfinConnectActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                Thread.sleep(500); click("Enter server address")
                waitFor("Server input missing") { tree().any { it.isEditable } }
                tree().first { it.isEditable }.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, fixture.getString("server")) })
                click("Done", "Fertig")
                click("Quick Connect")
                waitFor("Quick Connect code missing") { tree().any { it.text?.toString()?.matches(Regex("[0-9]{6}")) == true } }
                val code = tree().first { it.text?.toString()?.matches(Regex("[0-9]{6}")) == true }.text.toString()
                status("quick-connect-$role")
                Thread.sleep(2500)
                val user = fixture.getJSONObject(role)
                JellyfinApi(fixture.getString("server"), "shelf-phone", fixture.getString("admin_token")).json("/QuickConnect/Authorize?code=$code&userId=${user.getString("user_id")}", JSONObject())
                waitFor("Quick Connect token not saved") { store.account() != null }
                assertEquals(user.getString("user_id"), store.account()!!.userId)
                waitFor("Connected page missing") { tree().any { it.text?.toString() == "Connected as top-shelf-$role" } }
                status("connected-$role"); Thread.sleep(3000)
                val data = JellyfinContentSource(ctx, store).refresh()
                assertEquals(user.getString("resume_item"), data.data.resume.first().id)
                assertTrue("No next episode", data.data.next.isNotEmpty()); assertTrue("No latest items", data.data.latest.isNotEmpty())
                assertNotNull("No hero image", data.hero); assertTrue("No card images", data.images.isNotEmpty())
                ctx.startActivity(Intent(ctx, dev.streamybox.launcher.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                val resume = data.data.resume.first()
                waitFor("Shelf failed to render") { tree().any { it.text?.toString() in setOf(resume.episode, resume.episode.removePrefix("${resume.title} · ")) } }
                status("home-$role"); Thread.sleep(3000)
                if (role == "a") for (language in listOf("en", "de")) for (theme in listOf("dark", "light")) {
                    SharedState.write(ctx, "language", language); SharedState.write(ctx, "theme", theme)
                    ctx.startActivity(Intent(ctx, dev.streamybox.launcher.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    Thread.sleep(4500); status("home-$theme-$language"); Thread.sleep(3000)
                }
                if (role == "a") {
                    for (step in 0..3) { instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_DOWN); Thread.sleep(350) }
                    status("rows-light-de"); Thread.sleep(3000)
                    jellyfin(fixture, user)
                }
                if (role == "b") {
                    val other = ShelfStore(ctx, added.first())
                    assertNull("Inactive profile token leaked", other.account()); assertTrue("Inactive profile shelf leaked", other.data().empty)
                    assertFalse("Inactive writes permitted", runCatching { other.save(data.data) }.isSuccess)
                }
            }
            ProfileClient.call(ctx, "switch", JSONObject().put("id", added.first()))
            val a = ShelfStore(ctx, added.first())
            assertEquals(fixture.getJSONObject("a").getString("user_id"), a.account()!!.userId)
            assertEquals(fixture.getJSONObject("a").getString("resume_item"), a.data().resume.first().id)
            status("offline-start"); Thread.sleep(1500)
            val offline = JellyfinContentSource(ctx, a).refresh()
            assertTrue("Server outage not detected", offline.offline)
            assertEquals(a.data(), offline.data); assertNotNull("Cached hero missing offline", offline.hero)
            ctx.startActivity(Intent(ctx, dev.streamybox.launcher.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            val cached = offline.data.resume.first()
            waitFor("Offline cached hero did not render") { tree().any { it.text?.toString() in setOf(cached.episode, cached.episode.removePrefix("${cached.title} · ")) } }
            Thread.sleep(1500); status("offline"); Thread.sleep(3000); status("offline-end"); Thread.sleep(1500)
            ctx.startActivity(Intent(ctx, JellyfinConnectActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            click("Von Startseite trennen", "Disconnect from Home screen"); click("Von Startseite trennen", "Disconnect from Home screen")
            waitFor("Sign-out did not remove credentials") { a.account() == null }
            assertTrue(a.data().empty)
            status("signed-out")
        } finally {
            for (id in added) { ProfileClient.call(ctx, "switch", JSONObject().put("id", id)); ShelfStore(ctx, id).disconnect() }
            ProfileClient.call(ctx, "switch", JSONObject().put("id", original))
            for (id in added) ProfileClient.call(ctx, "delete", JSONObject().put("id", id))
        }
    }
    private fun jellyfin(fixture: JSONObject, user: JSONObject) {
        val item = user.getString("resume_item")
        ctx.startActivity(Intent(Intent.ACTION_MAIN).setClassName("org.jellyfin.androidtv", "org.jellyfin.androidtv.ui.startup.StartupActivity").putExtra("ItemId", item).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        waitFor("Jellyfin did not start") { tree().any { it.packageName?.toString() == "org.jellyfin.androidtv" } }
        Thread.sleep(2000)
        val manual = tree().firstOrNull { it.viewIdResourceName?.endsWith("/enter_server_address") == true }
        if (manual != null) {
            assertTrue(manual.performAction(AccessibilityNodeInfo.ACTION_CLICK))
            waitFor("Jellyfin server input missing") { tree().any { it.isEditable } }
            tree().first { it.isEditable }.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, fixture.getString("server")) })
            waitFor("Jellyfin connect button missing") { tree().any { it.viewIdResourceName?.endsWith("/confirm") == true } }
            tree().first { it.viewIdResourceName?.endsWith("/confirm") == true }.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        Thread.sleep(2000)
        if (tree().none { it.text?.toString()?.contains("Arrival") == true }) {
            waitFor("Jellyfin user card missing") { tree().any { it.text?.toString() == "top-shelf-a" } }
            var node: AccessibilityNodeInfo? = tree().first { it.text?.toString() == "top-shelf-a" }; var card: AccessibilityNodeInfo? = null
            while (node != null) { if (node.isFocusable && node.isClickable) card = node; node = node.parent }
            card?.performAction(AccessibilityNodeInfo.ACTION_FOCUS); instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_CENTER)
            waitFor("Official Jellyfin Quick Connect code missing") { tree().any { it.text?.toString()?.replace(" ", "")?.matches(Regex("[0-9]{6}")) == true } }
            val code = tree().first { it.text?.toString()?.replace(" ", "")?.matches(Regex("[0-9]{6}")) == true }.text.toString().replace(" ", "")
            JellyfinApi(fixture.getString("server"), "shelf-phone", fixture.getString("admin_token")).json("/QuickConnect/Authorize?code=$code&userId=${user.getString("user_id")}", JSONObject())
        }
        waitFor("Jellyfin did not open Arrival details") { tree().any { it.packageName?.toString() == "org.jellyfin.androidtv" && it.text?.toString()?.contains("Arrival") == true } }
        ctx.startActivity(Intent(ctx, dev.streamybox.launcher.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        click("Resume", "Fortsetzen")
        waitFor("Shelf handoff did not open exact Jellyfin item") { tree().any { it.packageName?.toString() == "org.jellyfin.androidtv" && it.text?.toString()?.contains("Arrival") == true } }
        status("jellyfin-detail"); Thread.sleep(3000)
    }

}

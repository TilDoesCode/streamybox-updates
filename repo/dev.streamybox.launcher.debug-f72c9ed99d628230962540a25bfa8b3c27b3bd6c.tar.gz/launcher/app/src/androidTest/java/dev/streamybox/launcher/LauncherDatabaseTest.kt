package dev.streamybox.launcher

import android.test.AndroidTestCase

@Suppress("DEPRECATION")
class LauncherDatabaseTest : AndroidTestCase() {
    fun testPinOrderAndEmptyStateSurviveReload() {
        val ctx = context.createDeviceProtectedStorageContext()
        val profile="database-test-${java.util.UUID.randomUUID()}"
        val apps = listOf(AppEntry("org.smarttube.stable", "SmartTube"), AppEntry("org.jellyfin.androidtv", "Jellyfin"))
        LauncherDatabase(ctx,profile).use { db ->
            assertEquals(listOf("org.smarttube.stable", "org.jellyfin.androidtv"), db.synchronize(apps))
            db.savePins(listOf("org.jellyfin.androidtv", "org.smarttube.stable"))
        }
        LauncherDatabase(ctx,profile).use { db ->
            assertEquals(listOf("org.jellyfin.androidtv", "org.smarttube.stable"), db.synchronize(apps))
            db.savePins(emptyList())
        }
        LauncherDatabase(ctx,profile).use { db -> assertTrue(db.synchronize(apps).isEmpty()) }
        ctx.deleteDatabase("streamybox-$profile.db")
    }
    fun testProfilePreferencesAndPinOrderAreIsolated() {
        val ctx=context.createDeviceProtectedStorageContext()
        val a="database-test-${java.util.UUID.randomUUID()}";val b="database-test-${java.util.UUID.randomUUID()}"
        val appA="org.smarttube.stable";val appB="org.jellyfin.androidtv"
        val prefsA=dev.streamybox.profiles.contract.ProfileClient.preferences(ctx,a)
        val prefsB=dev.streamybox.profiles.contract.ProfileClient.preferences(ctx,b)
        try {
            assertTrue(prefsA.edit().putBoolean("light",true).putString("language","de").putString("motion","reduced").putStringSet("hidden",setOf(appA)).commit())
            assertTrue(prefsB.edit().putBoolean("light",false).putString("language","en").putString("motion","off").putStringSet("hidden",setOf(appB)).commit())
            LauncherDatabase(ctx,a).use { it.savePins(listOf(appB,appA)) }
            LauncherDatabase(ctx,b).use { it.savePins(listOf(appA)) }
            LauncherDatabase(ctx,a).use { assertEquals(listOf(appB,appA),it.readPins()) }
            LauncherDatabase(ctx,b).use { assertEquals(listOf(appA),it.readPins()) }
            assertEquals("de",prefsA.getString("language",null));assertEquals("en",prefsB.getString("language",null))
            assertTrue(prefsA.getBoolean("light",false));assertFalse(prefsB.getBoolean("light",true))
            assertEquals("reduced",prefsA.getString("motion",null));assertEquals("off",prefsB.getString("motion",null))
            assertEquals(setOf(appA),prefsA.getStringSet("hidden",emptySet()));assertEquals(setOf(appB),prefsB.getStringSet("hidden",emptySet()))
        } finally {
            prefsA.edit().clear().commit();prefsB.edit().clear().commit()
            ctx.deleteDatabase("streamybox-$a.db");ctx.deleteDatabase("streamybox-$b.db")
        }
    }
    fun testCuratedCatalogOverridesAreProfileScoped() {
        val ctx=context.createDeviceProtectedStorageContext()
        val a="catalog-test-${java.util.UUID.randomUUID()}";val b="catalog-test-${java.util.UUID.randomUUID()}"
        val prefsA=dev.streamybox.profiles.contract.ProfileClient.preferences(ctx,a)
        val prefsB=dev.streamybox.profiles.contract.ProfileClient.preferences(ctx,b)
        try {
            assertTrue(AppCatalog(ctx,a).hidden("dev.streamybox.diag"))
            assertTrue(prefsA.edit().putStringSet("shown",setOf("dev.streamybox.diag")).putStringSet("hidden",setOf("org.jellyfin.androidtv")).commit())
            assertFalse(AppCatalog(ctx,a).hidden("dev.streamybox.diag"))
            assertTrue(AppCatalog(ctx,b).hidden("dev.streamybox.diag"))
            assertTrue(AppCatalog(ctx,a).hidden("org.jellyfin.androidtv"))
            assertFalse(AppCatalog(ctx,b).hidden("org.jellyfin.androidtv"))
        } finally { prefsA.edit().clear().commit();prefsB.edit().clear().commit() }
    }

}

@file:Suppress("DEPRECATION")
package dev.streamybox.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.test.InstrumentationTestCase
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import dev.streamybox.design.Glyph
import dev.streamybox.design.NetworkTransport
import dev.streamybox.design.TvDesign
import dev.streamybox.design.avatar
import java.io.File

/** Capture scenario (not part of the suite): top-bar status cluster per transport, since emulators have no Ethernet. */
class NetworkGlyphSheet : InstrumentationTestCase() {
    fun testRender() {
        val ctx = instrumentation.targetContext
        val out = File(ctx.filesDir, "glyph-sheet").apply { mkdirs() }
        for (light in listOf(false, true)) instrumentation.runOnMainSync {
            val ui = TvDesign(ctx, light)
            val sheet = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = ui.backdrop(); setPadding(ui.dp(32f), ui.dp(24f), ui.dp(32f), ui.dp(24f)) }
            for ((transport, label) in listOf(NetworkTransport.ETHERNET to "Ethernet", NetworkTransport.WIFI to "WLAN", NetworkTransport.OFFLINE to "Offline")) {
                val cluster = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(ui.dp(18f), ui.dp(8f), ui.dp(18f), ui.dp(8f)); background = ui.shape(ui.surface, TvDesign.PILL) }
                cluster.addView(ImageView(ctx).apply { setImageDrawable(Glyph(transport.glyph, ui.muted)) }, LinearLayout.LayoutParams(ui.dp(20f), ui.dp(20f)))
                cluster.addView(ui.text("11:58", 17f, ui.foreground, weight = 450), LinearLayout.LayoutParams(-2, -2).apply { marginStart = ui.dp(12f) })
                cluster.addView(ui.avatar("S", -7559681, 32f, 14f), LinearLayout.LayoutParams(ui.dp(32f), ui.dp(32f)).apply { marginStart = ui.dp(15f) })
                val column = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
                column.addView(cluster)
                column.addView(ui.text(label, 13f, ui.muted), LinearLayout.LayoutParams(-2, -2).apply { topMargin = ui.dp(10f) })
                column.addView(ImageView(ctx).apply { setImageDrawable(Glyph(transport.glyph, ui.foreground)) }, LinearLayout.LayoutParams(ui.dp(64f), ui.dp(64f)).apply { topMargin = ui.dp(14f) })
                sheet.addView(column, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = ui.dp(40f) })
            }
            sheet.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            sheet.layout(0, 0, sheet.measuredWidth, sheet.measuredHeight)
            val image = Bitmap.createBitmap(sheet.measuredWidth, sheet.measuredHeight, Bitmap.Config.ARGB_8888)
            sheet.draw(Canvas(image))
            File(out, if (light) "light.png" else "dark.png").outputStream().use { image.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
    }
}

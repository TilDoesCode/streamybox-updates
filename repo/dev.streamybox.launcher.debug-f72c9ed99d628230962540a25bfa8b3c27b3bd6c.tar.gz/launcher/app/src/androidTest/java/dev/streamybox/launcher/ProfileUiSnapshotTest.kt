@file:Suppress("DEPRECATION")
package dev.streamybox.launcher

import android.test.InstrumentationTestCase
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject
import org.json.JSONArray

class ProfileUiSnapshotTest : InstrumentationTestCase() {
    fun testSnapshotWithoutIdleWait() {
        fun snapshot(node: AccessibilityNodeInfo): JSONObject {
            val children=JSONArray()
            for(index in 0 until node.childCount)node.getChild(index)?.let { children.put(snapshot(it)) }
            return JSONObject().put("text",node.text?.toString() ?: "").put("focused",node.isFocused).put("children",children)
        }
        instrumentation.targetContext.startActivity(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_HOME)
            .setClassName(instrumentation.targetContext.packageName, "dev.streamybox.launcher.MainActivity").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        Thread.sleep(600)
        val automation=instrumentation.uiAutomation
        var node=automation.rootInActiveWindow
        val deadline=android.os.SystemClock.elapsedRealtime()+3000
        while(node==null && android.os.SystemClock.elapsedRealtime()<deadline) { Thread.sleep(50); node=automation.rootInActiveWindow }
        val active=requireNotNull(node)
        instrumentation.sendStatus(0,android.os.Bundle().apply { putString("stream","PROFILE_UI:"+android.util.Base64.encodeToString(snapshot(active).toString().toByteArray(),android.util.Base64.NO_WRAP)) })
    }
}

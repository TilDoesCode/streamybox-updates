@file:Suppress("DEPRECATION")
package dev.streamybox.launcher

import android.app.Instrumentation
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import dev.streamybox.profiles.contract.ProfileClient

internal object LauncherTestHome {
    private fun field(name: String) = MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }
    private val loading = field("loading")
    private val resumed = field("resumed")
    private val profile = field("profileId")
    private val signature = field("signature")
    private val currentSignature = MainActivity::class.java.getDeclaredMethod("signature").apply { isAccessible = true }

    fun open(instrumentation: Instrumentation) {
        val ctx = instrumentation.targetContext
        val status = requireNotNull(ProfileClient.status(ctx))
        if (status.optBoolean("pending")) ProfileClient.call(ctx, "switch", org.json.JSONObject().put("id", status.getString("current")))
        val monitor = instrumentation.addMonitor(MainActivity::class.java.name, null, false)
        try {
            ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setClass(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            await(instrumentation) { monitor.lastActivity as? MainActivity }
        } finally { instrumentation.removeMonitor(monitor) }
    }

    fun await(instrumentation: Instrumentation, timeoutMs: Long = 15000, activity: () -> MainActivity?) {
        val ctx = instrumentation.targetContext
        val expectedProfile = ProfileClient.current(ctx)
        val expectedLanguage = ProfileClient.preferences(ctx, expectedProfile).getString("language", "en")
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        var stableSince = 0L
        var previousActivity: MainActivity? = null
        var previousScene: View? = null
        while (SystemClock.uptimeMillis() < deadline) {
            var ready = false
            var screen: MainActivity? = null
            var scene: View? = null
            instrumentation.runOnMainSync {
                screen = activity()
                screen?.let {
                    if (it.isDestroyed || it.isChangingConfigurations) return@let
                    scene = (it.findViewById<ViewGroup>(android.R.id.content)?.getChildAt(0) as? ViewGroup)?.getChildAt(0)
                    ready = !it.isDestroyed && !it.isChangingConfigurations && it.hasWindowFocus() && resumed.getBoolean(it) && !loading.getBoolean(it) &&
                        profile.get(it) == expectedProfile && it.resources.configuration.locales[0].language == expectedLanguage &&
                        scene?.isAttachedToWindow == true && (scene?.width ?: 0) > 0 && it.currentFocus != null && signature.get(it) == currentSignature.invoke(it)
                }
            }
            val now = SystemClock.uptimeMillis()
            if (!ready) stableSince = 0L
            else if (stableSince == 0L || screen !== previousActivity || scene !== previousScene) stableSince = now
            if (stableSince > 0 && now - stableSince >= 350) return
            previousActivity = screen
            previousScene = scene
            Thread.sleep(50)
        }
        throw AssertionError("HOME did not settle: profile=$expectedProfile language=$expectedLanguage activity=$previousActivity scene=$previousScene")
    }
}

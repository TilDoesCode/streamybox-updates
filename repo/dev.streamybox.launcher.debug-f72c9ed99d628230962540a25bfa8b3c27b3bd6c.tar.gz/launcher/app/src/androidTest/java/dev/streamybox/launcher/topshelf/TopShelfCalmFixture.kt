@file:Suppress("DEPRECATION")
package dev.streamybox.launcher.topshelf

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.test.InstrumentationTestCase
import dev.streamybox.profiles.contract.ProfileClient
import java.io.ByteArrayOutputStream

/** Evidence fixture (not in the regression suite): seeds an offline Top Shelf for the current profile; testClear removes it. */
class TopShelfCalmFixture : InstrumentationTestCase() {
    private val ctx get() = instrumentation.targetContext
    private fun store() = ShelfStore(ctx, ProfileClient.current(ctx))
    private fun art(top: Int, bottom: Int, glow: Int, width: Int): ByteArray {
        val bitmap = Bitmap.createBitmap(width, width * 9 / 16, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap); val w = bitmap.width.toFloat(); val h = bitmap.height.toFloat()
        canvas.drawPaint(Paint().apply { shader = LinearGradient(0f, 0f, w, h, top, bottom, Shader.TileMode.CLAMP) })
        canvas.drawPaint(Paint().apply { shader = RadialGradient(w * .7f, h * .35f, w * .45f, glow, 0, Shader.TileMode.CLAMP) })
        return ByteArrayOutputStream().also { bitmap.compress(Bitmap.CompressFormat.JPEG, 88, it) }.toByteArray()
    }
    fun testSeed() {
        val store = store(); assertTrue("profile not active", store.active())
        val account = JellyfinAccount("http://127.0.0.1:9", "0123456789abcdef0123456789abcdef", "Demo", "fixturetoken", "streamyboxfixture")
        store.connect(account)
        val palette = listOf(Triple(0xFF1B2A4A, 0xFF0B0F1A, 0xAA4F8DFF), Triple(0xFF3A1C2E, 0xFF0E0A12, 0xAAFF6F7D), Triple(0xFF183A2F, 0xFF07110D, 0xAA5BE3A4), Triple(0xFF3A2E14, 0xFF110D05, 0xAAFFC35B))
        fun item(i: Int, title: String, line: String, position: Long) = ShelfItem("%032x".format(0xA0 + i), title, line, position, 2_640_000L, "%032x".format(0xA0 + i), "Backdrop", "t$i")
        val resume = listOf(item(1, "Nordlicht", "S1 · E4 · Polarnacht", 1_500_000L), item(2, "Die Küste", "Dokumentation", 600_000L))
        val next = listOf(item(3, "Stadt am Fluss", "S2 · E1 · Neubeginn", 0L), item(4, "Horizont", "S1 · E7 · Dämmerung", 0L))
        val latest = listOf(item(5, "Das Archiv", "Film · 2026", 0L), item(6, "Wellen", "Konzertfilm", 0L), item(7, "Glühwürmchen", "Kurzfilm", 0L))
        store.save(ShelfData(resume, next, latest))
        val api = JellyfinApi(account.server, account.deviceId, account.token)
        for ((index, entry) in (resume + next + latest).withIndex()) {
            val (top, bottom, glow) = palette[index % palette.size]
            store.cache().put(api.image(entry, 400), art(top.toInt(), bottom.toInt(), glow.toInt(), 400))
            if (entry in resume) store.cache().put(api.image(entry, 1280), art(top.toInt(), bottom.toInt(), glow.toInt(), 1280))
        }
    }
    fun testClear() { store().disconnect() }
}

package dev.streamybox.launcher

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyServiceGuardTest {
    private val bound = listOf("com.example/.Reader", "dev.streamybox.settings/.SwitcherKeyService")
    @Test fun provisionsOnlyWhenTheKeyServiceIsMissing() {
        assertFalse(KeyServiceGuard.needed(bound, 100_000, 0))
        assertFalse(KeyServiceGuard.needed(listOf("dev.streamybox.settings/dev.streamybox.settings.SwitcherKeyService"), 100_000, 0))
        assertTrue(KeyServiceGuard.needed(emptyList(), 100_000, 0))
        assertTrue(KeyServiceGuard.needed(listOf("com.example/.Reader"), 100_000, 0))
    }
    @Test fun rateLimitsRepeatedResumes() {
        assertFalse(KeyServiceGuard.needed(emptyList(), 10_000, 0))
        assertTrue(KeyServiceGuard.needed(emptyList(), KeyServiceGuard.MIN_INTERVAL, 0))
        assertTrue(KeyServiceGuard.needed(emptyList(), 0, Long.MIN_VALUE / 2))
    }
}

package dev.streamybox.launcher

import org.junit.Assert.*
import org.junit.Test

class AppCurationTest {
    @Test fun stockAndDeveloperAppsAreHiddenWithoutHidingMedia() {
        listOf("com.android.settings", "org.chromium.chrome.stable", "com.android.webview.shell",
            "dev.streamybox.diag", "org.jellyfin.androidtv.debug", "com.rockchip.devicetest", "dev.streamybox.profiletest", "dev.streamybox.vaultprobe").forEach {
            assertTrue(it, AppCuration.hidden(it, emptySet(), emptySet()))
        }
        listOf("dev.streamybox.settings", "org.jellyfin.androidtv", "org.smarttube.stable", "org.xbmc.kodi", "ordinary.sideload").forEach {
            assertFalse(it, AppCuration.hidden(it, emptySet(), emptySet()))
        }
    }
    @Test fun retainedBspAndEmulatorServicesHaveNoDefaultTiles() {
        listOf("com.android.captiveportallogin", "com.android.phone", "com.android.hotspot2.osulogin",
            "com.google.android.gms", "com.android.printspooler").forEach {
            assertTrue(it, AppCuration.hidden(it, emptySet(), emptySet()))
            assertFalse(it, AppCuration.hidden(it, emptySet(), setOf(it)))
        }
        assertFalse(AppCuration.hidden("org.smarttube.stable", emptySet(), emptySet()))
    }
    @Test fun explicitShowAndHidePersistOverDefaults() {
        assertFalse(AppCuration.hidden("dev.streamybox.diag", emptySet(), setOf("dev.streamybox.diag")))
        assertTrue(AppCuration.hidden("dev.streamybox.diag", setOf("dev.streamybox.diag"), setOf("dev.streamybox.diag")))
        assertTrue(AppCuration.hidden("ordinary.sideload", setOf("ordinary.sideload"), emptySet()))
    }
}

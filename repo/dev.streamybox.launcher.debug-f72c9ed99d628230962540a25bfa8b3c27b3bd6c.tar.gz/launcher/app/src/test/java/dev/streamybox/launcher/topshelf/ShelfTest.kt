package dev.streamybox.launcher.topshelf

import org.json.JSONObject
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files

class ShelfTest {
    @Test fun parsesResumeTicksAndEpisodeImages() {
        val data = JSONObject("""{"Items":[{"Id":"0123456789abcdef0123456789abcdef","Name":"Arrival","SeriesName":"Our series","Type":"Episode","ParentIndexNumber":2,"IndexNumber":3,"RunTimeTicks":600000000,"UserData":{"PlaybackPositionTicks":300000000},"ParentBackdropItemId":"abcdef0123456789abcdef0123456789","ParentBackdropImageTags":["art"]},{"Id":"bad"}]}""")
        val item = parseItems(data).single()
        assertEquals(30000L, item.position); assertEquals(60000L, item.duration); assertEquals(.5, item.progress, 0.0)
        assertEquals("Our series · S2 · E3 · Arrival", item.episode); assertEquals("Backdrop", item.imageType)
        assertEquals(item, ShelfData.parse(ShelfData(resume = listOf(item)).json()).resume.single())
    }
    @Test fun capsResponseAndRejectsUnsafeServerUrls() {
        val items = JSONArray((0..99).map { JSONObject().put("Id", "%032x".format(it)).put("Name", "Item") })
        assertEquals(24, parseItems(items).size)
        for (url in listOf("file:///secret", "http://user:pass@host", "http://host/?token=x", "http://host/#x")) assertTrue(runCatching { serverUrl(url) }.isFailure)
        assertEquals("https://media.example/jellyfin", serverUrl("https://media.example/jellyfin/"))
    }
    @Test fun cacheStaysWithinByteAndCountBounds() {
        val root = Files.createTempDirectory("shelf-test").toFile()
        try {
            val cache = ShelfCache(root, 20, 2)
            repeat(10) { cache.put("$it", ByteArray(9)); assertTrue(root.listFiles()!!.size <= 2); assertTrue(root.listFiles()!!.sumOf { f -> f.length() } <= 20) }
            assertNull(cache.put("too-large", ByteArray(21)))
            assertNull(cache.get("../../escape"))
        } finally { root.deleteRecursively() }
    }
}

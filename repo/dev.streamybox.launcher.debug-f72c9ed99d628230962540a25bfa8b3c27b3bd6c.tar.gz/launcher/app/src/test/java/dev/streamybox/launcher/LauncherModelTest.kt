package dev.streamybox.launcher

import org.junit.Assert.*
import org.junit.Test

class LauncherModelTest {
    @Test fun storePinsFollowMediaAppsAndUseTheInstalledLabels() {
        val entries = listOf(AppEntry("com.aurora.store", "Aurora Store"), AppEntry("org.fdroid.fdroid", "F-Droid"),
            AppEntry("org.smarttube.stable", "SmartTube"), AppEntry("org.jellyfin.androidtv", "Jellyfin"))
        assertEquals(listOf("org.smarttube.stable", "org.jellyfin.androidtv", "org.fdroid.fdroid", "com.aurora.store"), AppOrder.defaults(entries))
        assertEquals(listOf("YouTube", "Jellyfin", "F-Droid", "Aurora Store"), AppOrder.defaults(entries).map { pkg -> entries.first { it.packageName == pkg }.label })
    }
    @Test fun streamarrIsPinnedOnlyWhenInstalled() {
        assertEquals(listOf("org.jellyfin.androidtv", "dev.streamarr.app"), AppOrder.defaults(listOf(
            AppEntry("dev.streamarr.app", "Streamarr"), AppEntry("org.jellyfin.androidtv", "Jellyfin"))))
        assertTrue(AppOrder.defaults(emptyList()).isEmpty())
    }
    @Test fun sortingUsesLabelsAndIncludesNormalApps() {
        val apps = AppOrder.sorted(listOf(AppEntry("b", "beta"), AppEntry("normal.sideload", "Alpha"),
            AppEntry("org.smarttube.stable", "SmartTube"), AppEntry("b", "beta")))
        assertEquals(listOf("Alpha", "beta", "YouTube"), apps.map { it.label })
    }
    @Test fun defaultPinsOnlyInstalledAppsInPriorityOrder() {
        assertEquals(listOf("org.smarttube.stable", "org.jellyfin.androidtv", "dev.streamybox.diag"), AppOrder.defaults(listOf(
            AppEntry("dev.streamybox.launcher.debug", "Streamybox"), AppEntry("dev.streamybox.diag", "Diagnostics"),
            AppEntry("org.jellyfin.androidtv", "Jellyfin"), AppEntry("org.smarttube.stable", "SmartTube"), AppEntry("normal.app", "Normal"))))
        assertTrue(AppOrder.defaults(listOf(AppEntry("normal", "Normal"))).isEmpty())
    }
    @Test fun rowTraversalClampsAndCanReturnToHeader() {
        val cursor = RemoteCursor(1, 4)
        cursor.move(0, 1, listOf(1, 5, 2))
        assertEquals(2, cursor.row); assertEquals(1, cursor.column)
        cursor.move(1, 0, listOf(1, 5, 2)); assertEquals(1, cursor.column)
        cursor.move(0, -1, listOf(1, 5, 2)); cursor.move(0, -1, listOf(1, 5, 2))
        assertEquals(0, cursor.row); assertEquals(0, cursor.column)
    }
    @Test fun gridDoesNotWrapAndClampsIncompleteLastRow() {
        val cursor = RemoteCursor()
        assertEquals(5, cursor.gridMove(5, 1, 0, 8))
        assertEquals(7, cursor.gridMove(4, 0, 1, 8))
        assertEquals(1, cursor.gridMove(7, 0, -1, 8))
        assertEquals(0, cursor.gridMove(0, -1, 0, 8))
    }
}

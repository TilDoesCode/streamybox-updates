package dev.streamybox.launcher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import java.lang.ref.WeakReference

object HomeHealth {
    private var activity = WeakReference<Activity>(null)
    var lastFrame = 0L; private set
    fun resume(value: Activity) {
        activity = WeakReference(value)
        value.window.decorView.postOnAnimation { if (value.hasWindowFocus()) lastFrame = SystemClock.uptimeMillis() }
    }
    fun current(): Activity? = activity.get()
}

class HomeHealthReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "dev.streamybox.action.CHECK_HOME") return
        val activity = HomeHealth.current() ?: return
        if (HomeHealth.lastFrame >= intent.getLongExtra("requested_at", Long.MAX_VALUE)) { resultCode = Activity.RESULT_OK; return }
        val pending = goAsync()
        activity.window.decorView.postOnAnimation {
            pending.resultCode = if (activity.hasWindowFocus() && !activity.isFinishing && !activity.isDestroyed) Activity.RESULT_OK else Activity.RESULT_CANCELED
            pending.finish()
        }
    }
}

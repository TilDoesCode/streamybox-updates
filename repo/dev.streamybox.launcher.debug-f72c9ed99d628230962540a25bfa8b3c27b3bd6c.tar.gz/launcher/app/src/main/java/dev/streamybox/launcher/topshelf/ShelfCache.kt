package dev.streamybox.launcher.topshelf

import java.io.File
import java.security.MessageDigest

internal class ShelfCache(private val directory: File, private val maxBytes: Long = 48L * 1024 * 1024, private val maxFiles: Int = 120) {
    init { require(maxBytes > 0 && maxFiles > 0); check(directory.isDirectory || directory.mkdirs()) }
    private fun file(key: String) = File(directory, MessageDigest.getInstance("SHA-256").digest(key.toByteArray()).joinToString("") { "%02x".format(it) })
    fun get(key: String): File? = file(key).takeIf { it.isFile }?.also { it.setLastModified(System.currentTimeMillis()) }
    fun put(key: String, bytes: ByteArray): File? {
        if (bytes.size > maxBytes) return null
        val destination = file(key); val temp = File(directory, destination.name + ".tmp")
        temp.outputStream().use { it.write(bytes) }; check(temp.renameTo(destination)); trim()
        return destination.takeIf { it.exists() }
    }
    fun trim() {
        val files = directory.listFiles().orEmpty().filter { it.isFile }.sortedByDescending { it.lastModified() }
        var size = 0L
        files.forEachIndexed { index, file -> size += file.length(); if (index >= maxFiles || size > maxBytes || file.name.endsWith(".tmp")) file.delete() }
    }
}

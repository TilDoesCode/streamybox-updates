package dev.streamybox.launcher

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class LauncherDatabase(context: Context, profile: String = dev.streamybox.profiles.contract.ProfileClient.current(context)) : SQLiteOpenHelper(context, if (profile == "default") "streamybox.db" else "streamybox-$profile.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE apps(package TEXT PRIMARY KEY, name TEXT NOT NULL, version TEXT NOT NULL)")
        db.execSQL("CREATE TABLE pins(package TEXT PRIMARY KEY, position INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE config(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
    @Synchronized fun synchronize(apps: List<AppEntry>): List<String> {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("apps", null, null)
            apps.forEach { app -> db.insertOrThrow("apps", null, ContentValues().apply {
                put("package", app.packageName); put("name", app.name); put("version", app.version)
            }) }
            val initialized = db.rawQuery("SELECT value FROM config WHERE key='pinsInitialized'", null).use { it.moveToFirst() }
            if (!initialized) {
                writePins(db, AppOrder.defaults(apps))
                db.execSQL("INSERT INTO config VALUES('pinsInitialized', '1')")
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return db.rawQuery("SELECT package FROM pins ORDER BY position", null).use { cursor ->
            buildList { while (cursor.moveToNext()) add(cursor.getString(0)) }
        }
    }
    @Synchronized fun readPins(): List<String> = readableDatabase.rawQuery("SELECT package FROM pins ORDER BY position", null).use { cursor ->
        buildList { while (cursor.moveToNext()) add(cursor.getString(0)) }
    }
    @Synchronized fun savePins(pins: List<String>) {
        val db = writableDatabase
        db.beginTransaction()
        try { writePins(db, pins); db.setTransactionSuccessful() } finally { db.endTransaction() }
    }
    private fun writePins(db: SQLiteDatabase, pins: List<String>) {
        db.delete("pins", null, null)
        pins.forEachIndexed { index, pkg -> db.insertOrThrow("pins", null, ContentValues().apply {
            put("package", pkg); put("position", index)
        }) }
    }
}

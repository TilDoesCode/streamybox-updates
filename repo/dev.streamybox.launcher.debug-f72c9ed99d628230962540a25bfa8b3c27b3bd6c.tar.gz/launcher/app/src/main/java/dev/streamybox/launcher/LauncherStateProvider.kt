@file:Suppress("ApplySharedPref")
package dev.streamybox.launcher

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Bundle

class LauncherStateProvider : ContentProvider() {
    override fun onCreate() = true
    @Synchronized override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        val ctx = requireNotNull(context)
        ctx.enforceCallingOrSelfPermission("dev.streamybox.permission.LAUNCHER_STATE", "Launcher state requires our app signature")
        val profile = dev.streamybox.profiles.contract.ProfileClient.current(ctx)
        val prefs = dev.streamybox.profiles.contract.ProfileClient.preferences(ctx, profile)
        val result = Bundle()
        when (method) {
            "catalog" -> result.putString("apps", org.json.JSONArray(AppCatalog(ctx, profile).applications().map { org.json.JSONObject().put("package", it.packageName).put("name", it.name) }).toString())
            "read" -> { result.putBoolean("light", prefs.getBoolean("light", false)); result.putString("language", prefs.getString("language", "en")); result.putString("motion", prefs.getString("motion", "full")); result.putString("home_layout", prefs.getString("home_layout", HomeLayout.FULL)); LauncherDatabase(ctx, profile).use { result.putStringArrayList("pins", ArrayList(it.readPins())) }; result.putStringArrayList("hidden", ArrayList(AppCatalog(ctx, profile).applications(true).filter { AppCatalog(ctx, profile).hidden(it.packageName) }.map { it.packageName })) }
            "theme" -> { require(arg in listOf("light", "dark")); prefs.edit().putBoolean("light", arg == "light").commit() }
            "motion" -> { require(arg in listOf("full", "reduced", "off")); prefs.edit().putString("motion", arg).commit() }
            "home_layout" -> { require(arg in HomeLayout.values); prefs.edit().putString("home_layout", arg).commit() }
            "language" -> { require(arg in listOf("de", "en")); prefs.edit().putString("language", arg).commit() }
            "pin", "unpin" -> {
                require(arg != null && arg.matches(Regex("[a-zA-Z0-9_.]+")))
                LauncherDatabase(ctx, profile).use { db ->
                    val pins = db.synchronize(AppCatalog(ctx, profile).applications()).toMutableList()
                    if (method == "pin" && arg !in pins) pins.add(arg) else if (method == "unpin") pins.remove(arg)
                    db.savePins(pins)
                }
            }
            "hide", "show" -> {
                require(arg != null && arg.matches(Regex("[a-zA-Z0-9_.]+")))
                val hidden = prefs.getStringSet("hidden", emptySet())!!.toMutableSet()
                val shown = prefs.getStringSet("shown", emptySet())!!.toMutableSet()
                if (method == "hide") { hidden.add(arg); shown.remove(arg) } else { hidden.remove(arg); shown.add(arg) }
                prefs.edit().putStringSet("hidden", hidden).putStringSet("shown", shown).commit()
            }
            else -> error("Unknown setting")
        }
        result.putBoolean("ok", true)
        return result
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = null
    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?) = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?) = 0
}

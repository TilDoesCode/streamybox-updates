package dev.streamybox.launcher.topshelf

import org.json.JSONArray
import org.json.JSONObject
import java.net.URI

internal data class JellyfinAccount(val server: String, val userId: String, val name: String, val token: String, val deviceId: String) {
    fun json() = JSONObject().put("server", server).put("userId", userId).put("name", name).put("token", token).put("deviceId", deviceId)
    companion object {
        fun parse(json: JSONObject) = JellyfinAccount(serverUrl(json.getString("server")), itemId(json.getString("userId")), json.getString("name"), json.getString("token").also { require(it.matches(Regex("[a-zA-Z0-9_-]{1,512}"))) }, json.getString("deviceId"))
    }
}
internal data class ShelfItem(val id: String, val title: String, val episode: String, val position: Long, val duration: Long, val imageId: String, val imageType: String, val imageTag: String) {
    val progress get() = if (duration > 0) (position.toDouble() / duration).coerceIn(0.0, 1.0) else 0.0
    fun json() = JSONObject().put("Id", id).put("Name", title).put("EpisodeLine", episode).put("RunTimeTicks", duration * 10000).put("UserData", JSONObject().put("PlaybackPositionTicks", position * 10000)).put("CachedImageId", imageId).put("CachedImageType", imageType).put("CachedImageTag", imageTag)
}
internal data class ShelfData(val resume: List<ShelfItem> = emptyList(), val next: List<ShelfItem> = emptyList(), val latest: List<ShelfItem> = emptyList()) {
    val empty get() = resume.isEmpty() && next.isEmpty() && latest.isEmpty()
    val items get() = (resume + next + latest).distinctBy { it.id }
    fun json() = JSONObject().put("resume", JSONArray(resume.map { it.json() })).put("next", JSONArray(next.map { it.json() })).put("latest", JSONArray(latest.map { it.json() }))
    companion object { fun parse(json: JSONObject) = ShelfData(parseItems(json.optJSONArray("resume") ?: JSONArray()), parseItems(json.optJSONArray("next") ?: JSONArray()), parseItems(json.optJSONArray("latest") ?: JSONArray())) }
}
internal fun itemId(value: String): String = value.replace("-", "").lowercase().also { require(it.matches(Regex("[a-f0-9]{32}"))) }
internal fun serverUrl(value: String): String {
    val uri = URI(value.trim().let { if (it.contains("://")) it else "http://$it" })
    require(uri.scheme in listOf("http", "https") && !uri.host.isNullOrEmpty() && uri.userInfo == null && uri.query == null && uri.fragment == null)
    require(uri.port in -1..65535)
    return uri.toASCIIString().trimEnd('/')
}
internal fun parseItems(value: Any): List<ShelfItem> {
    val array = if (value is JSONArray) value else (value as JSONObject).optJSONArray("Items") ?: JSONArray()
    return (0 until minOf(array.length(), 24)).mapNotNull { index -> runCatching {
        val item = array.getJSONObject(index)
        val id = itemId(item.getString("Id"))
        val tags = item.optJSONObject("ImageTags") ?: JSONObject()
        val backdrop = item.optJSONArray("BackdropImageTags")?.optString(0).orEmpty()
        val parentBackdrop = item.optJSONArray("ParentBackdropImageTags")?.optString(0).orEmpty()
        val imageType = when { backdrop.isNotEmpty() || parentBackdrop.isNotEmpty() -> "Backdrop"; tags.has("Thumb") -> "Thumb"; else -> "Primary" }
        val imageId = if (backdrop.isEmpty() && parentBackdrop.isNotEmpty()) itemId(item.getString("ParentBackdropItemId")) else id
        val season = item.optInt("ParentIndexNumber", -1); val episode = item.optInt("IndexNumber", -1)
        val line = item.optString("EpisodeLine").ifEmpty { if (item.optString("Type") == "Episode") listOfNotNull(item.optString("SeriesName").takeIf { it.isNotEmpty() }, if (season >= 0 && episode >= 0) "S$season · E$episode" else null, item.optString("Name").takeIf { it.isNotEmpty() }).joinToString(" · ") else item.optInt("ProductionYear", 0).takeIf { it > 0 }?.toString().orEmpty() }
        ShelfItem(id, item.optString("SeriesName").ifEmpty { item.optString("Name") }, line,
            (item.optJSONObject("UserData")?.optLong("PlaybackPositionTicks", 0) ?: 0).coerceAtLeast(0) / 10000,
            item.optLong("RunTimeTicks", 0).coerceAtLeast(0) / 10000,
            item.optString("CachedImageId").ifEmpty { imageId }, item.optString("CachedImageType").ifEmpty { imageType }, item.optString("CachedImageTag").ifEmpty { if (imageType == "Backdrop") backdrop.ifEmpty { parentBackdrop } else tags.optString(imageType) })
    }.getOrNull() }.distinctBy { it.id }
}

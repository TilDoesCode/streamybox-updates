package dev.streamybox.launcher

import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import dev.streamybox.design.ControllerMonitor
import dev.streamybox.design.ControllerStatusGlyph
import dev.streamybox.design.Fonts
import dev.streamybox.design.TvDesign

class ControllerBadge(context: android.content.Context, ui: TvDesign) : LinearLayout(context) {
    constructor(context: android.content.Context) : this(context, TvDesign(context))
    private val glyph = ControllerStatusGlyph(ui.muted, ui.foreground, ui.background, Fonts.get(context, 700))
    private val image = ImageView(context).apply { setImageDrawable(glyph); scaleType = ImageView.ScaleType.FIT_XY }
    private val monitor = ControllerMonitor(context) { devices ->
        visibility = if (devices.isEmpty()) View.GONE else View.VISIBLE
        glyph.count = if (devices.size >= 2) java.text.NumberFormat.getIntegerInstance(resources.configuration.locales[0]).format(devices.size) else ""
        glyph.low = devices.any { (it.battery ?: 100) <= 15 }
        image.layoutParams = LayoutParams(ui.dp(if (glyph.badged) 24f else 20f), ui.dp(24f))
        contentDescription = context.getString(R.string.controllers_count, devices.size)
    }
    init {
        orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE
        addView(image, LayoutParams(ui.dp(20f), ui.dp(24f)))
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); monitor.start() }
    override fun onDetachedFromWindow() { monitor.close(); super.onDetachedFromWindow() }
}

package dev.streamybox.launcher

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityManager

/** A force-stop of Settings drops its key service (AOSP onHandleForceStop); the launcher asks Settings to re-provision it. */
object KeyServiceGuard {
    private val ids = setOf("dev.streamybox.settings/.SwitcherKeyService", "dev.streamybox.settings/dev.streamybox.settings.SwitcherKeyService")
    const val MIN_INTERVAL = 30_000L
    private var last = Long.MIN_VALUE / 2
    fun needed(enabled: Collection<String>, now: Long, last: Long) = enabled.none { it in ids } && now - last >= MIN_INTERVAL
    fun check(context: Context) {
        val manager = context.getSystemService(AccessibilityManager::class.java) ?: return
        val enabled = runCatching { manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).map { it.id } }.getOrNull() ?: return
        val now = SystemClock.elapsedRealtime()
        if (!needed(enabled, now, last)) return
        last = now
        runCatching { context.sendBroadcast(Intent("dev.streamybox.action.PROVISION_SWITCHER").setClassName("dev.streamybox.settings", "dev.streamybox.settings.SwitcherGuardReceiver").addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)) }
    }
}

package dev.streamybox.launcher

import android.app.PendingIntent
import android.net.Uri

data class PlaybackItem(val id: String, val title: String, val artwork: Uri?, val positionMillis: Long, val durationMillis: Long, val resume: PendingIntent)
interface ContentSource {
    suspend fun continueWatching(): List<PlaybackItem>
    suspend fun nowPlaying(): PlaybackItem?
}
object EmptyContentSource : ContentSource {
    override suspend fun continueWatching() = emptyList<PlaybackItem>()
    override suspend fun nowPlaying(): PlaybackItem? = null
}

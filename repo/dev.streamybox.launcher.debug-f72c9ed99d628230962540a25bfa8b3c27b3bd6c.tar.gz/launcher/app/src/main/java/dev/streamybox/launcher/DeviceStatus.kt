package dev.streamybox.launcher

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import java.net.Inet4Address

data class DeviceStatus(val connected: Boolean, val online: Boolean, val ip: String, val usb: Boolean, val tcp: String, val transport: dev.streamybox.design.NetworkTransport = dev.streamybox.design.NetworkTransport.of(connected, false, true)) {
    companion object {
        fun read(context: Context): DeviceStatus {
            val cm = context.getSystemService(ConnectivityManager::class.java)
            val net = cm.activeNetwork
            val caps = cm.getNetworkCapabilities(net)
            val ip = cm.getLinkProperties(net)?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.address?.hostAddress ?: ""
            return DeviceStatus(caps != null, caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true,
                ip, Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1 ||
                property("sys.usb.config").split(',').contains("adb"), property("service.adb.tcp.port").ifEmpty { property("persist.adb.tcp.port") }, dev.streamybox.design.NetworkTransport.of(caps))
        }
        private fun property(name: String) = runCatching {
            val process = ProcessBuilder("/system/bin/getprop", name).start()
            process.inputStream.bufferedReader().use { it.readText().trim() }
        }.getOrDefault("")
        fun description() = "${Build.MODEL} · ${Build.BOARD}\nAndroid ${Build.VERSION.RELEASE} · ${Build.DISPLAY}"
    }
}

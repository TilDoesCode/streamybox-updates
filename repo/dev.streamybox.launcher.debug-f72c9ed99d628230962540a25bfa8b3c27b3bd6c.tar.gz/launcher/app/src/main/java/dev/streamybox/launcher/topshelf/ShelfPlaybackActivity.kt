package dev.streamybox.launcher.topshelf

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import dev.streamybox.launcher.R
import java.util.concurrent.Executors

internal class ShelfPlaybackActivity : Activity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val profile = intent.getStringExtra("profile") ?: return finish()
        val item = runCatching { itemId(intent.getStringExtra("item").orEmpty()) }.getOrNull() ?: return finish()
        val store = ShelfStore(this, profile)
        worker.execute {
            val account = store.account()
            runOnUiThread {
                if (isDestroyed || account == null || !store.active()) { finish(); return@runOnUiThread }
                Toast.makeText(this, getString(R.string.topshelf_app_hint, account.name), Toast.LENGTH_SHORT).show()
                val target = Intent(Intent.ACTION_MAIN).setClassName("org.jellyfin.androidtv", "org.jellyfin.androidtv.ui.startup.StartupActivity").putExtra("ItemId", item).putExtra("HideSplash", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (runCatching { startActivity(target) }.isFailure) packageManager.getLeanbackLaunchIntentForPackage("org.jellyfin.androidtv")?.let { runCatching { startActivity(it) } }
                finish()
            }
        }
    }
    companion object { private val worker = Executors.newSingleThreadExecutor() }
}

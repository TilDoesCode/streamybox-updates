package dev.streamybox.launcher.topshelf

import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import dev.streamybox.design.TvDesign
import dev.streamybox.launcher.R

/** Quick Connect code block in the pairing-card language: eyebrow, headline, code panel, server and countdown. */
internal object QuickConnectCode {
    fun build(ui: TvDesign, body: LinearLayout, code: String, server: String): TextView {
        val context = ui.context
        body.removeAllViews()
        body.addView(ui.eyebrow("Jellyfin"))
        body.addView(ui.text(context.getString(R.string.topshelf_qc_title), TvDesign.TYPE_H1, weight = 600), LinearLayout.LayoutParams(-2, -2).apply { topMargin = ui.dp(6f) })
        body.addView(ui.text(context.getString(R.string.topshelf_quick_hint), 14.5f, ui.muted).apply { setLineSpacing(0f, 1.2f) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(8f) })
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ui.dp(24f), ui.dp(18f), ui.dp(24f), ui.dp(20f)); background = ui.shape(ui.raised, TvDesign.RADIUS_L, if (ui.light) ui.border else ui.hairline)
        }
        panel.addView(ui.eyebrow(context.getString(R.string.topshelf_qc_code)), LinearLayout.LayoutParams(-2, -2))
        panel.addView(ui.text(code, 64f, weight = 600).apply { fontFeatureSettings = "tnum"; letterSpacing = .2f; gravity = Gravity.CENTER; includeFontPadding = false }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = ui.dp(10f) })
        panel.addView(ui.text(server.removePrefix("https://").removePrefix("http://").trimEnd('/'), 13.5f, ui.faint).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = ui.dp(10f) })
        body.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(22f) })
        val countdown = ui.text("", 13.5f, ui.muted).apply { fontFeatureSettings = "tnum"; gravity = Gravity.CENTER }
        body.addView(countdown, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(12f); bottomMargin = ui.dp(18f) })
        return countdown
    }
}

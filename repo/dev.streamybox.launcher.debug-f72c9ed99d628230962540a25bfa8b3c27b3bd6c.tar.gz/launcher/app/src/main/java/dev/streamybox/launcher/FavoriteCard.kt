package dev.streamybox.launcher

import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import dev.streamybox.design.TvDesign

/** One card language for every favourite: artwork fills the face, an optional mark is centred, the name always sits below. */
internal object FavoriteCard {
    const val MARK = .46f

    class Parts(val root: LinearLayout, val label: TextView)

    /** [art] is a TV banner (real or composed from the icon, [mark] null) or ambience art with a centred [mark]. */
    fun build(ui: TvDesign, face: FrameLayout, row: HomeLayout.Row, name: String, art: Drawable, mark: Drawable?): Parts {
        val context = face.context
        val w = ui.dp(row.width); val h = ui.dp(row.height)
        face.addView(ImageView(context).apply { setImageDrawable(art); scaleType = ImageView.ScaleType.CENTER_CROP }, FrameLayout.LayoutParams(w, h))
        if (mark != null) {
            val size = ui.dp(row.height * MARK)
            face.addView(ImageView(context).apply { setImageDrawable(mark) }, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        }
        val label = ui.text(name, row.label, ui.muted, weight = 600).apply {
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setPadding(ui.dp(2f), 0, ui.dp(2f), 0)
        }
        val root = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false }
        root.addView(face, LinearLayout.LayoutParams(w, h))
        root.addView(label, LinearLayout.LayoutParams(w, ui.dp(row.labelHeight - HomeLayout.Row.LABEL_GAP)).apply { topMargin = ui.dp(HomeLayout.Row.LABEL_GAP) })
        return Parts(root, label)
    }
}

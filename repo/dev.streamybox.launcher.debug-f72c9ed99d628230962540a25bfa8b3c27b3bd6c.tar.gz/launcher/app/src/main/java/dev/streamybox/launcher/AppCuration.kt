package dev.streamybox.launcher

object AppCuration {
    private val stock = setOf("com.android.settings", "com.android.tv.settings", "com.android.documentsui",
        "com.google.android.documentsui", "com.android.webview.shell", "org.chromium.webview_shell",
        "org.chromium.chrome.stable", "com.android.inputmethod.latin", "com.android.launcher3", "com.android.chrome", "com.android.traceur",
        "com.android.rk", "android.rk.RockVideoPlayer", "com.cghs.stresstest", "dev.streamybox.diag",
        "com.google.android.gms", "com.google.android.gsf", "com.android.vending", "dev.streamybox.profiletest", "dev.streamybox.vaultprobe")
    fun hiddenByDefault(pkg: String) = pkg in stock || pkg in BspHiddenApps.packages || pkg.startsWith("com.rockchip.") ||
        pkg.startsWith("android.rockchip.") || listOf(".debug", ".test", ".benchmark", ".development").any { pkg.endsWith(it) } ||
        pkg.startsWith("dev.streamybox.minimalui.")
    fun hidden(pkg: String, hidden: Set<String>, shown: Set<String>) = pkg in hidden || (hiddenByDefault(pkg) && pkg !in shown)
}

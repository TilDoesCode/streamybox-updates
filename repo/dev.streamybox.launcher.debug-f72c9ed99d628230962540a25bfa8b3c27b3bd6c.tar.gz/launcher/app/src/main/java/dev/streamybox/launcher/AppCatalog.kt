// Copyright Étienne Fesser, Oscar Rojas, Arc Launcher contributors; GPL-3.0.
// App discovery and intent fallbacks adapted from Arc Launcher / FLauncher (GPL-3.0).
package dev.streamybox.launcher

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.Settings

class AppCatalog(private val context: Context, private val profile: String = dev.streamybox.profiles.contract.ProfileClient.current(context)) {
    private val pm = context.packageManager
    private val builtIn = setOf("dev.streamybox.profiles", "dev.streamybox.settings")
    fun applications(includeHidden: Boolean = false): List<AppEntry> {
        val activities = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
            .flatMap { pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(it), 0) }
            .map { it.activityInfo }.distinctBy { it.packageName }
        return AppOrder.sorted(activities.filter { it.packageName != context.packageName && it.packageName !in builtIn && (includeHidden || !hidden(it.packageName)) }.map {
            AppEntry(it.packageName, it.loadLabel(pm).toString(),
                pm.getPackageInfo(it.packageName, 0).versionName ?: "",
                it.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0,
                it.applicationInfo.category in setOf(ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_IMAGE) ||
                    dev.streamybox.design.AppIcon.media(dev.streamybox.design.AppIcon.kind(it.packageName)))
        })
    }
    fun hidden(pkg: String): Boolean {
        val prefs = dev.streamybox.profiles.contract.ProfileClient.preferences(context, profile)
        return AppCuration.hidden(pkg, prefs.getStringSet("hidden", emptySet())!!, prefs.getStringSet("shown", emptySet())!!)
    }
    fun launchDeveloper(app: AppEntry) = start(pm.getLeanbackLaunchIntentForPackage(app.packageName) ?: pm.getLaunchIntentForPackage(app.packageName))
    private fun entry(app: AppEntry) = pm.getLeanbackLaunchIntentForPackage(app.packageName) ?: pm.getLaunchIntentForPackage(app.packageName)
    fun icon(app: AppEntry): Drawable? = entry(app)?.let { runCatching { pm.getActivityIcon(it) }.getOrNull() } ?: runCatching { pm.getApplicationIcon(app.packageName) }.getOrNull()
    fun banner(app: AppEntry): Drawable? = pm.getLeanbackLaunchIntentForPackage(app.packageName)?.let { runCatching { pm.getActivityBanner(it) }.getOrNull() } ?: runCatching { pm.getApplicationBanner(app.packageName) }.getOrNull()
    fun launch(app: AppEntry, options: Bundle? = null): Boolean = if (app.packageName in listOf("com.android.settings", "com.android.tv.settings")) settings(options)
        else start(pm.getLeanbackLaunchIntentForPackage(app.packageName) ?: pm.getLaunchIntentForPackage(app.packageName), options)
    fun settings(options: Bundle? = null): Boolean = start(pm.getLaunchIntentForPackage("dev.streamybox.settings"), options)
    fun info(app: AppEntry) = start(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")))
    fun protected(app: AppEntry) = app.system || app.packageName.startsWith("com.android.") ||
        app.packageName.startsWith("com.rockchip") || app.packageName.contains(".hal") ||
        app.packageName == "android" || app.packageName.startsWith("com.google.android")
    fun uninstall(app: AppEntry) = !protected(app) && start(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
    private fun start(intent: Intent?, options: Bundle? = null): Boolean {
        if (intent == null) return false
        if (options == null && !dev.streamybox.design.Motion.animated) intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        return runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), options); true }.getOrDefault(false)
    }
}

package dev.streamybox.launcher

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.Activity
import android.media.AudioManager
import android.os.Handler
import android.os.Looper

class HomeReplacementReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val recovery = ComponentName("dev.streamybox.settings", "dev.streamybox.settings.HomeRecoveryReceiver")
        val pending = goAsync()
        val handler = Handler(Looper.getMainLooper())
        var finished = false
        fun finish() { if (!finished) { finished = true; pending.finish() } }
        val timeout = Runnable {
            if (finished) return@Runnable
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val preferred = context.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo
            if (preferred?.packageName == context.packageName && !context.getSystemService(AudioManager::class.java).isMusicActive) {
                runCatching { context.startActivity(home.setComponent(ComponentName(context, MainActivity::class.java)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)) }
                    .onFailure { android.util.Log.e("StreamyboxRecovery", "Restoring HOME after launcher replacement failed", it) }
            }
            finish()
        }
        handler.postDelayed(timeout, 2000)
        context.sendOrderedBroadcast(Intent("dev.streamybox.action.REQUEST_HOME").putExtra("replacement", true).setComponent(recovery).addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES), "dev.streamybox.permission.LAUNCHER_STATE", object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (resultCode == Activity.RESULT_OK) { handler.removeCallbacks(timeout); finish() }
            }
        }, handler, Activity.RESULT_CANCELED, null, null)
    }
}

package dev.streamybox.launcher

/** Start page geometry in dp on the 960×540 canvas: the full layout or favourites only with a taller hero. */
data class HomeLayout(val favoritesOnly: Boolean) {
    val heroHeight = if (favoritesOnly) 440f else 332f
    val iconSize = if (favoritesOnly) 168f else 132f
    val iconX = if (favoritesOnly) 606f else 644f
    val nameSize = if (favoritesOnly) 64f else 52f
    val nameHeight = if (favoritesOnly) 86f else 70f
    val nameWidth get() = iconX - NAME_X - 24f
    /** Title and mark share one axis, centred between the top bar and the favourites title. */
    val heroAxis get() = (TOP_BAR + pinned.titleY) / 2f
    val iconY get() = heroAxis - iconSize / 2f
    val nameY get() = heroAxis - nameHeight / 2f
    val pinned = if (favoritesOnly) Row(334f, 192f, 108f, 16f, 15f) else Row(254f, 160f, 90f, 14f, 13.5f)
    val all: Row? = if (favoritesOnly) null else Row(408f, 112f, 68f, 12f, 0f)
    val rows get() = listOfNotNull(pinned, all)
    /** Row 0 is the top bar; with favourites only there is no "All apps" row to land on. */
    fun lengths(tabs: Int, favourites: Int, apps: Int) = if (favoritesOnly) listOf(tabs, favourites) else listOf(tabs, favourites, apps)

    /** One horizontal row of cards; [label] > 0 is the text size of the name below each card. */
    data class Row(val titleY: Float, val width: Float, val height: Float, val gap: Float, val label: Float) {
        val top get() = titleY + 16f
        val labelHeight get() = if (label > 0) label * 1.45f + LABEL_GAP else 0f
        val bottom get() = top + 10f + height + labelHeight
        val step get() = width + gap
        /** Cards the row may scroll past before the focused one would leave the 848 dp viewport. */
        val lead get() = ((848f - width) / step).toInt()
        companion object { const val LABEL_GAP = 7f }
    }

    companion object {
        const val NAME_X = 53f
        /** Bottom of the tab pills and status cluster. */
        const val TOP_BAR = 60f
        /** Tab pills start here so their label lines up with the hero title and the rows. */
        const val TABS_X = 39f
        const val FULL = "full"
        const val FAVORITES = "favorites"
        val values = listOf(FULL, FAVORITES)
        fun parse(value: String?) = HomeLayout(value == FAVORITES)
    }
}

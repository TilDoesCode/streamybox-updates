package dev.streamybox.launcher

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import dev.streamybox.design.Ambience
import dev.streamybox.design.PackageIcon

/** Cached real artwork per package: TV banner, else a banner composed from the app's own icon; misses are cached too. */
class AppArt(private val catalog: AppCatalog, private val resources: Resources) {
    private val icons = HashMap<String, Drawable.ConstantState?>()
    private val banners = HashMap<String, Drawable.ConstantState?>()
    fun icon(app: AppEntry): Drawable? = icons.getOrPut(app.packageName) { catalog.icon(app)?.constantState }?.newDrawable(resources)?.mutate()
    fun banner(app: AppEntry, dark: Boolean): Drawable? = banners.getOrPut("${app.packageName}/$dark") {
        (catalog.banner(app) ?: icon(app)?.let { compose(it, dark) })?.constantState
    }?.newDrawable(resources)?.mutate()
    fun clear() { icons.clear(); banners.clear() }
    private fun compose(icon: Drawable, dark: Boolean): Drawable {
        val width = 320; val height = 180; val size = 84
        val image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(image)
        canvas.drawColor(Ambience.mix(tone(icon), if (dark) Color.rgb(14, 18, 26) else Color.WHITE, if (dark) .55f else .35f))
        PackageIcon(icon).apply { setBounds((width - size) / 2, (height - size) / 2, (width + size) / 2, (height + size) / 2) }.draw(canvas)
        return BitmapDrawable(resources, image)
    }
    private fun tone(icon: Drawable): Int {
        val probe = Bitmap.createBitmap(12, 12, Bitmap.Config.ARGB_8888)
        PackageIcon(icon).apply { setBounds(0, 0, 12, 12) }.draw(Canvas(probe))
        var r = 0L; var g = 0L; var b = 0L; var n = 0L
        for (y in 0 until 12) for (x in 0 until 12) { val c = probe.getPixel(x, y); if (Color.alpha(c) < 200) continue; r += Color.red(c); g += Color.green(c); b += Color.blue(c); n++ }
        return if (n == 0L) Color.GRAY else Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
    }
}

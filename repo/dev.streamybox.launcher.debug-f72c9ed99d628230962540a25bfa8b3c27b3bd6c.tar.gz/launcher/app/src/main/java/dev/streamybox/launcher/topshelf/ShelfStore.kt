package dev.streamybox.launcher.topshelf

import android.content.Context
import android.util.AtomicFile
import dev.streamybox.profiles.contract.ProfileClient
import org.json.JSONObject
import java.io.File

internal class ShelfStore(private val context: Context, val profile: String) {
    private val root = File(context.noBackupFilesDir, "topshelf/$profile")
    init { require(profile.matches(Regex("[a-z0-9-]{1,64}"))) }
    fun active(): Boolean {
        val status = ProfileClient.status(context) ?: return false
        return status.optString("current") == profile && !status.optBoolean("busy") && !status.optBoolean("pending") && status.optString("blocked").isEmpty()
    }
    fun account(): JellyfinAccount? { if (!active()) return null; return runCatching { JellyfinAccount.parse(read("account.json")) }.getOrNull() }
    fun connect(account: JellyfinAccount) { check(active()); check(!root.exists() || root.deleteRecursively()); write("account.json", account.json()) }
    fun disconnect() { check(active()); check(!root.exists() || root.deleteRecursively()) }
    fun data(): ShelfData = if (account() == null) ShelfData() else runCatching { ShelfData.parse(read("shelf.json")) }.getOrDefault(ShelfData())
    fun save(data: ShelfData) { check(active()); write("shelf.json", data.json()) }
    fun cache() = ShelfCache(File(root, "images"))
    private fun read(name: String) = JSONObject(AtomicFile(File(root, name)).openRead().bufferedReader().use { it.readText() })
    private fun write(name: String, json: JSONObject) {
        check(root.isDirectory || root.mkdirs()); val file = AtomicFile(File(root, name)); val output = file.startWrite()
        try { output.write(json.toString().toByteArray()); file.finishWrite(output) } catch (error: Exception) { file.failWrite(output); throw error }
    }
}

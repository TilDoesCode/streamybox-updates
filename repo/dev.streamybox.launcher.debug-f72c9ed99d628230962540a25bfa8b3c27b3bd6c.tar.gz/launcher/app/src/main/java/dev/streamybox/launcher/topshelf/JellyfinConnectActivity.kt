package dev.streamybox.launcher.topshelf

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.LinearLayout
import android.widget.ScrollView
import dev.streamybox.design.*
import dev.streamybox.launcher.R
import dev.streamybox.profiles.contract.ProfileClient
import org.json.JSONObject
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

internal class JellyfinConnectActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: ShelfStore
    private lateinit var ui: TvDesign
    private lateinit var body: LinearLayout
    private var server = ""
    private var device = UUID.randomUUID().toString()
    private var generation = 0
    private var resumed = false
    private var modal: Dialog? = null
    private val profileChanges = object : android.database.ContentObserver(handler) { override fun onChange(selfChange: Boolean) { generation++; body.removeAllViews(); modal?.dismiss(); finish() } }
    override fun attachBaseContext(base: Context) {
        val config = Configuration(base.resources.configuration)
        config.setLocale(Locale.forLanguageTag(ProfileClient.preferences(base).getString("language", "en") ?: "en"))
        super.attachBaseContext(base.createConfigurationContext(config))
    }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        store = ShelfStore(this, ProfileClient.current(this))
        ui = TvDesign(this, ProfileClient.preferences(this).getBoolean("light", false))
        val root = LinearLayout(this).apply { gravity = Gravity.CENTER; background = ui.backdrop() }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(30f), ui.dp(26f), ui.dp(30f), ui.dp(26f)); background = ui.shape(ui.surface, TvDesign.RADIUS_XL) }
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(body) }
        contentResolver.registerContentObserver(ProfileClient.uri, false, profileChanges)
        root.addView(scroll, LinearLayout.LayoutParams(ui.dp(620f), -2)); setContentView(root)
        if (android.os.Build.VERSION.SDK_INT >= 30) window.insetsController?.apply { hide(WindowInsets.Type.systemBars()); systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE }
    }
    override fun onResume() { super.onResume(); resumed = true; if (!store.active()) finish() else load() }
    override fun onPause() { resumed = false; generation++; handler.removeCallbacksAndMessages(null); modal?.dismiss(); super.onPause() }
    override fun onDestroy() { contentResolver.unregisterContentObserver(profileChanges); worker.shutdownNow(); super.onDestroy() }
    private fun title(message: String = getString(R.string.topshelf_connect)) {
        body.removeAllViews()
        body.addView(ui.text("Jellyfin", 28f, weight = 600))
        body.addView(ui.text(message, 14f, ui.muted).apply { setPadding(0, ui.dp(8f), 0, ui.dp(20f)) })
    }
    private fun row(label: Int, action: () -> Unit) { body.addView(ui.row(getString(label), action = action)); ui.group(body) }
    private fun <T> work(task: () -> T, done: (T) -> Unit) {
        val version = generation
        worker.execute {
            val result = runCatching(task)
            handler.post {
                if (!resumed || isDestroyed || version != generation) return@post
                if (!store.active()) { body.removeAllViews(); finish(); return@post }
                result.onSuccess(done).onFailure { title(getString(R.string.topshelf_error)); row(R.string.topshelf_retry) { load() }; row(R.string.topshelf_manual) { manual() } }
            }
        }
    }
    private fun load() {
        generation++; title()
        work({ store.account() }) { account ->
            if (account == null) {
                row(R.string.topshelf_discover) { discover() }; row(R.string.topshelf_manual) { manual() }
            } else {
                server = account.server; device = account.deviceId
                title(getString(R.string.topshelf_connected, account.name))
                body.addView(ui.text(server, 13f, ui.muted).apply { setPadding(0, 0, 0, ui.dp(18f)) })
                body.addView(ui.text(getString(R.string.topshelf_app_hint, account.name), 14f, ui.muted).apply { setPadding(0, 0, 0, ui.dp(18f)) })
                row(R.string.topshelf_disconnect) { modal = ui.card(getString(R.string.topshelf_disconnect), listOf(getString(R.string.cancel) to {}, getString(R.string.topshelf_disconnect) to { work({ val api = JellyfinApi(account.server, account.deviceId, account.token); store.disconnect(); runCatching { api.bytes("/Sessions/Logout", method = "POST") } }) { load() } })) }
            }
            body.getChildAt(body.childCount - 1)?.requestFocus()
        }
    }
    private fun discover() {
        generation++; title(getString(R.string.topshelf_searching))
        work({ JellyfinApi.discover() }) { servers ->
            title(if (servers.isEmpty()) getString(R.string.topshelf_no_servers) else getString(R.string.topshelf_choose_server))
            servers.forEach { (name, url) -> body.addView(ui.row(name, url) { select(url) }) }
            row(R.string.topshelf_manual) { manual() }; body.getChildAt(2)?.requestFocus()
        }
    }
    private fun manual() { modal = TextPrompt(ui, getString(R.string.topshelf_server), false, "http://jellyfin.local:8096") { url -> work({ serverUrl(url) }) { select(it) } }.also { it.open() } }
    private fun select(url: String) {
        generation++; server = url; title(url)
        row(R.string.topshelf_quick_connect) { quickConnect() }
        row(R.string.topshelf_password) { password() }
        body.getChildAt(2)?.requestFocus()
    }
    private fun password() {
        generation++
        modal = TextPrompt(ui, getString(R.string.topshelf_username), false) { username ->
            modal = TextPrompt(ui, getString(R.string.topshelf_password), true) { password ->
                title(getString(R.string.topshelf_connecting))
                work({ val api = JellyfinApi(server, device); api.authenticate(api.json("/Users/AuthenticateByName", JSONObject().put("Username", username).put("Pw", password)) as JSONObject) }) { connected(it) }
            }.also { it.open() }
        }.also { it.open() }
    }
    private fun quickConnect() {
        generation++; title(getString(R.string.topshelf_connecting))
        work({ JellyfinApi(server, device).json("/QuickConnect/Initiate", JSONObject()) as JSONObject }) { request ->
            val deadline = SystemClock.elapsedRealtime() + 5 * 60 * 1000
            val countdown = QuickConnectCode.build(ui, body, request.getString("Code"), server)
            row(R.string.topshelf_password) { password() }; row(R.string.cancel) { generation++; select(server) }
            body.getChildAt(body.childCount - 1)?.requestFocus()
            val shown = generation
            val tick = object : Runnable { override fun run() { if (generation != shown || !countdown.isAttachedToWindow) return; val left = ((deadline - SystemClock.elapsedRealtime()) / 1000).coerceAtLeast(0); countdown.text = getString(R.string.topshelf_qc_waiting, String.format(java.util.Locale.ROOT, "%d:%02d", left / 60, left % 60)); if (left > 0) handler.postDelayed(this, 1000) } }
            tick.run()
            poll(request.getString("Secret"), deadline)
        }
    }
    private fun poll(secret: String, deadline: Long) {
        if (SystemClock.elapsedRealtime() >= deadline) { title(getString(R.string.topshelf_expired)); row(R.string.topshelf_quick_connect) { quickConnect() }; row(R.string.topshelf_password) { password() }; return }
        work({ JellyfinApi(server, device).json("/QuickConnect/Connect?secret=${JellyfinApi.encode(secret)}") as JSONObject }) { result ->
            if (result.optBoolean("Authenticated")) work({ val api = JellyfinApi(server, device); api.authenticate(api.json("/Users/AuthenticateWithQuickConnect", JSONObject().put("Secret", secret)) as JSONObject) }) { connected(it) }
            else handler.postDelayed({ poll(secret, deadline) }, 2500)
        }
    }
    private fun connected(account: JellyfinAccount) { generation++; work({ store.connect(account) }) { load() } }
}

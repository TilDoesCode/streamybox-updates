package dev.streamybox.launcher.topshelf

import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.io.ByteArrayOutputStream

internal class JellyfinHttpException(val status: Int) : Exception("Jellyfin HTTP $status")
internal class JellyfinApi(val server: String, private val deviceId: String, private val token: String? = null) {
    fun json(path: String, body: JSONObject? = null, method: String = if (body == null) "GET" else "POST"): Any = JSONTokener(String(bytes(path, body, method, 2 * 1024 * 1024), Charsets.UTF_8)).nextValue()
    fun bytes(path: String, body: JSONObject? = null, method: String = "GET", limit: Int = 4 * 1024 * 1024): ByteArray {
        val connection = URL(server + path).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 4000; connection.readTimeout = 6000; connection.instanceFollowRedirects = false; connection.requestMethod = method
            connection.setRequestProperty("Authorization", "MediaBrowser Client=\"Streamybox Top Shelf\", Device=\"Streamybox\", DeviceId=\"$deviceId\", Version=\"1.0\"" + (token?.let { ", Token=\"$it\"" } ?: ""))
            if (body != null) { connection.doOutput = true; connection.setRequestProperty("Content-Type", "application/json"); connection.outputStream.use { it.write(body.toString().toByteArray()) } }
            if (connection.responseCode !in 200..299) throw JellyfinHttpException(connection.responseCode)
            require(connection.contentLengthLong <= limit)
            return connection.inputStream.use { input ->
                val output = ByteArrayOutputStream(); val buffer = ByteArray(8192)
                while (true) { val count = input.read(buffer); if (count < 0) break; require(output.size() + count <= limit); output.write(buffer, 0, count) }
                output.toByteArray()
            }
        } finally { connection.disconnect() }
    }
    fun shelf(user: String): ShelfData {
        val fields = "Fields=PrimaryImageAspectRatio,UserData&EnableImages=true&Limit=24"
        return ShelfData(parseItems(json("/Users/$user/Items/Resume?$fields&MediaTypes=Video")), parseItems(json("/Shows/NextUp?UserId=$user&$fields")), parseItems(json("/Users/$user/Items/Latest?$fields&IncludeItemTypes=Movie,Episode,Video")))
    }
    fun authenticate(result: JSONObject): JellyfinAccount {
        val user = result.getJSONObject("User")
        return JellyfinAccount.parse(JSONObject().put("server", server).put("userId", user.getString("Id")).put("name", user.getString("Name")).put("token", result.getString("AccessToken")).put("deviceId", deviceId))
    }
    fun image(item: ShelfItem, width: Int) = "/Items/${item.imageId}/Images/${item.imageType}?maxWidth=$width&quality=85&tag=${encode(item.imageTag)}"
    companion object {
        fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
        fun discover(): List<Pair<String, String>> {
            val found = LinkedHashMap<String, String>()
            DatagramSocket().use { socket ->
                socket.broadcast = true; socket.soTimeout = 450
                val payload = "who is JellyfinServer?".toByteArray()
                val addresses = mutableSetOf(InetAddress.getByName("255.255.255.255"))
                NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }.flatMap { it.interfaceAddresses }.mapNotNullTo(addresses) { it.broadcast }
                addresses.forEach { address -> runCatching { socket.send(DatagramPacket(payload, payload.size, address, 7359)) } }
                val end = System.nanoTime() + 2_000_000_000L
                while (System.nanoTime() < end && found.size < 12) runCatching {
                    val packet = DatagramPacket(ByteArray(8192), 8192); socket.receive(packet)
                    val response = JSONObject(String(packet.data, 0, packet.length)); val url = serverUrl(response.getString("Address"))
                    found[url] = response.optString("Name", url)
                }
            }
            return found.map { (url, name) -> name to url }
        }
    }
}

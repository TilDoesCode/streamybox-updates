plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    useLibrary("android.test.runner")
    useLibrary("android.test.base")
    namespace = "dev.streamybox.launcher"
    compileSdk = 36
    defaultConfig {
        applicationId = "dev.streamybox.launcher.debug"
        minSdk = 29
        targetSdk = 36
        testInstrumentationRunner = "android.test.InstrumentationTestRunner"
    }
    buildTypes {
        debug { isDebuggable = false }
        create("development") { initWith(getByName("debug")); isDebuggable = true; matchingFallbacks += listOf("debug") }
        create("benchmark") { initWith(getByName("debug")); isDebuggable = false; matchingFallbacks += listOf("release") }
        release { isMinifyEnabled = false;  }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    bundle { language { enableSplit = false } }
    lint { abortOnError = true; warningsAsErrors = true }
}
dependencies { implementation(project(":profiles-contract")); implementation(project(":design")); testImplementation("junit:junit:4.13.2"); testImplementation("org.json:json:20240303") }

apply(from = rootProject.file("../gradle/streamybox-release.gradle"))

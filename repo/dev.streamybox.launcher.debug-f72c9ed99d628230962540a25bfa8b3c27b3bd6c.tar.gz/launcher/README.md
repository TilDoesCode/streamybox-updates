# Streamybox

Our native Kotlin home screen for the ROCK 4D: remote-first, ad-free, German/English,
with dark/light themes, favourites, every launchable app, and Android settings.
There is no Flutter runtime. `dev.streamybox.launcher.debug` is the development HOME.

## Build and install

From the repository root:

```sh
source scripts/env.sh
cd launcher
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > local.properties
./gradlew assembleDebug lintDebug testDebugUnitTest
cd ..
scripts/install-launcher.sh --no-build
```

The installer selects the physical ROCK 4D, holds the shared `lockf` device lock,
installs the APK and sets HOME. `--user <Android user id>` configures a particular
existing Android user; otherwise it uses the current user. Arc remains installed.
`--release` builds a local release using the development key; production signing is
not configured. No Google Play flavour, network content, wallpaper or update code.

## Architecture

- `MainActivity.kt`: native Android Views, explicit row/grid cursor, short focus animations,
  modal context/settings/developer menus. Long OK or five Menu presses open tools.
- `AppCatalog.kt`: PackageManager discovery for both Leanback and ordinary launchers;
  banners/icons and TV-first launch/settings fallbacks.
- `LauncherDatabase.kt`: transactional SQLite app cache and ordered pins; empty pin lists
  remain empty across restarts. Android isolates both SQLite and preferences per system user.
- `../design`: shared palette, typography, focus, rows, dialogs and remote keyboard.
- `DeviceStatus.kt`: actual connectivity, configured USB ADB and network ADB status.
- `values/strings.xml` and `values-de/strings.xml`: native localization.

Continue Watching / Now Playing stay hidden behind a generic `ContentSource` interface.
The Settings tile and the Control Center open our native Settings app (`dev.streamybox.settings`). Appearance
and language are managed there through the shared design module. There is no account
or user-switching interface in the launcher.

## Attribution and license

GPL-3.0; the complete license is in [LICENSE](LICENSE).
This directory began as a git-subtree import of
[Arc Launcher](https://github.com/meddouribadis/arclauncher) by meddouribadis,
a fork through [LTvLauncher](https://github.com/LeanBitLab/LtvLauncher) of
[FLauncher](https://gitlab.com/flauncher/flauncher) by Étienne Fesser and contributors,
including Oscar Rojas. Native app discovery and intent fallbacks retain those upstream
behaviours; Streamybox replaces the UI, Flutter bridge and persistence implementation.
The upstream source and history remain available in this repository's git history.

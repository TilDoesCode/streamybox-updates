#!/usr/bin/env python3
"""Generates adaptive icons and 320x180 TV banners for the Streamybox apps (glyphs match design AppIcon)."""
import math, pathlib
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

ROOT = pathlib.Path(__file__).resolve().parents[2]
FONT = ROOT / 'design/src/main/assets/fonts/Inter.ttf'
NS = 'xmlns:android="http://schemas.android.com/apk/res/android" xmlns:aapt="http://schemas.android.com/aapt"'

def circle(cx, cy, r): return f'M{cx - r:.2f},{cy:.2f}a{r},{r} 0 1 0 {2 * r},0a{r},{r} 0 1 0 {-2 * r},0'
def polar(r, deg): a = math.radians(deg); return 12 + r * math.cos(a), 12 + r * math.sin(a)
def teeth():
    out = []
    for i in range(8):
        (x1, y1), (x2, y2) = polar(7.4, i * 45 + 22.5), polar(9.2, i * 45 + 22.5)
        out.append(f'M{x1:.2f},{y1:.2f}L{x2:.2f},{y2:.2f}')
    return ''.join(out)
def arc():
    (x1, y1), (x2, y2) = polar(8.6, 20), polar(8.6, 285)
    return f'M{x1:.2f},{y1:.2f}A8.6,8.6 0 1 1 {x2:.2f},{y2:.2f}'
def keys(): return ''.join(f'M{x - .85:.2f},9.45h1.7v1.7h-1.7z' for x in (6.5, 9.25, 12, 14.75, 17.5))

# (stroke|fill, path in the 24-unit AppIcon grid, stroke width)
GLYPHS = {
    'brand': [('s', arc(), 2.6), ('f', 'M10.2,8.2L16.2,12L10.2,15.8Z', 0)],
    'settings': [('s', circle(12, 12, 6.2), 2.1), ('s', circle(12, 12, 2.4), 2.1), ('s', teeth(), 3)],
    'diagnostics': [('s', 'M2.5,12.5L7,12.5L9.5,6L14,18L16.5,12.5L21.5,12.5', 2.2)],
    'keyboard': [('s', 'M5.1,6.5H18.9A2.6,2.6 0 0 1 21.5,9.1V14.9A2.6,2.6 0 0 1 18.9,17.5H5.1A2.6,2.6 0 0 1 2.5,14.9V9.1A2.6,2.6 0 0 1 5.1,6.5Z', 2), ('f', keys(), 0), ('s', 'M8.5,14.2H15.5', 1.9)],
    'profiles': [('s', circle(12, 8.4, 3.6), 2.1), ('s', 'M5,19.6C5,15.6 8.2,13.9 12,13.9C15.8,13.9 19,15.6 19,19.6', 2.1)],
}
# module, glyph, hue (AppIcon.Kind), banner name en / de
APPS = [
    ('launcher/app', 'brand', 0x4FA8EE, 'Streamybox', 'Streamybox'),
    ('settings', 'settings', 0x7F92B0, 'Settings', 'Einstellungen'),
    ('test-app/app', 'diagnostics', 0x7C6CF0, 'Diagnostics', 'Diagnose'),
    ('keyboard', 'keyboard', 0xC9A23F, 'Keyboard', 'Tastatur'),
    ('profiles', 'profiles', 0x3FB6A8, 'Profiles', 'Profile'),
]

def rgb(c): return (c >> 16) & 255, (c >> 8) & 255, c & 255
def mix(a, b, t): return tuple(round(x + (y - x) * t) for x, y in zip(a, b))
def hexc(c): return '#FF%02X%02X%02X' % c

def glyph(name, ink, scale, dx, dy):
    parts = []
    for kind, data, width in GLYPHS[name]:
        if kind == 's': parts.append(f'<path android:pathData="{data}" android:strokeColor="{ink}" android:strokeWidth="{width}" android:strokeLineCap="round" android:strokeLineJoin="round" android:fillColor="#00000000" />')
        else: parts.append(f'<path android:pathData="{data}" android:fillColor="{ink}" />')
    return f'<group android:translateX="{dx:.2f}" android:translateY="{dy:.2f}" android:scaleX="{scale:.4f}" android:scaleY="{scale:.4f}">' + ''.join(parts) + '</group>'

def backdrop(hue, w, h):
    base = rgb(0x07090E)
    top, bottom = mix(rgb(0x0B141F), hue, .30), mix(base, hue, .06)
    glow = mix(hue, (255, 255, 255), .1)
    return (f'<path android:pathData="M0,0H{w}V{h}H0Z"><aapt:attr name="android:fillColor"><gradient android:type="linear" android:startX="0" android:startY="0" android:endX="{w}" android:endY="{h}" android:startColor="{hexc(top)}" android:endColor="{hexc(bottom)}" /></aapt:attr></path>'
            f'<path android:pathData="M0,0H{w}V{h}H0Z"><aapt:attr name="android:fillColor"><gradient android:type="radial" android:centerX="{w * .5}" android:centerY="{h * .38}" android:gradientRadius="{max(w, h) * .62}" android:startColor="#38{"%02X%02X%02X" % glow}" android:endColor="#00{"%02X%02X%02X" % glow}" /></aapt:attr></path>')

def vector(w, h, body, dpw=None, dph=None):
    lint = ' xmlns:tools="http://schemas.android.com/tools" tools:ignore="VectorPath"' if dpw else ''
    return f'<vector {NS}{lint} android:width="{dpw or w}dp" android:height="{dph or h}dp" android:viewportWidth="{w}" android:viewportHeight="{h}">{body}</vector>\n'

font = instantiateVariableFont(TTFont(FONT), {'wght': 640})
glyphs, cmap, upm = font.getGlyphSet(), font.getBestCmap(), font['head'].unitsPerEm
def text(value, size, cx, baseline, color):
    scale = size / upm
    width = sum(glyphs[cmap[ord(ch)]].width for ch in value) * scale - size * .02 * (len(value) - 1)
    x, out = cx - width / 2, []
    for ch in value:
        g, pen = glyphs[cmap[ord(ch)]], SVGPathPen(glyphs, ntos=lambda v: ('%.1f' % v).rstrip('0').rstrip('.'))
        g.draw(TransformPen(pen, (scale, 0, 0, -scale, x, baseline)))
        if pen.getCommands(): out.append(f'<path android:pathData="{pen.getCommands()}" android:fillColor="{color}" />')
        x += g.width * scale - size * .02
    return ''.join(out)

for module, name, hue, en, de in APPS:
    res = ROOT / module / 'src/main/res'
    ink = hexc(mix(rgb(hue), (255, 255, 255), .45))
    def write(path, content): p = res / path; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(content)
    write('drawable/sb_app_icon_bg.xml', vector(108, 108, backdrop(rgb(hue), 108, 108)))
    write('drawable/sb_app_icon_fg.xml', vector(108, 108, glyph(name, ink, 46 / 24, 31, 31)))
    write('drawable/sb_app_icon_mono.xml', vector(108, 108, glyph(name, '#FFFFFFFF', 46 / 24, 31, 31)))
    write('mipmap-anydpi/sb_app_icon.xml', '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@drawable/sb_app_icon_bg" />\n    <foreground android:drawable="@drawable/sb_app_icon_fg" />\n    <monochrome android:drawable="@drawable/sb_app_icon_mono" />\n</adaptive-icon>\n')
    def banner(label): return vector(320, 180, backdrop(rgb(hue), 320, 180) + glyph(name, ink, 60 / 24, 130, 30) + text(label, 27, 160, 140, '#FFEEF2F8'), 160, 90)
    write('drawable/sb_app_banner.xml', banner(en))
    if de != en: write('drawable-de/sb_app_banner.xml', banner(de))
    print('generated', module)

package dev.streamybox.design

import android.app.Dialog
import android.app.Activity
import android.graphics.drawable.StateListDrawable
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.inputmethod.InputMethodManager
import android.view.WindowManager
import android.view.WindowInsets
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout

/** Title plus one plain text field above the system keyboard; secrets are cleared on dismissal. */
class TextPrompt(private val ui: TvDesign, title: String, secret: Boolean, hint: String = "", private val done: (String) -> Unit) : Dialog(ui.context) {
    private var origin: View? = null
    private var opening = false
    private var attempts = 0
    private var enterDown = false
    private val showIme = Runnable { showKeyboard() }
    val field = object : EditText(ui.context) {
        override fun dispatchKeyEventPreIme(event: KeyEvent): Boolean {
            if (event.keyCode != KeyEvent.KEYCODE_BACK) return super.dispatchKeyEventPreIme(event)
            if (event.action == KeyEvent.ACTION_UP && !event.isCanceled) this@TextPrompt.cancel()
            return true
        }
    }.apply {
        textSize = 20f * ui.scale; typeface = Fonts.get(context, 500); includeFontPadding = false
        setTextColor(ui.foreground); setHintTextColor(ui.faint); this.hint = hint; isSingleLine = true
        setPadding(ui.dp(18f), 0, ui.dp(18f), 0); gravity = Gravity.CENTER_VERTICAL
        background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), ui.shape(ui.background, TvDesign.RADIUS_M, ui.accent, 2f))
            addState(intArrayOf(), ui.shape(ui.background, TvDesign.RADIUS_M, ui.border))
        }
        textCursorDrawable = ui.shape(ui.accent, 1f).apply { setSize(ui.dp(2f), -1) }
        inputType = InputType.TYPE_CLASS_TEXT or if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
        setOnEditorActionListener { _, action, event ->
            when {
                event == null && action == EditorInfo.IME_ACTION_DONE -> { submit(); true }
                event?.keyCode in setOf(KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER) && event?.action == KeyEvent.ACTION_UP && enterDown -> { enterDown = false; submit(); true }
                else -> false
            }
        }
    }
    private val body = ui.dialogBody()
    init {
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        body.addView(ui.text(title, 22f, weight = 600).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(ui.dp(2f), 0, 0, ui.dp(16f)) })
        body.addView(field, LinearLayout.LayoutParams(-1, ui.dp(52f)))
        setContentView(body)
        window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        field.setOnApplyWindowInsetsListener { _, insets ->
            if (android.os.Build.VERSION.SDK_INT >= 30 && insets.isVisible(WindowInsets.Type.ime())) { opening = false; field.removeCallbacks(showIme) }
            insets
        }
    }
    fun open() {
        origin = (ui.context as? Activity)?.currentFocus
        opening = true; attempts = 0
        ui.present(this, 720f, body, 64f)
        field.requestFocus()
        field.post(showIme)
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && opening) field.post(showIme)
    }
    private fun showKeyboard() {
        field.removeCallbacks(showIme)
        if (!opening || !isShowing || !field.hasWindowFocus() || !field.isFocused) return
        if (android.os.Build.VERSION.SDK_INT >= 30 && field.rootWindowInsets?.isVisible(WindowInsets.Type.ime()) == true) { opening = false; return }
        context.getSystemService(InputMethodManager::class.java).showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
        if (++attempts < 40) field.postDelayed(showIme, 100)
    }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode in setOf(KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER)) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) enterDown = true
            if (event.action == KeyEvent.ACTION_UP && !enterDown) return true
        }
        return super.dispatchKeyEvent(event)
    }
    override fun dismiss() {
        opening = false; enterDown = false; field.removeCallbacks(showIme)
        context.getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(field.windowToken, 0)
        field.text.clear()
        super.dismiss()
        origin?.takeIf { it.isAttachedToWindow }?.let { control -> control.post { control.requestFocus() } }
    }
    private fun submit() { val value = field.text.toString(); dismiss(); done(value) }
}

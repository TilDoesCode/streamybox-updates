package dev.streamybox.design

import android.app.Dialog
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/** One card for every flow: optional icon + subtitle, an optional large code, choices with a chosen default focus. */
fun TvDesign.card(
    title: String, options: List<Pair<String, () -> Unit>>, message: String = "", icon: Drawable? = null, subtitle: String = "",
    code: String? = null, focus: Int = 0, swatches: List<Int> = emptyList()
): Dialog {
    val dialog = Dialog(context).apply { requestWindowFeature(android.view.Window.FEATURE_NO_TITLE) }
    val column = dialogBody()
    val head = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    if (icon != null) head.addView(ImageView(context).apply {
        setImageDrawable(icon); isFocusable = false; clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() { override fun getOutline(view: View, outline: Outline) = outline.setRoundRect(0, 0, view.width, view.height, dp(TvDesign.RADIUS_M).toFloat()) }
    }, LinearLayout.LayoutParams(dp(56f), dp(56f)).apply { marginEnd = dp(18f) })
    val titles = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    titles.addView(text(title, 22f, weight = 600).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
    if (subtitle.isNotEmpty()) titles.addView(text(subtitle, 13.5f, muted, weight = 500).apply {
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(5f), 0, 0); fontFeatureSettings = "tnum"
    })
    head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
    column.addView(head)
    if (code != null) column.addView(text(code, 40f, weight = 600).apply {
        gravity = Gravity.CENTER; letterSpacing = .16f; fontFeatureSettings = "tnum"; includeFontPadding = false
        setPadding(0, dp(18f), 0, dp(18f)); background = shape(surfaceHigh, TvDesign.RADIUS_L)
    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20f) })
    if (message.isNotEmpty()) column.addView(text(message, 14f, muted).apply {
        setPadding(dp(2f), dp(14f), 0, 0); setLineSpacing(dp(3f).toFloat(), 1f)
    })
    val scroll = ScrollView(context).apply { clipChildren = false; clipToPadding = false; isVerticalScrollBarEnabled = false }
    val choices = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false; setPadding(dp(6f), dp(18f), dp(6f), dp(6f)) }
    options.forEachIndexed { index, (label, action) ->
        val option = item(label) { dialog.dismiss(); action() }.apply { minimumHeight = dp(48f); setPadding(dp(18f), 0, dp(16f), 0) }
        swatches.getOrNull(index)?.let { color ->
            option.addView(View(context).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color); setStroke(dp(1f), if (light) Color.argb(40, 0, 0, 0) else Color.argb(50, 255, 255, 255)) } },
                0, LinearLayout.LayoutParams(dp(20f), dp(20f)).apply { marginEnd = dp(14f) })
        }
        style(option, FocusStyle(surfaceHigh, null, chipFocus, radii(TvDesign.RADIUS_M), 1f, softRing))
        choices.addView(option, LinearLayout.LayoutParams(-1, dp(48f)).apply { bottomMargin = dp(8f) })
    }
    scroll.addView(choices)
    column.addView(scroll, LinearLayout.LayoutParams(-1, minOf(options.size * dp(56f) + dp(24f), dp(320f))))
    dialog.setContentView(column)
    present(dialog, 560f, column)
    choices.getChildAt(focus.coerceIn(0, maxOf(0, options.size - 1)))?.requestFocus()
    return dialog
}

/** Launcher-style app badge (tinted tile + drawn glyph) so cards match the home grid. */
fun TvDesign.appBadge(pkg: String, label: String): Drawable {
    val kind = AppIcon.kind(pkg); val tone = AppIcon.tone(kind, pkg)
    val glyph = AppIcon(kind, Color.parseColor(if (light) "#3A4558" else "#DCE2EC"), label.take(1).uppercase(context.resources.configuration.locales[0]), Fonts.get(context, 650), tone, light)
    return LayerDrawable(arrayOf(tile(tone), glyph)).apply { val inset = dp(10f); setLayerInset(1, inset, inset, inset, inset) }
}

/** Round chip around a line glyph, for cards without an app (Bluetooth, notices). */
fun TvDesign.glyphBadge(glyph: Drawable): Drawable =
    LayerDrawable(arrayOf(shape(chip, TvDesign.PILL), glyph)).apply { val inset = dp(16f); setLayerInset(1, inset, inset, inset, inset) }

/** Avatar disc with the profile initial, shared by picker, Settings and Control Center. */
fun TvDesign.avatar(name: String, color: Int, size: Float, textSize: Float) = text(name.take(1).uppercase(context.resources.configuration.locales[0]), textSize, Color.WHITE, weight = 600).apply {
    gravity = Gravity.CENTER; includeFontPadding = false; background = shape(color, TvDesign.PILL); minimumWidth = dp(size); minimumHeight = dp(size)
}

package dev.streamybox.profiles.contract

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject

object ProfileClient {
    val uri: Uri=Uri.parse("content://dev.streamybox.profiles/state")
    fun call(context: Context,method: String,args: JSONObject=JSONObject()): JSONObject {
        val bundle=context.contentResolver.call(uri,method,args.toString(),null) ?: error("Profile service unavailable")
        val result=JSONObject(requireNotNull(bundle.getString("json")))
        if (result.has("current")) {
            val cache=context.getSharedPreferences("profile-contract",0)
            val id=result.getString("current");val count=result.getJSONArray("profiles").length()
            if(cache.getString("current",null)!=id || cache.getInt("count",0)!=count)check(cache.edit().putString("current",id).putInt("count",count).commit())
        }
        check(result.optBoolean("ok")) { result.optString("error","Profile recovery blocked") }; return result
    }
    fun status(context: Context): JSONObject?=runCatching { call(context,"status") }.getOrNull()
    fun current(context: Context): String=status(context)?.optString("current","default") ?: context.getSharedPreferences("profile-contract",0).getString("current","default")!!
    fun preferences(context: Context,id: String=current(context)): android.content.SharedPreferences { require(id.matches(Regex("[a-z0-9-]{1,64}"))); return context.getSharedPreferences(if(id=="default")"launcher" else "launcher-$id",0) }
    fun picker(context: Context) { context.startActivity(Intent().setClassName("dev.streamybox.profiles","dev.streamybox.profiles.PickerActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun settings(context: Context,developer: Boolean=false) { context.startActivity(Intent().setClassName("dev.streamybox.profiles","dev.streamybox.profiles.ProfilesActivity").putExtra("developer",developer).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun pending(context: Context): Boolean {
        val status=status(context) ?: return context.getSharedPreferences("profile-contract",0).getInt("count",0)>=2
        return status.optBoolean("pending") || status.optString("blocked").isNotEmpty()
    }
}

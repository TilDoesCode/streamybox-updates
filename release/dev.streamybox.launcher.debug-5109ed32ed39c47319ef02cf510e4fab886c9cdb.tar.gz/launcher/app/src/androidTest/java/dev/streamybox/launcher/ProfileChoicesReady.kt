@file:Suppress("DEPRECATION")
package dev.streamybox.launcher

import android.app.Instrumentation
import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo
import dev.streamybox.profiles.contract.ProfileClient

internal object ProfileChoicesReady {
    private fun text(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        return (node.text?.toString() ?: "") + "\n" + (0 until node.childCount).joinToString("\n") { text(node.getChild(it)) }
    }

    fun await(instrumentation: Instrumentation) {
        val status = requireNotNull(ProfileClient.status(instrumentation.targetContext))
        val first = status.getJSONArray("profiles").getJSONObject(0).getString("name")
        val deadline = SystemClock.uptimeMillis() + 15000
        var tree = ""
        while (SystemClock.uptimeMillis() < deadline) {
            val root = instrumentation.uiAutomation.rootInActiveWindow
            tree = text(root)
            if (root?.packageName == "dev.streamybox.settings" && first in tree && "App-Daten pro Profil" in tree && "System-Apps sind immer gemeinsam" !in tree) return
            Thread.sleep(50)
        }
        throw AssertionError("Settings › Profiles did not render its list; tree=$tree")
    }
}

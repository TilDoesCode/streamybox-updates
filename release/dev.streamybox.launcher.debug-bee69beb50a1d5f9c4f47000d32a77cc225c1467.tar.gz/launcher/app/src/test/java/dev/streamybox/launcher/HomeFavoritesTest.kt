package dev.streamybox.launcher

import org.junit.Assert.*
import org.junit.Test

class HomeFavoritesTest {
    private val box = listOf(AppEntry("dev.streamybox.store", "Streamybox Store"), AppEntry("org.smarttube.stable", "SmartTube"),
        AppEntry("org.jellyfin.androidtv", "Jellyfin"), AppEntry("dev.streamarr.app", "Streamarr"), AppEntry("org.fdroid.fdroid", "F-Droid"),
        AppEntry("com.aurora.store", "Aurora Store"), AppEntry("dev.streamybox.airplay", "AirPlay"), AppEntry("com.netflix.ninja", "Netflix"))

    @Test fun everyEarlierAutomaticListIsRecognised() {
        assertTrue(HomeFavorites.looksAutomatic(listOf("dev.streamybox.store", "org.smarttube.stable", "org.jellyfin.androidtv", "dev.streamarr.app", "org.fdroid.fdroid"), box))
        assertTrue(HomeFavorites.looksAutomatic(listOf("dev.streamybox.store", "org.smarttube.stable", "org.jellyfin.androidtv", "org.fdroid.fdroid", "com.aurora.store", "dev.streamybox.airplay"), box))
        assertTrue(HomeFavorites.looksAutomatic(listOf("org.smarttube.stable", "org.jellyfin.androidtv", "dev.streamybox.airplay", "dev.streamybox.store"), box))
        assertTrue(HomeFavorites.looksAutomatic(listOf("org.smarttube.stable", "org.jellyfin.androidtv", "org.fdroid.fdroid", "com.aurora.store"), box))
    }
    @Test fun manualListsAreLeftAlone() {
        assertFalse(HomeFavorites.looksAutomatic(listOf("org.jellyfin.androidtv", "org.smarttube.stable"), box))
        assertFalse(HomeFavorites.looksAutomatic(listOf("dev.streamybox.store", "org.smarttube.stable", "com.netflix.ninja"), box))
        assertFalse(HomeFavorites.looksAutomatic(listOf("dev.streamarr.app", "dev.streamybox.store"), box))
        assertFalse(HomeFavorites.looksAutomatic(emptyList(), box))
    }
    @Test fun migrationDropsStoresAndToolsAndPutsStreamarrFirst() {
        assertEquals(listOf("dev.streamarr.app", "org.jellyfin.androidtv", "org.smarttube.stable"),
            HomeFavorites.migrate(listOf("dev.streamybox.store", "org.smarttube.stable", "org.jellyfin.androidtv", "dev.streamarr.app", "org.fdroid.fdroid", "com.aurora.store", "dev.streamybox.airplay"), box))
    }
    @Test fun migrationOfAStoresOnlyListFallsBackToDefaults() {
        assertEquals(HomeFavorites.defaults(box), HomeFavorites.migrate(listOf("dev.streamybox.store", "org.fdroid.fdroid"), box))
        assertEquals(listOf("dev.streamarr.app", "org.jellyfin.androidtv", "org.smarttube.stable", "com.netflix.ninja"), HomeFavorites.defaults(box))
    }
    @Test fun moveAndParse() {
        val pins = listOf("a", "b", "c")
        assertEquals(listOf("b", "a", "c"), HomeFavorites.move(pins, "b", -1))
        assertEquals(listOf("a", "b", "c"), HomeFavorites.move(pins, "a", -1))
        assertEquals(listOf("c", "a", "b"), HomeFavorites.move(pins, "c", null))
        assertEquals(listOf("a", "b", "c"), HomeFavorites.move(pins, "c", 1))
        assertEquals(listOf("org.a", "org.b"), HomeFavorites.parse(" org.a,org.b,org.a,"))
        assertTrue(HomeFavorites.parse("").isEmpty())
        assertTrue(runCatching { HomeFavorites.parse("org.a;rm") }.isFailure)
    }
}

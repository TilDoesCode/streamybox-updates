package dev.streamybox.launcher

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class LauncherDatabase(context: Context, profile: String = dev.streamybox.profiles.contract.ProfileClient.current(context)) : SQLiteOpenHelper(context, if (profile == "default") "streamybox.db" else "streamybox-$profile.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE apps(package TEXT PRIMARY KEY, name TEXT NOT NULL, version TEXT NOT NULL)")
        db.execSQL("CREATE TABLE pins(package TEXT PRIMARY KEY, position INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE config(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
    companion object { const val SOURCE = "pinsSource"; const val FAVORITES = "favoritesVersion"; const val AUTO = "auto"; const val USER = "user" }
    @Synchronized fun synchronize(apps: List<AppEntry>): List<String> {
        val db = writableDatabase
        if (config(db, "pinsInitialized") != null && (config(db, FAVORITES) != null || apps.isEmpty()) && stored(db) == apps.map { listOf(it.packageName, it.name, it.version) }.toSet()) return pins(db)
        db.beginTransaction()
        try {
            db.delete("apps", null, null)
            apps.forEach { app -> db.insertOrThrow("apps", null, ContentValues().apply {
                put("package", app.packageName); put("name", app.name); put("version", app.version)
            }) }
            if (config(db, "pinsInitialized") == null) {
                writePins(db, AppOrder.defaults(apps))
                setConfig(db, "pinsInitialized", "1"); setConfig(db, SOURCE, AUTO); setConfig(db, FAVORITES, "${HomeFavorites.VERSION}")
            } else if (config(db, FAVORITES) == null && apps.isNotEmpty()) {
                val pins = pins(db)
                val automatic = HomeFavorites.looksAutomatic(pins, apps)
                if (automatic) writePins(db, HomeFavorites.migrate(pins, apps))
                setConfig(db, SOURCE, if (automatic) AUTO else USER); setConfig(db, FAVORITES, "${HomeFavorites.VERSION}")
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return pins(db)
    }
    @Synchronized fun readPins(): List<String> = pins(readableDatabase)
    /** "auto" while the list is the untouched default, "user" after any edit. */
    @Synchronized fun source(): String? = config(readableDatabase, SOURCE)
    @Synchronized fun savePins(pins: List<String>, source: String = USER) {
        val db = writableDatabase
        db.beginTransaction()
        try { writePins(db, pins); setConfig(db, SOURCE, source); db.setTransactionSuccessful() } finally { db.endTransaction() }
    }
    private fun pins(db: SQLiteDatabase) = db.rawQuery("SELECT package FROM pins ORDER BY position", null).use { cursor ->
        buildList { while (cursor.moveToNext()) add(cursor.getString(0)) }
    }
    private fun stored(db: SQLiteDatabase) = db.rawQuery("SELECT package, name, version FROM apps", null).use { cursor ->
        buildSet { while (cursor.moveToNext()) add(listOf(cursor.getString(0), cursor.getString(1), cursor.getString(2))) }
    }
    private fun config(db: SQLiteDatabase, key: String) = db.rawQuery("SELECT value FROM config WHERE key=?", arrayOf(key)).use { if (it.moveToFirst()) it.getString(0) else null }
    private fun setConfig(db: SQLiteDatabase, key: String, value: String) { db.insertWithOnConflict("config", null, ContentValues().apply { put("key", key); put("value", value) }, SQLiteDatabase.CONFLICT_REPLACE) }
    private fun writePins(db: SQLiteDatabase, pins: List<String>) {
        db.delete("pins", null, null)
        pins.forEachIndexed { index, pkg -> db.insertOrThrow("pins", null, ContentValues().apply {
            put("package", pkg); put("position", index)
        }) }
    }
}

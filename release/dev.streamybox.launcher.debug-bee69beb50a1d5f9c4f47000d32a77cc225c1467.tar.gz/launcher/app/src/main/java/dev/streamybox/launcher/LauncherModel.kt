package dev.streamybox.launcher

data class AppEntry(val packageName: String, val name: String, val version: String = "", val system: Boolean = false, val media: Boolean = false) {
    val label get() = if (packageName == "org.smarttube.stable") "YouTube" else name
}

object AppOrder {
    fun sorted(apps: List<AppEntry>) = apps.distinctBy { it.packageName }
        .sortedWith(compareBy<AppEntry> { it.label.lowercase(java.util.Locale.ROOT) }.thenBy { it.packageName })
    fun defaults(apps: List<AppEntry>) = HomeFavorites.defaults(apps)
}

class RemoteCursor(var row: Int = 1, var column: Int = 0) {
    fun move(dx: Int, dy: Int, lengths: List<Int>) {
        row = (row + dy).coerceIn(0, lengths.lastIndex)
        column = (column + dx).coerceIn(0, (lengths[row] - 1).coerceAtLeast(0))
    }
    fun gridMove(index: Int, dx: Int, dy: Int, count: Int, columns: Int = 6): Int {
        if (count == 0) return 0
        if (dx != 0 && index % columns + dx !in 0 until columns) return index
        if (dy != 0 && (index / columns + dy < 0 || (index / columns + dy) * columns >= count)) return index
        return (index + dx + dy * columns).coerceIn(0, count - 1)
    }
}

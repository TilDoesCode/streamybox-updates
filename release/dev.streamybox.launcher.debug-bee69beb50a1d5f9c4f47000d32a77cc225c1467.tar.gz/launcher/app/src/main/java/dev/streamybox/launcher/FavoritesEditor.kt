package dev.streamybox.launcher

import android.content.Context
import android.content.Intent
import android.os.Bundle

/** Opens Settings › Appearance › Favourites for the active profile; Back there returns HOME. */
object FavoritesEditor {
    const val TILE = "edit"
    fun intent() = Intent().setClassName("dev.streamybox.settings", "dev.streamybox.settings.MainActivity")
        .putExtra("section", "appearance").putExtra("page", "home_favorites").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    fun open(context: Context, options: Bundle? = null) = runCatching { context.startActivity(intent(), options); true }.getOrDefault(false)
}

package dev.streamybox.launcher.topshelf

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import dev.streamybox.launcher.ContentSource
import dev.streamybox.launcher.PlaybackItem
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

internal data class ShelfSnapshot(val data: ShelfData, val images: Map<String, Bitmap>, val hero: Bitmap?, val offline: Boolean)
internal class JellyfinContentSource(private val context: Context, private val store: ShelfStore) : ContentSource {
    fun refresh(cachedOnly: Boolean = false): ShelfSnapshot {
        val account = store.account() ?: return ShelfSnapshot(ShelfData(), emptyMap(), null, false)
        val api = JellyfinApi(account.server, account.deviceId, account.token)
        var offline = cachedOnly
        val data = if (cachedOnly) store.data() else runCatching { api.shelf(account.userId).also { store.save(it) } }.getOrElse { error ->
            if (error is JellyfinHttpException && error.status in listOf(401, 403)) { store.disconnect(); return ShelfSnapshot(ShelfData(), emptyMap(), null, false) }
            offline = true; store.data()
        }
        if (!store.active()) return ShelfSnapshot(ShelfData(), emptyMap(), null, false)
        val cache = store.cache()
        fun image(item: ShelfItem, width: Int): Bitmap? = runCatching {
            val key = api.image(item, width)
            val file = cache.get(key) ?: if (offline) null else cache.put(key, api.bytes(key))
            file ?: return@runCatching null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(file.path, bounds)
            require(bounds.outWidth in 1..8192 && bounds.outHeight in 1..8192)
            var sample = 1
            while (bounds.outWidth / sample > width * 2 || bounds.outHeight / sample > width * 2) sample *= 2
            BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })?.apply { prepareToDraw() }
        }.getOrNull()
        val visibleItems = (data.resume.take(12) + data.next.take(12) + data.latest.take(12)).distinctBy { it.id }
        val images = visibleItems.mapNotNull { item -> image(item, 400)?.let { item.id to it } }.toMap()
        val hero = data.resume.firstOrNull()?.let { image(it, 1280) }
        cache.trim()
        return ShelfSnapshot(data, images, hero, offline)
    }
    override suspend fun continueWatching(): List<PlaybackItem> = suspendCoroutine { continuation ->
        executor.execute {
            val result = runCatching { refresh().data.resume.map { item ->
                val intent = Intent(context, ShelfPlaybackActivity::class.java).putExtra("item", item.id).putExtra("profile", store.profile)
                val account = store.account()
                val artwork = account?.let { store.cache().get(JellyfinApi(it.server, it.deviceId, it.token).image(item, 400)) }?.let(Uri::fromFile)
                PlaybackItem(item.id, item.title, artwork, item.position, item.duration,
                    PendingIntent.getActivity(context, item.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            } }.getOrDefault(emptyList())
            continuation.resume(result)
        }
    }
    override suspend fun nowPlaying(): PlaybackItem? = null
    companion object { private val executor = dev.streamybox.launcher.backgroundWorker("topshelf-provider") }
}

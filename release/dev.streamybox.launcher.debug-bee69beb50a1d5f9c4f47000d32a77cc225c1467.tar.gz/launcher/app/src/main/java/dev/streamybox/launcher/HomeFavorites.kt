package dev.streamybox.launcher

/** Default favourites per profile and the one-time cleanup of automatically created lists. */
object HomeFavorites {
    const val VERSION = 2
    val streaming = listOf("dev.streamarr.app", "org.jellyfin.androidtv", "org.smarttube.stable", "com.google.android.youtube.tv",
        "com.netflix.ninja", "com.disney.disneyplus", "com.amazon.amazonvideo.livingroom", "com.plexapp.android", "org.xbmc.kodi",
        "com.spotify.tv.android", "tv.twitch.android.app", "org.videolan.vlc")
    val stores = setOf("dev.streamybox.store", "org.fdroid.fdroid", "org.fdroid.basic", "com.aurora.store", "com.aurora.services",
        "com.android.vending", "com.machiav3lli.fdroid", "com.looker.droidify", "dev.imranr.obtainium", "nya.kitsunyan.foxydroid")
    /** Every list an earlier launcher pinned automatically starts with a subsequence of one of these, then dev.streamybox.* apps. */
    private val legacy = listOf(
        listOf("org.smarttube.stable", "org.jellyfin.androidtv"),
        listOf("org.smarttube.stable", "org.jellyfin.androidtv", "org.fdroid.fdroid", "com.aurora.store"),
        listOf("dev.streamybox.store", "org.smarttube.stable", "org.jellyfin.androidtv", "org.fdroid.fdroid", "com.aurora.store"),
        listOf("dev.streamybox.store", "org.smarttube.stable", "org.jellyfin.androidtv", "dev.streamarr.app", "org.fdroid.fdroid", "com.aurora.store"))

    fun excluded(pkg: String) = pkg in stores || pkg.startsWith("dev.streamybox.") || AppCuration.hiddenByDefault(pkg)
    fun defaults(apps: List<AppEntry>): List<String> {
        val available = apps.associateBy { it.packageName }
        return streaming.filter { it in available } +
            AppOrder.sorted(apps).filter { it.media && !it.system && it.packageName !in streaming && !excluded(it.packageName) }.map { it.packageName }
    }
    fun looksAutomatic(pins: List<String>, apps: List<AppEntry>): Boolean {
        val available = apps.map { it.packageName }.toSet()
        val present = pins.filter { it in available }
        if (present.isEmpty() || present.size != present.distinct().size) return false
        return legacy.any { known ->
            val head = present.takeWhile { it in known }
            head == known.filter { it in head } && present.drop(head.size).all { it.startsWith("dev.streamybox.") && !it.startsWith("dev.streamybox.launcher") }
        }
    }
    fun migrate(pins: List<String>, apps: List<AppEntry>): List<String> {
        val kept = pins.distinct().filterNot(::excluded).sortedBy { streaming.indexOf(it).takeIf { rank -> rank >= 0 } ?: streaming.size }
        return kept.ifEmpty { defaults(apps) }
    }
    /** New order after moving [pkg] by [delta] places, or to the front when [delta] is null. */
    fun move(pins: List<String>, pkg: String, delta: Int?): List<String> {
        val index = pins.indexOf(pkg)
        if (index < 0) return pins
        val target = if (delta == null) 0 else (index + delta).coerceIn(0, pins.lastIndex)
        return pins.toMutableList().apply { removeAt(index); add(target, pkg) }
    }
    fun parse(arg: String?): List<String> {
        val list = arg.orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }
        require(list.all { it.matches(Regex("[a-zA-Z0-9_.]+")) })
        return list.distinct()
    }
}

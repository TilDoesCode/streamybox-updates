package dev.streamybox.launcher

import android.os.Process
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Single-thread executor whose work (catalog, database, top shelf network and decoding) yields the CPU to the UI threads. */
internal fun backgroundWorker(name: String): ExecutorService = Executors.newSingleThreadExecutor { task ->
    Thread({ Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND); task.run() }, name)
}

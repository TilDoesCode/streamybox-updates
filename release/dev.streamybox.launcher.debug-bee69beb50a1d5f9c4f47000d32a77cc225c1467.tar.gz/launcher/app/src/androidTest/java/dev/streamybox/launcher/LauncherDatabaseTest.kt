package dev.streamybox.launcher

import android.test.AndroidTestCase

@Suppress("DEPRECATION")
class LauncherDatabaseTest : AndroidTestCase() {
    fun testPinOrderAndEmptyStateSurviveReload() {
        val ctx = context.createDeviceProtectedStorageContext()
        val profile="database-test-${java.util.UUID.randomUUID()}"
        val apps = listOf(AppEntry("org.smarttube.stable", "SmartTube"), AppEntry("org.jellyfin.androidtv", "Jellyfin"))
        LauncherDatabase(ctx,profile).use { db ->
            assertEquals(listOf("org.jellyfin.androidtv", "org.smarttube.stable"), db.synchronize(apps))
            db.savePins(listOf("org.smarttube.stable", "org.jellyfin.androidtv"))
        }
        LauncherDatabase(ctx,profile).use { db ->
            assertEquals(listOf("org.smarttube.stable", "org.jellyfin.androidtv"), db.synchronize(apps))
            db.savePins(emptyList())
        }
        LauncherDatabase(ctx,profile).use { db -> assertTrue(db.synchronize(apps).isEmpty()) }
        ctx.deleteDatabase("streamybox-$profile.db")
    }
    fun testProfilePreferencesAndPinOrderAreIsolated() {
        val ctx=context.createDeviceProtectedStorageContext()
        val a="database-test-${java.util.UUID.randomUUID()}";val b="database-test-${java.util.UUID.randomUUID()}"
        val appA="org.smarttube.stable";val appB="org.jellyfin.androidtv"
        val prefsA=dev.streamybox.profiles.contract.ProfileClient.preferences(ctx,a)
        val prefsB=dev.streamybox.profiles.contract.ProfileClient.preferences(ctx,b)
        try {
            assertTrue(prefsA.edit().putBoolean("light",true).putString("language","de").putString("motion","reduced").putStringSet("hidden",setOf(appA)).commit())
            assertTrue(prefsB.edit().putBoolean("light",false).putString("language","en").putString("motion","off").putStringSet("hidden",setOf(appB)).commit())
            LauncherDatabase(ctx,a).use { it.savePins(listOf(appB,appA)) }
            LauncherDatabase(ctx,b).use { it.savePins(listOf(appA)) }
            LauncherDatabase(ctx,a).use { assertEquals(listOf(appB,appA),it.readPins()) }
            LauncherDatabase(ctx,b).use { assertEquals(listOf(appA),it.readPins()) }
            assertEquals("de",prefsA.getString("language",null));assertEquals("en",prefsB.getString("language",null))
            assertTrue(prefsA.getBoolean("light",false));assertFalse(prefsB.getBoolean("light",true))
            assertEquals("reduced",prefsA.getString("motion",null));assertEquals("off",prefsB.getString("motion",null))
            assertEquals(setOf(appA),prefsA.getStringSet("hidden",emptySet()));assertEquals(setOf(appB),prefsB.getStringSet("hidden",emptySet()))
        } finally {
            prefsA.edit().clear().commit();prefsB.edit().clear().commit()
            ctx.deleteDatabase("streamybox-$a.db");ctx.deleteDatabase("streamybox-$b.db")
        }
    }
    private val box = listOf(AppEntry("dev.streamybox.store", "Streamybox Store"), AppEntry("org.smarttube.stable", "SmartTube"), AppEntry("org.jellyfin.androidtv", "Jellyfin"),
        AppEntry("dev.streamarr.app", "Streamarr"), AppEntry("org.fdroid.fdroid", "F-Droid"), AppEntry("com.aurora.store", "Aurora Store"))
    /** A database as the 1.6.0 launcher left it: pins and pinsInitialized only. */
    private fun legacy(ctx: android.content.Context, profile: String, pins: List<String>) = LauncherDatabase(ctx, profile).use { db ->
        db.synchronize(box); db.savePins(pins)
        db.writableDatabase.execSQL("DELETE FROM config WHERE key IN ('${LauncherDatabase.SOURCE}','${LauncherDatabase.FAVORITES}')")
    }
    fun testNewProfilesStartWithStreamingDefaults() {
        val ctx=context.createDeviceProtectedStorageContext(); val profile="favorites-test-${java.util.UUID.randomUUID()}"
        try {
            LauncherDatabase(ctx,profile).use { db ->
                assertEquals(listOf("dev.streamarr.app", "org.jellyfin.androidtv", "org.smarttube.stable"), db.synchronize(box))
                assertEquals(LauncherDatabase.AUTO, db.source())
            }
        } finally { ctx.deleteDatabase("streamybox-$profile.db") }
    }
    fun testAutomaticLegacyFavouritesAreCleanedOncePerProfile() {
        val ctx=context.createDeviceProtectedStorageContext()
        val a="favorites-test-${java.util.UUID.randomUUID()}";val b="favorites-test-${java.util.UUID.randomUUID()}"
        try {
            legacy(ctx, a, listOf("dev.streamybox.store", "org.smarttube.stable", "org.jellyfin.androidtv", "dev.streamarr.app", "org.fdroid.fdroid", "com.aurora.store"))
            legacy(ctx, b, listOf("org.fdroid.fdroid", "dev.streamybox.store", "org.jellyfin.androidtv"))
            LauncherDatabase(ctx,a).use { db ->
                assertEquals(listOf("dev.streamarr.app", "org.jellyfin.androidtv", "org.smarttube.stable"), db.synchronize(box))
                assertEquals(LauncherDatabase.AUTO, db.source())
                db.savePins(listOf("org.smarttube.stable", "dev.streamybox.store"))
            }
            LauncherDatabase(ctx,a).use { db -> assertEquals(listOf("org.smarttube.stable", "dev.streamybox.store"), db.synchronize(box)); assertEquals(LauncherDatabase.USER, db.source()) }
            LauncherDatabase(ctx,b).use { db -> assertEquals(listOf("org.fdroid.fdroid", "dev.streamybox.store", "org.jellyfin.androidtv"), db.synchronize(box)); assertEquals(LauncherDatabase.USER, db.source()) }
        } finally { ctx.deleteDatabase("streamybox-$a.db"); ctx.deleteDatabase("streamybox-$b.db") }
    }
    fun testMigrationWaitsForACatalogueAndKeepsAnEmptyChoice() {
        val ctx=context.createDeviceProtectedStorageContext()
        val a="favorites-test-${java.util.UUID.randomUUID()}";val b="favorites-test-${java.util.UUID.randomUUID()}"
        try {
            legacy(ctx, a, listOf("dev.streamybox.store", "org.smarttube.stable"))
            LauncherDatabase(ctx,a).use { db -> assertEquals(listOf("dev.streamybox.store", "org.smarttube.stable"), db.synchronize(emptyList())); assertNull(db.source()) }
            LauncherDatabase(ctx,a).use { db -> assertEquals(listOf("org.smarttube.stable"), db.synchronize(box)) }
            legacy(ctx, b, emptyList())
            LauncherDatabase(ctx,b).use { db -> assertTrue(db.synchronize(box).isEmpty()); assertEquals(LauncherDatabase.USER, db.source()) }
        } finally { ctx.deleteDatabase("streamybox-$a.db"); ctx.deleteDatabase("streamybox-$b.db") }
    }
    fun testCuratedCatalogOverridesAreProfileScoped() {
        val ctx=context.createDeviceProtectedStorageContext()
        val a="catalog-test-${java.util.UUID.randomUUID()}";val b="catalog-test-${java.util.UUID.randomUUID()}"
        val prefsA=dev.streamybox.profiles.contract.ProfileClient.preferences(ctx,a)
        val prefsB=dev.streamybox.profiles.contract.ProfileClient.preferences(ctx,b)
        try {
            assertTrue(AppCatalog(ctx,a).hidden("dev.streamybox.diag"))
            assertTrue(prefsA.edit().putStringSet("shown",setOf("dev.streamybox.diag")).putStringSet("hidden",setOf("org.jellyfin.androidtv")).commit())
            assertFalse(AppCatalog(ctx,a).hidden("dev.streamybox.diag"))
            assertTrue(AppCatalog(ctx,b).hidden("dev.streamybox.diag"))
            assertTrue(AppCatalog(ctx,a).hidden("org.jellyfin.androidtv"))
            assertFalse(AppCatalog(ctx,b).hidden("org.jellyfin.androidtv"))
        } finally { prefsA.edit().clear().commit();prefsB.edit().clear().commit() }
    }

}

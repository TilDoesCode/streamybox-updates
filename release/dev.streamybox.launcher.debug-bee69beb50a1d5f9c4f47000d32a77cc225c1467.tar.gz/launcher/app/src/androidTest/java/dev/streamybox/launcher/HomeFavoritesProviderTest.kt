@file:Suppress("DEPRECATION", "UNCHECKED_CAST")
package dev.streamybox.launcher

import android.net.Uri
import android.test.ActivityInstrumentationTestCase2
import android.view.View
import android.widget.TextView

class HomeFavoritesProviderTest : ActivityInstrumentationTestCase2<MainActivity>(MainActivity::class.java) {
    private val ctx get() = instrumentation.targetContext
    private val uri get() = Uri.parse("content://${ctx.packageName}.state")
    private fun state(method: String, arg: String? = null) = requireNotNull(ctx.contentResolver.call(uri, method, arg, null))
    private var saved: android.os.Bundle? = null
    private fun <T> field(name: String): T = MainActivity::class.java.getDeclaredField(name).apply { isAccessible = true }.get(activity) as T

    override fun setUp() {
        super.setUp()
        val client = dev.streamybox.profiles.contract.ProfileClient
        client.status(ctx)?.takeIf { it.optBoolean("pending") }?.let { client.call(ctx, "switch", org.json.JSONObject().put("id", it.getString("current"))) }
        saved = state("favorites")
        setActivityIntent(android.content.Intent().addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK))
    }
    override fun tearDown() {
        saved?.let { before ->
            val pins = before.getStringArrayList("pins").orEmpty()
            if (before.getString("source") == LauncherDatabase.AUTO && pins == before.getStringArrayList("defaults")) state("pins_reset") else state("pins", pins.joinToString(","))
        }
        super.tearDown()
    }
    private fun visible(bundle: android.os.Bundle): List<String> {
        val apps = org.json.JSONArray(bundle.getString("apps"))
        return (0 until apps.length()).map { apps.getJSONObject(it) }.filter { !it.getBoolean("hidden") }.map { it.getString("package") }
    }

    fun testPinsReorderResetAndRejectBadInput() {
        val apps = visible(state("favorites")).take(3)
        assertTrue("needs three visible apps, found $apps", apps.size == 3)
        state("pins", apps.reversed().joinToString(","))
        val after = state("favorites")
        assertEquals(apps.reversed(), after.getStringArrayList("pins")!!.filter { it in apps })
        assertEquals(LauncherDatabase.USER, after.getString("source"))
        state("pins", "not.installed.package,${apps[0]}")
        assertFalse("not.installed.package" in state("favorites").getStringArrayList("pins")!!)
        assertTrue(runCatching { state("pins", "evil;rm -rf") }.isFailure)
        state("pins_reset")
        val reset = state("favorites")
        assertEquals(LauncherDatabase.AUTO, reset.getString("source"))
        assertEquals(reset.getStringArrayList("defaults"), reset.getStringArrayList("pins")!!.filter { it in visible(reset) })
        assertTrue(reset.getStringArrayList("defaults")!!.none { HomeFavorites.excluded(it) })
    }

    fun testHomeRowEndsWithEditFavouritesWhichTargetsSettings() {
        val screen = activity
        val loading = MainActivity::class.java.getDeclaredField("loading").apply { isAccessible = true }
        val deadline = android.os.SystemClock.uptimeMillis() + 30000
        var label: String? = null
        while (label == null && android.os.SystemClock.uptimeMillis() < deadline) {
            instrumentation.runOnMainSync {
                if (!loading.getBoolean(screen)) label = field<Map<Pair<Int, Int>, TextView>>("labels").filterKeys { it.first == 1 }.maxByOrNull { it.key.second }?.value?.text?.toString()
            }
            if (label == null) Thread.sleep(100)
        }
        assertEquals(screen.getString(R.string.favoritesEdit), label)
        instrumentation.runOnMainSync { assertTrue(field<Map<Pair<Int, Int>, View>>("cards").filterKeys { it.first == 1 }.maxByOrNull { it.key.second }!!.value.isFocusable) }
        val target = ctx.packageManager.resolveActivity(FavoritesEditor.intent(), 0)?.activityInfo
        assertEquals("dev.streamybox.settings", target?.packageName)
    }
}

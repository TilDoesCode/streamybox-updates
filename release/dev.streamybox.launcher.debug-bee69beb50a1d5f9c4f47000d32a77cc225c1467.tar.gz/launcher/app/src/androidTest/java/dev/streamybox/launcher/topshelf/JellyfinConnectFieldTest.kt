@file:Suppress("DEPRECATION")
package dev.streamybox.launcher.topshelf

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.app.UiAutomation
import android.content.Intent
import android.graphics.Rect
import android.os.SystemClock
import android.test.InstrumentationTestCase
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import dev.streamybox.design.TextField
import dev.streamybox.launcher.R
import dev.streamybox.profiles.contract.ProfileClient
import org.json.JSONObject
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket

/** Top Shelf Jellyfin connect without a real server: inline server address (format, unreachable) and password sign-in against a loopback fake. */
class JellyfinConnectFieldTest : InstrumentationTestCase() {
    private lateinit var activity: Activity
    private var flags = 0
    private val ctx get() = instrumentation.targetContext
    private val automation get() = instrumentation.getUiAutomation(UiAutomation.FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES)
    private fun nodes(node: AccessibilityNodeInfo?): List<AccessibilityNodeInfo> = if (node == null) emptyList() else listOf(node) + (0 until node.childCount).flatMap { nodes(node.getChild(it)) }
    private fun keys(): List<AccessibilityNodeInfo> = automation.windows.flatMap { nodes(it.root) }.filter { it.packageName?.toString() == "dev.streamybox.keyboard" && it.text != null }
    private fun bounds(node: AccessibilityNodeInfo) = Rect().also { node.getBoundsInScreen(it) }
    private fun key(code: Int) { instrumentation.sendKeyDownUpSync(code); instrumentation.waitForIdleSync(); SystemClock.sleep(120) }
    private fun <T> main(block: () -> T): T { val box = arrayOfNulls<Any>(1); instrumentation.runOnMainSync { box[0] = block() }; @Suppress("UNCHECKED_CAST") return box[0] as T }
    private fun waitFor(message: String, ms: Long = 10_000, predicate: () -> Boolean) {
        val deadline = SystemClock.elapsedRealtime() + ms
        while (SystemClock.elapsedRealtime() < deadline) { if (predicate()) return; SystemClock.sleep(100) }
        fail(message)
    }
    private fun all(view: View): List<View> = listOf(view) + if (view is ViewGroup) (0 until view.childCount).flatMap { all(view.getChildAt(it)) } else emptyList()
    private fun text(id: Int) = activity.getString(id)
    /** Main thread only. */
    private fun field(tag: String): TextField? = activity.window.decorView.findViewWithTag(tag)
    private fun shown(label: String) = main { all(activity.window.decorView).any { it is TextView && it.isShown && it.text.toString() == label } }
    private fun ime() = main { activity.window.decorView.rootWindowInsets?.isVisible(WindowInsets.Type.ime()) == true }
    private fun focusedOn(tag: String) = main { field(tag)?.editor?.isFocused == true }
    private fun row(label: String) {
        waitFor("Missing row $label") { shown(label) }
        main {
            var target: View? = all(activity.window.decorView).first { it is TextView && it.text.toString() == label && it !is android.widget.EditText }
            while (target != null && !target.isFocusable) target = target.parent as? View
            assertTrue(requireNotNull(target).requestFocus())
        }
        key(KeyEvent.KEYCODE_DPAD_CENTER)
    }
    private fun keyboardReady() { waitFor("Streamybox keyboard did not open") { ime() && keys().any { it.isSelected } }; SystemClock.sleep(350) }
    private fun choose(text: String) {
        repeat(5) {
            val target = keys().first { it.text.toString() == text }
            val current = keys().first { it.isSelected }
            val y = bounds(target).centerY(); val currentY = bounds(current).centerY()
            if (y == currentY) return@repeat
            key(if (y < currentY) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN)
        }
        repeat(15) {
            val current = keys().first { it.isSelected }
            if (current.text.toString() == text) { key(KeyEvent.KEYCODE_DPAD_CENTER); return }
            key(KeyEvent.KEYCODE_DPAD_RIGHT)
        }
        fail("D-pad could not reach $text")
    }
    private fun store() = ShelfStore(ctx, ProfileClient.current(ctx))
    /** Starts the connect page on its first screen; false when this profile is already connected (the page then shows the account). */
    private fun open(): Boolean {
        if (!store().active() || store().account() != null) { println("ASSUMPTION: Top Shelf already connected or profile busy"); return false }
        activity = instrumentation.startActivitySync(Intent(ctx, JellyfinConnectActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        waitFor("Start rows missing") { shown(text(R.string.topshelf_manual)) }
        return true
    }

    override fun setUp() {
        super.setUp()
        val automation = automation
        flags = automation.serviceInfo.flags
        automation.serviceInfo = automation.serviceInfo.apply { flags = flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS }
    }
    override fun tearDown() {
        if (::activity.isInitialized) instrumentation.runOnMainSync { if (!activity.isFinishing) activity.finish() }
        automation.serviceInfo = automation.serviceInfo.apply { flags = this@JellyfinConnectFieldTest.flags }
        super.tearDown()
    }

    fun testServerAddressIsCheckedInlineAndBackSteps() {
        if (!open()) return
        row(text(R.string.topshelf_manual))
        waitFor("Server field not focused") { focusedOn("server-field") }
        assertFalse("Focusing the field must not open the keyboard", ime())
        key(KeyEvent.KEYCODE_DPAD_CENTER)
        keyboardReady()
        key(KeyEvent.KEYCODE_BACK)
        waitFor("BACK did not hide the keyboard") { !ime() }
        SystemClock.sleep(300)
        assertTrue("BACK with the keyboard open left the form", focusedOn("server-field"))
        main { field("server-field")!!.setText("foo bar") }
        row(text(R.string.topshelf_connect_action))
        waitFor("Invalid address shows no reason under the field") { shown(text(R.string.topshelf_server_invalid)) }
        assertTrue("Focus goes back to the field to fix it", focusedOn("server-field"))
        main { field("server-field")!!.setText("127.0.0.1:1") }
        row(text(R.string.topshelf_connect_action))
        waitFor("Unreachable server shows no reason under the field", 15_000) { shown(text(R.string.topshelf_server_unreachable)) }
        assertEquals("127.0.0.1:1", main { field("server-field")!!.text })
        assertTrue(focusedOn("server-field"))
        key(KeyEvent.KEYCODE_BACK)
        waitFor("BACK on the form did not return to the first screen") { main { field("server-field") == null } && shown(text(R.string.topshelf_discover)) }
    }

    fun testPasswordSignInWithKeyboardNextAndInlineErrors() {
        if (!open()) return
        FakeJellyfin().use { server ->
            try {
                row(text(R.string.topshelf_manual))
                waitFor("Server field not focused") { focusedOn("server-field") }
                main { field("server-field")!!.setText(server.url) }
                key(KeyEvent.KEYCODE_DPAD_CENTER)
                keyboardReady()
                choose(text(R.string.topshelf_connect_action))
                waitFor("Reachable server did not open the sign-in choices") { shown(text(R.string.topshelf_quick_connect)) }
                row(text(R.string.topshelf_password))
                waitFor("User name field not focused") { focusedOn("username-field") }
                row(text(R.string.topshelf_sign_in))
                waitFor("Empty user name shows no reason") { shown(text(R.string.topshelf_username_missing)) }
                assertEquals("No request without a user name", 0, server.attempts)
                waitFor("Focus did not return to the user name") { focusedOn("username-field") }
                key(KeyEvent.KEYCODE_DPAD_CENTER)
                keyboardReady()
                listOf("a", "n", "n", "a").forEach(::choose)
                choose(keys().first { it.text.toString() in listOf("Weiter", "Next") }.text.toString())
                waitFor("Next did not move to the password") { focusedOn("password-field") }
                waitFor("Next closed the keyboard") { ime() && keys().any { it.isSelected } }
                SystemClock.sleep(350)
                choose("x")
                choose(text(R.string.topshelf_sign_in))
                waitFor("Wrong password shows no reason under the field") { shown(text(R.string.topshelf_sign_in_failed)) }
                assertEquals(1, server.attempts)
                assertEquals("anna", main { field("username-field")!!.text })
                assertEquals("The password is not kept after a failed sign-in", "", main { field("password-field")!!.text })
                assertTrue("Focus is on the password after a failed sign-in", focusedOn("password-field"))
                main { field("password-field")!!.setText("geheim") }
                row(text(R.string.topshelf_sign_in))
                waitFor("Sign-in did not save the account") { store().account()?.name == "anna" }
                waitFor("Connected page missing") { shown(activity.getString(R.string.topshelf_connected, "anna")) }
            } finally { store().disconnect() }
        }
    }

    /** Loopback stand-in for the two endpoints the forms use. */
    private class FakeJellyfin : AutoCloseable {
        private val socket = ServerSocket(0, 8, InetAddress.getByName("127.0.0.1"))
        val url = "http://127.0.0.1:${socket.localPort}"
        @Volatile var attempts = 0
        init { Thread { while (!socket.isClosed) runCatching { socket.accept().use(::serve) } }.apply { isDaemon = true }.start() }
        private fun serve(client: Socket) {
            val input = client.getInputStream().bufferedReader()
            val path = input.readLine()?.split(' ')?.getOrNull(1) ?: return
            var length = 0
            while (true) { val line = input.readLine() ?: break; if (line.isEmpty()) break; if (line.startsWith("Content-Length:", true)) length = line.substringAfter(':').trim().toInt() }
            val body = CharArray(length).also { var read = 0; while (read < length) { val n = input.read(it, read, length - read); if (n < 0) break; read += n } }.concatToString()
            val (status, json) = when (path) {
                "/System/Info/Public" -> 200 to """{"ServerName":"Wohnzimmer","Version":"10.10.7","Id":"0123456789abcdef0123456789abcdef"}"""
                "/Users/AuthenticateByName" -> { attempts++; val sent = JSONObject(body); if (sent.optString("Username") == "anna" && sent.optString("Pw") == "geheim") 200 to """{"User":{"Id":"0123456789abcdef0123456789abcdef","Name":"anna"},"AccessToken":"loopbacktoken"}""" else 401 to "{}" }
                else -> 404 to "{}"
            }
            val bytes = json.toByteArray()
            client.getOutputStream().apply { write("HTTP/1.1 $status Fake\r\nContent-Type: application/json\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray()); write(bytes); flush() }
        }
        override fun close() = socket.close()
    }
}

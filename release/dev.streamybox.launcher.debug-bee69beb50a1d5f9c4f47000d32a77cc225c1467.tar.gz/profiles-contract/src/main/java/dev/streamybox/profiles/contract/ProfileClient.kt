package dev.streamybox.profiles.contract

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject

object ProfileClient {
    val uri: Uri=Uri.parse("content://dev.streamybox.profiles/state")
    private var held: android.content.ContentProviderClient?=null
    /** status runs on every HOME resume; a held unstable client skips getContentProvider, and status is safe to repeat if the provider died. */
    private fun request(context: Context,method: String,arg: String): android.os.Bundle? {
        if(method!="status") return context.contentResolver.call(uri,method,arg,null)
        val client=synchronized(this) { held ?: context.applicationContext.contentResolver.acquireUnstableContentProviderClient(uri).also { held=it } }
            ?: return context.contentResolver.call(uri,method,arg,null)
        return try { client.call(method,arg,null) } catch(_: android.os.DeadObjectException) {
            synchronized(this) { if(held===client) { held=null; client.close() } }
            context.contentResolver.call(uri,method,arg,null)
        }
    }
    fun call(context: Context,method: String,args: JSONObject=JSONObject()): JSONObject {
        val bundle=request(context,method,args.toString()) ?: error("Profile service unavailable")
        val result=JSONObject(requireNotNull(bundle.getString("json")))
        if (result.has("current")) {
            val cache=context.getSharedPreferences("profile-contract",0)
            val id=result.getString("current");val count=result.getJSONArray("profiles").length()
            if(cache.getString("current",null)!=id || cache.getInt("count",0)!=count)check(cache.edit().putString("current",id).putInt("count",count).commit())
        }
        if (!result.optBoolean("ok")) {
            val message=result.optString("error","Profile recovery blocked")
            throw ProfileError(result.optString("code").ifEmpty { if (message.contains("keystore",true)) "keystore" else "failed" },message)
        }
        return result
    }
    /** Plain-language reason for a failed request; technical details only where the user cannot act on the reason. */
    fun explain(context: Context,error: Throwable): String {
        val code=(error as? ProfileError)?.code ?: "failed"
        val text=context.getString(when(code) {
            "storage" -> R.string.profile_failure_storage; "app_running" -> R.string.profile_failure_app_running
            "cache_missing" -> R.string.profile_failure_cache_missing; "keystore" -> R.string.profile_failure_keystore
            "blocked" -> R.string.profile_failure_blocked; else -> R.string.profile_failure_failed
        })
        val details=error.message?.takeIf { it.isNotBlank() && code in setOf("blocked","failed") } ?: return text
        return text+"\n\n"+context.getString(R.string.profile_failure_details,details)
    }
    fun status(context: Context): JSONObject?=runCatching { call(context,"status") }.getOrNull()
    fun current(context: Context): String=current(context,status(context))
    /** [current] and [pending] for an already fetched [status], so one IPC can answer both. */
    fun current(context: Context,status: JSONObject?): String=status?.optString("current","default") ?: context.getSharedPreferences("profile-contract",0).getString("current","default")!!
    fun preferences(context: Context,id: String=current(context)): android.content.SharedPreferences { require(id.matches(Regex("[a-z0-9-]{1,64}"))); return context.getSharedPreferences(if(id=="default")"launcher" else "launcher-$id",0) }
    fun picker(context: Context) { context.startActivity(Intent().setClassName("dev.streamybox.profiles","dev.streamybox.profiles.PickerActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    /** Opens the picker, which switches to [id] right away with its usual loading screen and then goes home. */
    fun switchTo(context: Context,id: String) { context.startActivity(Intent().setClassName("dev.streamybox.profiles","dev.streamybox.profiles.PickerActivity").putExtra("switch",id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    /** Profile management lives in Settings › Profiles. */
    fun settings(context: Context,developer: Boolean=false) { context.startActivity(Intent().setClassName("dev.streamybox.settings","dev.streamybox.settings.MainActivity").putExtra("section","profiles").putExtra("developer",developer).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun pending(context: Context): Boolean=pending(context,status(context))
    fun pending(context: Context,status: JSONObject?): Boolean {
        if(status==null) return context.getSharedPreferences("profile-contract",0).getInt("count",0)>=2
        return status.optBoolean("pending") || status.optString("blocked").isNotEmpty()
    }
}
/** A profile request the service refused; [code] is storage, app_running, cache_missing, keystore, blocked or failed. */
class ProfileError(val code: String,message: String) : IllegalStateException(message)

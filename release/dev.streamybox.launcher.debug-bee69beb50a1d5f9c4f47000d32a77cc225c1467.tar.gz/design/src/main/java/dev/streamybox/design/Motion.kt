package dev.streamybox.design

import android.animation.ValueAnimator
import android.app.Dialog
import android.graphics.Rect
import android.content.Context
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import android.view.animation.Interpolator
import android.view.animation.PathInterpolator
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.roundToInt

object Motion {
    enum class Level { FULL, REDUCED, OFF }
    const val MICRO = 100L
    const val FOCUS = 170L
    const val STANDARD = 240L
    const val EMPHASIZED = 380L
    const val EXIT = 150L
    const val FOCUS_OUT = 70L
    const val STAGGER = 18L
    const val STAGGER_MAX = 220L
    const val SETTLE = 90L
    const val SHIFT = 20f
    val decelerate: Interpolator = PathInterpolator(.05f, .7f, .1f, 1f)
    val standard: Interpolator = PathInterpolator(.2f, 0f, 0f, 1f)
    val accelerate: Interpolator = PathInterpolator(.3f, 0f, .8f, .15f)

    var preference = Level.FULL
    val level: Level get() = if (!ValueAnimator.areAnimatorsEnabled()) Level.OFF else preference
    val moving get() = level == Level.FULL
    val animated get() = level != Level.OFF

    fun parse(value: String?) = when (value) { "reduced" -> Level.REDUCED; "off" -> Level.OFF; else -> Level.FULL }
    fun key(level: Level) = level.name.lowercase()
    fun duration(base: Long) = when (level) { Level.FULL -> base; Level.REDUCED -> base * 3 / 4; Level.OFF -> 0L }

    /** Fades [view] in, sliding by ([dx], [dy]) dp-scaled pixels when full motion is active. */
    fun enter(view: View, dx: Float = 0f, dy: Float = 0f, delay: Long = 0L, duration: Long = STANDARD, from: Float = 0f) {
        view.animate().cancel()
        if (!animated) { view.alpha = 1f; view.translationX = 0f; view.translationY = 0f; return }
        view.alpha = from
        view.translationX = if (moving) dx else 0f; view.translationY = if (moving) dy else 0f
        view.animate().alpha(1f).translationX(0f).translationY(0f).setStartDelay(delay).setDuration(duration(duration))
            .setInterpolator(decelerate).layered(view).start()
    }

    /** Fades [views] out, applies [change], then lets them enter from [shift]; a newer swap supersedes a running one. */
    fun swap(views: List<View>, shift: Float, change: () -> Unit) {
        if (!animated || views.isEmpty()) { change(); return }
        val arrive = Runnable { change(); views.forEachIndexed { i, view -> enter(view, shift, 0f, i * STAGGER) } }
        if (views[0].alpha < .05f) { arrive.run(); return }
        views.forEachIndexed { i, view ->
            view.animate().cancel()
            val out = view.animate().alpha(0f).translationX(if (moving) -shift * .4f else 0f).setStartDelay(0).setDuration(EXIT).setInterpolator(accelerate).layered(view)
            if (i == 0) out.withEndAction(arrive)
            out.start()
        }
    }

    /** Crossfades [old] into [fresh]: [fresh] takes its slot, [old] fades out in [host]'s overlay (one ghost per slot). */
    fun replace(old: View, fresh: View, host: android.view.ViewGroup, dx: Float, dy: Float) {
        val parent = old.parent as android.view.ViewGroup
        val index = parent.indexOfChild(old)
        (parent.getTag(R.id.sb_motion) as? View)?.let { it.animate().cancel(); host.overlay.remove(it) }
        val ghost = animated && old.isLaidOut && host.isAttachedToWindow
        val from = IntArray(2).also { old.getLocationInWindow(it) }
        val to = IntArray(2).also { host.getLocationInWindow(it) }
        parent.removeView(old)
        parent.addView(fresh, index, old.layoutParams)
        if (!ghost) return
        old.offsetLeftAndRight(from[0] - to[0] - old.left); old.offsetTopAndBottom(from[1] - to[1] - old.top)
        host.overlay.add(old); parent.setTag(R.id.sb_motion, old)
        old.animate().alpha(0f).translationX(if (moving) -dx * .4f else 0f).translationY(if (moving) -dy * .4f else 0f).setStartDelay(0)
            .setDuration(duration(EXIT)).setInterpolator(accelerate).layered(old)
            .withEndAction { host.overlay.remove(old); if (parent.getTag(R.id.sb_motion) === old) parent.setTag(R.id.sb_motion, null) }.start()
        enter(fresh, dx, dy, EXIT / 3)
    }

    /** A non-overlapping view (plain text, single drawable) fades identically without an offscreen layer and its pipelines. */
    private fun android.view.ViewPropertyAnimator.layered(view: View) = if (view.hasOverlappingRendering()) withLayer() else this

    fun dialog(dialog: Dialog) {
        dialog.window?.setWindowAnimations(when (level) { Level.FULL -> R.style.SbMotionScrim; Level.REDUCED -> R.style.SbMotionDialogReduced; Level.OFF -> 0 })
    }
}

/** Critically damped spring for a scroll offset: retargets mid-flight keeping velocity, never overshoots, no allocations per frame. */
class Glide(private val view: View, private val horizontal: Boolean) : Choreographer.FrameCallback {
    private var target = 0f
    private var position = 0f
    private var velocity = 0f
    private var last = 0L
    private var running = false
    private var pending = -1
    private val omega = 6.6f / (Motion.EMPHASIZED / 1000f)
    val destination get() = if (running) target.roundToInt() else current()
    private fun current() = if (horizontal) view.scrollX else view.scrollY
    fun to(value: Int) {
        target = value.toFloat()
        if (!Motion.animated || !view.isAttachedToWindow) { stop(); apply(value); return }
        if (!running) {
            position = current().toFloat(); velocity = 0f; last = 0L
            if (abs(position - target) < 1f) return
            running = true; Choreographer.getInstance().postFrameCallback(this)
        }
    }
    /** Jumps without animation, deferred until the scroller has been laid out. */
    fun jump(value: Int) { stop(); target = value.toFloat(); if (view.isLaidOut && !view.isLayoutRequested) apply(value) else pending = value }
    fun layout() { if (pending >= 0) { apply(pending); pending = -1 } }
    fun stop() { if (running) { running = false; Choreographer.getInstance().removeFrameCallback(this) } }
    private fun apply(value: Int) { if (horizontal) view.scrollTo(value, view.scrollY) else view.scrollTo(view.scrollX, value) }
    override fun doFrame(now: Long) {
        if (!running) return
        val dt = if (last == 0L) .016f else ((now - last) / 1e9f).coerceIn(.001f, .05f)
        last = now
        val x = position - target
        val decay = exp(-omega * dt)
        val c = velocity + omega * x
        position = target + (x + c * dt) * decay
        velocity = (velocity - omega * c * dt) * decay
        if (abs(position - target) < .5f && abs(velocity) < 8f) { position = target; running = false }
        apply(position.roundToInt())
        val reached = if (horizontal) view.scrollX else view.scrollY
        if (running && reached != position.roundToInt()) running = false
        if (running) Choreographer.getInstance().postFrameCallback(this)
    }
}

/** Horizontal scroller that never jumps on focus changes; callers glide it to an explicit offset. */
class GlideHorizontalScrollView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : HorizontalScrollView(context, attrs) {
    val glide = Glide(this, true)
    override fun computeScrollDeltaToGetChildRectOnScreen(rect: Rect) = 0
    override fun executeKeyEvent(event: android.view.KeyEvent) = false
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) { super.onLayout(changed, l, t, r, b); glide.layout() }
    override fun onDetachedFromWindow() { glide.stop(); super.onDetachedFromWindow() }
}

/** Vertical scroller whose focus-follow scrolling glides instead of jumping; [follow] off means callers drive it. */
class GlideScrollView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : ScrollView(context, attrs) {
    val glide = Glide(this, false)
    var follow = true
    override fun computeScrollDeltaToGetChildRectOnScreen(rect: Rect): Int {
        if (!follow || childCount == 0) return 0
        val from = glide.destination
        val margin = height / 8
        val top = from + margin; val bottom = from + height - margin
        val next = when {
            rect.bottom > bottom && rect.top > top -> from + minOf(rect.bottom - bottom, rect.top - top)
            rect.top < top && rect.bottom < bottom -> from - minOf(top - rect.top, bottom - rect.bottom)
            else -> from
        }
        if (next != from) glide.to(next.coerceIn(0, range()))
        return 0
    }
    private fun range() = (getChildAt(0).height - (height - paddingTop - paddingBottom)).coerceAtLeast(0)
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        val direction = when (event.keyCode) { android.view.KeyEvent.KEYCODE_DPAD_DOWN -> FOCUS_DOWN; android.view.KeyEvent.KEYCODE_DPAD_UP -> FOCUS_UP; else -> 0 }
        val focused = findFocus()
        if (follow && direction != 0 && event.action == android.view.KeyEvent.ACTION_DOWN && childCount > 0 && focused != null && android.view.FocusFinder.getInstance().findNextFocus(this, focused, direction).let { it == null || it === focused }) {
            val from = glide.destination
            val next = (from + (if (direction == FOCUS_DOWN) height / 3 else -height / 3)).coerceIn(0, range())
            if (next != from) { glide.to(next); return true }
        }
        return super.dispatchKeyEvent(event)
    }
    override fun executeKeyEvent(event: android.view.KeyEvent) = false
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) { super.onLayout(changed, l, t, r, b); glide.layout() }
    override fun onDetachedFromWindow() { glide.stop(); super.onDetachedFromWindow() }
}

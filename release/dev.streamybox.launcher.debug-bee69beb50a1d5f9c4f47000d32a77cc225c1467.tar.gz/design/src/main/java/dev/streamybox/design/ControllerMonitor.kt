package dev.streamybox.design

import android.content.Context
import android.hardware.input.InputManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import java.io.Closeable

class ControllerMonitor(context: Context, private val changed: (List<Controller>) -> Unit) : Closeable, InputManager.InputDeviceListener {
    data class Controller(val id: Int, val descriptor: String, val vendor: Int, val product: Int,
        val model: ControllerIdentity.Model, val player: Int, val battery: Int?, val device: InputDevice)
    private val input = context.getSystemService(InputManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private val slots = PlayerSlots()
    private var started = false
    @Volatile var controllers: List<Controller> = emptyList(); private set
    private val poll = object : Runnable { override fun run() { refresh(); if (started) handler.postDelayed(this, 30000) } }
    fun start() { if (!started) { started = true; input.registerInputDeviceListener(this, handler); handler.post(poll) } }
    private fun refresh() {
        val devices = input.inputDeviceIds.toList().mapNotNull(input::getInputDevice).filter(::isController)
        val order = controllers.map { it.id }.filter { id -> devices.any { it.id == id } } + devices.map { it.id }.filter { id -> controllers.none { it.id == id } }
        val players = slots.update(order.map(Int::toString))
        controllers = order.mapNotNull { id -> devices.find { it.id == id }?.let { d ->
            val battery = if (Build.VERSION.SDK_INT >= 31) runCatching { d.batteryState.takeIf { it.isPresent }?.capacity?.takeIf { it.isFinite() && it >= 0 }?.let { (it * 100).toInt().coerceIn(0, 100) } }.getOrNull() else null
            Controller(d.id, d.descriptor, d.vendorId, d.productId, ControllerIdentity.model(d.vendorId, d.productId, d.name), players.getValue(id.toString()), battery, d)
        } }
        changed(controllers)
    }
    override fun onInputDeviceAdded(deviceId: Int) = refresh()
    override fun onInputDeviceRemoved(deviceId: Int) = refresh()
    override fun onInputDeviceChanged(deviceId: Int) = refresh()
    override fun close() { started = false; input.unregisterInputDeviceListener(this); handler.removeCallbacksAndMessages(null) }
    companion object {
        private val known = java.util.WeakHashMap<InputDevice, Boolean>()
        /** Runs on every key event: the source check avoids the hasKeys binder calls for remotes and keyboards, the cache for pads. */
        fun isController(device: InputDevice?): Boolean {
            if (device == null || device.isVirtual || !device.supportsSource(InputDevice.SOURCE_GAMEPAD) && !device.supportsSource(InputDevice.SOURCE_JOYSTICK)) return false
            return synchronized(known) { known.getOrPut(device) { probe(device) } }
        }
        private fun probe(device: InputDevice): Boolean {
            val keys = device.hasKeys(KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B)
            val direction = device.getMotionRange(MotionEvent.AXIS_X) != null && device.getMotionRange(MotionEvent.AXIS_Y) != null ||
                device.getMotionRange(MotionEvent.AXIS_HAT_X) != null || device.hasKeys(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN).all { it }
            return ControllerIdentity.eligible(device.isVirtual, device.supportsSource(InputDevice.SOURCE_GAMEPAD), device.supportsSource(InputDevice.SOURCE_JOYSTICK), keys.all { it }, direction)
        }
    }
}

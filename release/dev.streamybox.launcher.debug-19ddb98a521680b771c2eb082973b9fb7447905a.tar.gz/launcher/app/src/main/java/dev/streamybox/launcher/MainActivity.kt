package dev.streamybox.launcher

import dev.streamybox.design.*
import android.app.Activity
import android.app.ActivityOptions
import android.app.Dialog
import android.content.*
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.os.*
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.math.*

private const val RISE = 2

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var catalog: AppCatalog
    private var profileStatus: org.json.JSONObject? = null
    private var profileId = "default"
    private val topShelf by lazy { dev.streamybox.launcher.topshelf.TopShelfHome(this, { profileId }) { scenes.clear(); buildHome() } }
    private lateinit var database: LauncherDatabase
    private lateinit var frame: FrameLayout
    private var stage: FrameLayout? = null
    private data class Scene(val stage: FrameLayout, val activate: () -> Unit)
    private val scenes = HashMap<String, Scene>()
    private var sceneConfiguration = ""
    private lateinit var prefs: android.content.SharedPreferences
    private var apps = emptyList<AppEntry>()
    private var pins = mutableListOf<String>()
    private val cursor = RemoteCursor()
    private var section = "home"
    private val grid get() = section != "home"
    private var tabFocus = false
    private var tabColumn = 0
    private var gridIndex = 0
    private var held = false
    private var pressing = false
    private var menuCount = 0
    private var lastMenu = 0L
    private var dialog: Dialog? = null
    private var status = DeviceStatus(false, false, "", false, "")
    private val cards = mutableMapOf<Pair<Int, Int>, View>()
    private val labels = mutableMapOf<Pair<Int, Int>, TextView>()
    private val rows = mutableMapOf<Int, GlideHorizontalScrollView>()
    private var gridScroll: GlideScrollView? = null
    private var heroName: TextView? = null
    private var heroBackdrop: ImageView? = null
    private var heroUnder: ImageView? = null
    private var heroArt: FrameLayout? = null
    private var heroShown: String? = null
    private var signature = ""
    private var resumed = false
    private var launched = false
    private var heroIcon: ImageView? = null
    private var clock: TextView? = null
    private var networkIcon: ImageView? = null
    private val arts = HashMap<String, Bitmap>()
    private var scale = 1f
    private var viewportWidth = 0
    private var loading = false
    private val dark get() = !prefs.getBoolean("light", false)
    private val layout get() = HomeLayout.parse(prefs.getString("home_layout", null))
    private var cachedDesign: TvDesign? = null
    private val design: TvDesign get() = cachedDesign?.takeIf { it.light == !dark && it.scale == scale } ?: TvDesign(this, !dark, scale).also { cachedDesign = it }
    private val settle = Runnable { if (!grid) hero(current(), true) }
    private val foreground get() = design.foreground
    private val hold = Runnable { if (pressing) { held = true; contextMenu() } }
    private val tick = object : Runnable {
        override fun run() {
            clock?.setTextIfChanged(time())
            refreshStatus()
            handler.postDelayed(this, 15000)
        }
    }
    private var artStale = false
    private val packages = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { artStale = true; loadApps() }
    }
    private val connectivity = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { refreshStatus() }
        override fun onLost(network: Network) { refreshStatus() }
        override fun onCapabilitiesChanged(network: Network, caps: android.net.NetworkCapabilities) { refreshStatus() }
    }

    override fun attachBaseContext(base: Context) {
        val language = dev.streamybox.profiles.contract.ProfileClient.preferences(base).getString("language", "en")
        val configuration = Configuration(base.resources.configuration)
        if (language != null) configuration.setLocale(Locale.forLanguageTag(language))
        super.attachBaseContext(base.createConfigurationContext(configuration))
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) ControllerWake.request(this)
        ControllerNavigation.install(window, tab = { delta -> activate(Tile("tab_${sectionIds[(sectionIds.indexOf(section) + delta).coerceIn(0, sectionIds.lastIndex)]}", "")) }, menu = { contextMenu() })
        profileStatus = dev.streamybox.profiles.contract.ProfileClient.status(this)
        profileId = profileStatus?.getString("current") ?: dev.streamybox.profiles.contract.ProfileClient.current(this)
        prefs = dev.streamybox.profiles.contract.ProfileClient.preferences(this, profileId)
        catalog = AppCatalog(this, profileId)
        database = LauncherDatabase(this, profileId)
        immersive()
        frame = FrameLayout(this).apply { clipChildren = false }
        setContentView(frame)
        buildHome()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        registerReceiver(packages, filter)
        getSystemService(ConnectivityManager::class.java).registerDefaultNetworkCallback(connectivity)
        handler.post(tick)
    }
    override fun onResume() {
        super.onResume()
        HomeHealth.resume(this)
        sendBroadcast(android.content.Intent("dev.streamybox.action.HOME_VISIBLE").setComponent(android.content.ComponentName("dev.streamybox.settings", "dev.streamybox.settings.HomeRecoveryReceiver")), "dev.streamybox.permission.LAUNCHER_STATE")
        KeyServiceGuard.check(this)
        profileStatus = dev.streamybox.profiles.contract.ProfileClient.status(this)
        if (profileId != dev.streamybox.profiles.contract.ProfileClient.current(this)) { recreate(); return }
        if (dev.streamybox.profiles.contract.ProfileClient.pending(this)) { dev.streamybox.profiles.contract.ProfileClient.picker(this); return }
        val language = prefs.getString("language", "en")
        if (language != resources.configuration.locales[0].language) { recreate(); return }
        resumed = true
        Motion.preference = Motion.parse(prefs.getString("motion", null))
        immersive()
        if (signature != signature()) buildHome() else if (launched) land()
        launched = false
        loadApps(); topShelf.resume()
    }
    override fun onPause() { topShelf.pause(); resumed = false; super.onPause() }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); topShelf.refresh()
        if (intent.hasCategory(Intent.CATEGORY_HOME)) { ControllerWake.request(this); if (dev.streamybox.profiles.contract.ProfileClient.pending(this)) dev.streamybox.profiles.contract.ProfileClient.picker(this) else home() }
    }
    override fun onConfigurationChanged(configuration: Configuration) {
        super.onConfigurationChanged(configuration)
        immersive(); scenes.clear()
        handler.postDelayed({ if (!isDestroyed) buildHome() }, 250)
    }
    override fun onDestroy() {
        ControllerNavigation.uninstall(window)
        topShelf.close(); handler.removeCallbacksAndMessages(null)
        unregisterReceiver(packages)
        getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(connectivity)
        worker.execute { database.close() }
        worker.shutdown()
        dialog?.dismiss()
        super.onDestroy()
    }
    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
    private fun loadApps() {
        if (loading) return
        loading = true
        val light = !dark
        val cached = arts.toMap()
        worker.execute {
            val prepared = HashMap<String, Bitmap>()
            val result = runCatching {
                val list = catalog.applications()
                val order = database.synchronize(list)
                val tiles = list.map { Tile(it.packageName, it.label, it) } +
                    (sectionIds.map { "tab_$it" } + listOf("apps", "settings", "quick")).map { Tile(it, "") }
                for (tile in tiles) for (spot in listOf(false, true)) {
                    val key = "${tone(tile)}/${!light}/$spot"
                    if (key !in prepared) prepared[key] = cached[key] ?: Ambience.render(tone(tile), light, spot).apply { prepareToDraw() }
                }
                list to order
            }
            handler.post {
                loading = false
                if (isDestroyed) return@post
                result.onSuccess { (list, order) ->
                    val changed = list != apps || order != pins
                    if (light == !dark) { arts.clear(); arts.putAll(prepared) }
                    apps = list; pins = order.toMutableList()
                    cursor.column = cursor.column.coerceIn(0, (tiles(cursor.row).size - 1).coerceAtLeast(0))
                    gridIndex = gridIndex.coerceIn(0, (gridApps().size - 1).coerceAtLeast(0))
                    if (changed || artStale) { artStale = false; scenes.clear(); appArt.clear(); buildHome() }
                }.onFailure { toast(R.string.launchFailed) }
            }
        }
    }
    private fun refreshStatus() {
        if (worker.isShutdown) return
        worker.execute {
            val next = DeviceStatus.read(this)
            handler.post {
                if (isDestroyed) return@post
                status = next
                networkIcon?.contentDescription = getString(if (next.online) R.string.online else if (next.connected) R.string.localNetwork else R.string.offline)
                networkIcon?.setImageDrawable(Glyph(next.transport.glyph, design.muted))
            }
        }
    }

    private data class Tile(val id: String, val label: String, val app: AppEntry? = null)
    private val sectionIds = listOf("home", "media", "extras", "apps")
    private fun sectionLabel(id: String) = getString(when (id) { "media" -> R.string.media; "extras" -> R.string.extras; "apps" -> R.string.apps; else -> R.string.home })
    private fun tiles(row: Int): List<Tile> = when (row) {
        0 -> sectionIds.map { Tile("tab_$it", sectionLabel(it)) } + Tile("quick", getString(R.string.quickMenu)) + if (avatarShown()) listOf(Tile("profile", getString(if (hasProfiles()) R.string.profileSwitch else R.string.profilesManage))) else emptyList()
        1 -> pins.mapNotNull { pkg -> apps.find { it.packageName == pkg } }.map { Tile(it.packageName, it.label, it) } +
            listOf(Tile("apps", getString(R.string.apps)), Tile("settings", getString(R.string.settings)), Tile(FavoritesEditor.TILE, getString(R.string.favoritesEdit)))
        else -> apps.map { Tile(it.packageName, it.label, it) }
    }
    private fun gridApps() = when (section) { "media" -> apps.filter { it.media }; "extras" -> apps.filter { !it.media }; else -> apps }
    private fun current(): Tile = when {
        grid && tabFocus -> tiles(0)[tabColumn]
        grid -> gridApps().getOrNull(gridIndex)?.let { Tile(it.packageName, it.label, it) } ?: tiles(0)[sectionIds.indexOf(section)]
        else -> tiles(cursor.row).getOrElse(cursor.column) { tiles(1).first() }
    }
    private fun dp(value: Float) = (value * scale * resources.displayMetrics.density).roundToInt()
    private fun text(value: String, size: Float, tint: Int = foreground, bold: Boolean = false, weight: Int = if (bold) 600 else 400) =
        design.text(value, size, tint, weight = weight).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
    private fun place(parent: FrameLayout, view: View, x: Float, y: Float, w: Float, h: Float) {
        parent.addView(view, FrameLayout.LayoutParams(if (w < 0) -2 else dp(w), dp(h)).apply { leftMargin = dp(x); topMargin = dp(y) })
    }
    private fun alpha(color: Int, value: Int) = Color.argb(value, Color.red(color), Color.green(color), Color.blue(color))
    private fun kind(tile: Tile): AppIcon.Kind = when (tile.id) {
        "apps", "tab_apps" -> AppIcon.Kind.APPS; "settings" -> AppIcon.Kind.SETTINGS; "tab_home" -> AppIcon.Kind.BRAND; FavoritesEditor.TILE -> AppIcon.Kind.FAVORITES
        "tab_media" -> AppIcon.Kind.MEDIA; "tab_extras" -> AppIcon.Kind.SYSTEM; else -> AppIcon.kind(tile.id)
    }
    private fun tone(tile: Tile) = AppIcon.tone(kind(tile), tile.id)
    private val appArt by lazy { AppArt(catalog, resources) }
    private fun icon(tile: Tile): android.graphics.drawable.Drawable {
        val own = tile.app?.takeIf { kind(tile) == AppIcon.Kind.GENERIC || it.packageName == "dev.streamarr.app" }?.let { appArt.icon(it) }
        return own?.let { dev.streamybox.design.PackageIcon(it) } ?: AppIcon(kind(tile), Color.parseColor(if (dark) "#DCE2EC" else "#3A4558"),
            tile.label.take(1).uppercase(resources.configuration.locales[0]), Fonts.get(this, 650), tone(tile), !dark)
    }
    private fun art(tile: Tile, spot: Boolean = true): Bitmap = arts.getOrPut("${tone(tile)}/$dark/$spot") { Ambience.render(tone(tile), !dark, spot).apply { prepareToDraw() } }
    private fun time(): String {
        val locale = resources.configuration.locales[0]
        val skeleton = when (android.provider.Settings.System.getString(contentResolver, android.provider.Settings.System.TIME_12_24)) { "24" -> "Hm"; "12" -> "hm"; else -> "jm" }
        return SimpleDateFormat(android.text.format.DateFormat.getBestDateTimePattern(locale, skeleton), locale).format(Date())
    }
    private fun signature() = "$dark|${layout.favoritesOnly}|${Motion.level}|$section|$viewportWidth|${hasProfiles()}|${avatarShown()}|$profileId|${profileStatus?.optJSONArray("profiles")}"
    private fun buildHome(direction: Int = 0) {
        Motion.preference = Motion.parse(prefs.getString("motion", null))
        scale = (viewportWidth.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels) / resources.displayMetrics.density / 960f
        val configuration = "$dark|${Motion.level}|$viewportWidth|${resources.displayMetrics.densityDpi}|${resources.configuration.fontScale}"
        if (configuration != sceneConfiguration) { scenes.clear(); sceneConfiguration = configuration }
        val key = signature()
        cursor.row = cursor.row.coerceAtMost(layout.rows.size)
        handler.removeCallbacks(settle)
        stage?.let { stopScene(it) }
        frame.removeAllViews()
        scenes[key]?.takeUnless { !grid && topShelf.populated }?.let { scene ->
            scene.activate(); scene.stage.alpha = 1f
            frame.addView(scene.stage, FrameLayout.LayoutParams(-1, -1))
            rows.values.forEach { it.glide.jump(0) }; gridScroll?.glide?.jump(0)
            clock?.setTextIfChanged(time()); updateFocus(false); refreshStatus(); signature = key
            if (direction != 0 && resumed) arrive(direction)
            return
        }
        val stage = object : FrameLayout(this) {
            override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
                super.onSizeChanged(w, h, oldw, oldh)
                if (w > 0 && w != viewportWidth) {
                    viewportWidth = w; scenes.clear()
                    handler.post { if (!isDestroyed) buildHome() }
                }
            }
        }
        this.stage = stage
        val ui = design
        stage.background = if (grid) ui.backdrop() else android.graphics.drawable.ColorDrawable(ui.background); stage.clipChildren = false
        frame.addView(stage, 0, FrameLayout.LayoutParams(-1, -1))
        cards.clear(); labels.clear(); rows.clear(); gridScroll = null; heroBackdrop = null; heroUnder = null; heroIcon = null; heroShown = null; heroArt = null
        handler.removeCallbacks(settle)
        if (grid) {
            val backdrop = stage.background
            stage.background = null
            stage.addView(View(this).apply { background = backdrop; setLayerType(View.LAYER_TYPE_HARDWARE, null) }, FrameLayout.LayoutParams(-1, -1))
        } else buildHero(ui)
        topBar(ui)
        if (grid) buildGrid(ui) else {
            buildRow(ui, 1, getString(R.string.pinned), layout.pinned)
            layout.all?.let { buildRow(ui, 2, getString(R.string.allApps), it) }
            place(stage, PlaybackPlaceholder(this), 0f, 0f, 0f, 0f)
        }
        updateFocus(false); refreshStatus()
        signature = signature()
        if (!grid) topShelf.attach(stage, ui, pins.mapNotNull { pkg -> apps.find { it.packageName == pkg } }, if (layout.favoritesOnly) emptyList() else apps, { app -> catalog.launch(app, options()) }, { app -> contextMenu(app) }, { app -> icon(Tile(app.packageName, app.label, app)) }, { if (!FavoritesEditor.open(this)) toast(R.string.launchFailed) })
        rememberScene(key, stage)
        if (direction != 0 && resumed) arrive(direction)
    }
    private fun stopScene(view: View) {
        view.animate().cancel(); view.alpha = 1f; view.translationX = 0f; view.translationY = 0f
        view.jumpDrawablesToCurrentState()
        if (view is GlideHorizontalScrollView) view.glide.stop()
        if (view is GlideScrollView) view.glide.stop()
        if (view is ViewGroup) for (i in 0 until view.childCount) stopScene(view.getChildAt(i))
    }
    private fun rememberScene(key: String, stage: FrameLayout) {
        val savedCards = cards.toMap(); val savedLabels = labels.toMap(); val savedRows = rows.toMap()
        val savedGridScroll = gridScroll; val savedHeroArt = heroArt
        val savedHeroName = heroName; val savedHeroBackdrop = heroBackdrop; val savedHeroUnder = heroUnder
        val savedHeroIcon = heroIcon; val savedClock = clock; val savedNetwork = networkIcon
        scenes[key] = Scene(stage) {
            this.stage = stage
            cards.clear(); cards.putAll(savedCards); labels.clear(); labels.putAll(savedLabels); rows.clear(); rows.putAll(savedRows)
            gridScroll = savedGridScroll; heroArt = savedHeroArt
            heroName = savedHeroName; heroBackdrop = savedHeroBackdrop; heroUnder = savedHeroUnder
            heroIcon = savedHeroIcon; clock = savedClock; networkIcon = savedNetwork
            heroShown = null
        }
    }
    private fun arrive(direction: Int) {
        val shift = dp(Motion.SHIFT).toFloat()
        val dx = if (direction == RISE) 0f else direction * shift
        val dy = if (direction == RISE) shift * .7f else 0f
        if (grid) {
            for ((key, card) in cards) {
                if (key.first != 3) continue
                val index = key.second
                if (index >= 24) break
                val delay = minOf((index / 6 * 2 + index % 6) * Motion.STAGGER, Motion.STAGGER_MAX)
                Motion.enter(card, dx, dy, delay)
                labels[key]?.let { Motion.enter(it, dx, dy, delay) }
            }
        } else {
            listOfNotNull(heroName, heroIcon).forEachIndexed { i, view -> Motion.enter(view, dx, dy, i * Motion.STAGGER) }
            rows.values.forEachIndexed { i, row -> Motion.enter(row, dx, dy, (i + 2) * Motion.STAGGER * 2) }
        }
    }
    private fun land() {
        val card = cards[if (grid && tabFocus) 0 to tabColumn else if (grid) 3 to gridIndex else cursor.row to cursor.column] ?: return
        if (!Motion.moving) return
        val zoom = card.scaleX
        card.setTag(dev.streamybox.design.R.id.sb_motion, zoom)
        card.scaleX = 1f; card.scaleY = 1f
        card.animate().scaleX(zoom).scaleY(zoom).setStartDelay(Motion.STANDARD).setDuration(Motion.EMPHASIZED).setInterpolator(Motion.decelerate).start()
    }
    private fun buildHero(ui: TvDesign) {
        val stage = stage!!
        val base = ui.background
        val home = layout; val tall = home.heroHeight
        val artHost = FrameLayout(this).apply { setLayerType(View.LAYER_TYPE_HARDWARE, null) }.also { heroArt = it }
        place(stage, artHost, 0f, 0f, 960f, tall)
        heroUnder = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; outlineProvider = ViewOutlineProvider.BOUNDS; clipToOutline = true }
        place(artHost, heroUnder!!, 0f, 0f, 960f, tall - 2f)
        heroBackdrop = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; outlineProvider = ViewOutlineProvider.BOUNDS; clipToOutline = true }
        place(artHost, heroBackdrop!!, 0f, 0f, 960f, tall - 2f)
        place(artHost, View(this).apply { background = ui.gradient(GradientDrawable.Orientation.LEFT_RIGHT, alpha(base, 235), alpha(base, 175), alpha(base, 40), Color.TRANSPARENT) }, 0f, 0f, 760f, tall - 2f)
        place(artHost, View(this).apply { background = ui.gradient(GradientDrawable.Orientation.TOP_BOTTOM, alpha(base, 150), Color.TRANSPARENT) }, 0f, 0f, 960f, 100f)
        place(artHost, View(this).apply { background = ui.gradient(GradientDrawable.Orientation.TOP_BOTTOM, Color.TRANSPARENT, alpha(base, 210), base) }, 0f, tall - 142f, 960f, 142f)
        heroIcon = ImageView(this)
        place(stage, heroIcon!!, home.iconX, home.iconY, home.iconSize, home.iconSize)
        heroName = text("", home.nameSize, weight = 650).apply { letterSpacing = -.02f; gravity = Gravity.CENTER_VERTICAL; includeFontPadding = false }
        place(stage, heroName!!, HomeLayout.NAME_X, home.nameY, home.nameWidth, home.nameHeight)
    }
    private fun hasProfiles() = (profileStatus?.optJSONArray("profiles")?.length() ?: 0) >= 2
    private fun avatarShown() = (profileStatus?.optJSONArray("profiles")?.length() ?: 0) >= 1
    private fun profileTap() = if (hasProfiles()) dev.streamybox.profiles.contract.ProfileClient.picker(this) else dev.streamybox.profiles.contract.ProfileClient.settings(this)
    private fun topBar(ui: TvDesign) {
        val stage = stage!!
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }
        tiles(0).take(sectionIds.size).forEachIndexed { i, tile ->
            val tab = ui.pill(tile.label, sectionIds[i] == section).apply {
                textSize = 14.5f * scale; setPadding(dp(17f), 0, dp(17f), 0); isFocusable = true; contentDescription = tile.label
                setOnClickListener { if (grid) { tabFocus = true; tabColumn = i } else { cursor.row = 0; cursor.column = i }; activate(tile) }
            }
            tabs.addView(tab, LinearLayout.LayoutParams(-2, -1).apply { marginEnd = dp(4f) })
            cards[0 to i] = tab
        }
        place(stage, tabs, HomeLayout.TABS_X, 22f, -1f, 34f)
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; clipChildren = false; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        fun slot(view: View, w: Int = dp(36f), gap: Float = 5f) = bar.addView(view, LinearLayout.LayoutParams(w, dp(36f)).apply { marginStart = if (bar.childCount == 0) 0 else dp(gap) })
        slot(ControllerBadge(this, ui), -2)
        networkIcon = ui.glyph(Glyph.Kind.OFFLINE, ui.muted)
        val quick = FrameLayout(this).apply {
            isFocusable = true; contentDescription = getString(R.string.quickMenu); setOnClickListener { quickMenu() }
            ui.style(this, FocusStyle(Color.TRANSPARENT, null, ui.chipFocus, ui.radii(TvDesign.PILL), 1f))
        }
        place(quick, networkIcon!!, 8f, 8f, 20f, 20f)
        slot(quick); cards[0 to sectionIds.size] = quick
        clock = text(time(), 17f, alpha(ui.foreground, 220), weight = 450).apply { gravity = Gravity.CENTER_VERTICAL; includeFontPadding = false; setPadding(0, dp(1f), 0, 0) }
        slot(clock!!, -2)
        if (avatarShown()) {
            val status = profileStatus!!
            val profiles = status.getJSONArray("profiles")
            val p = (0 until profiles.length()).map { profiles.getJSONObject(it) }.let { all -> all.firstOrNull { it.getString("id") == status.optString("current") } ?: all.first() }
            val avatar = ui.text(p.getString("name").take(1).uppercase(), 15f, Color.WHITE, weight = 600).apply {
                gravity = Gravity.CENTER; isFocusable = true; contentDescription = getString(if (hasProfiles()) R.string.profileSwitch else R.string.profilesManage); includeFontPadding = false
                ui.style(this, ui.cardStyle(TvDesign.PILL, 1.06f, p.getInt("color")))
                setOnFocusChangeListener { view, focused -> ui.focus(view, focused) }
                setOnClickListener { profileTap() }
            }
            bar.addView(avatar, LinearLayout.LayoutParams(dp(32f), dp(32f)).apply { marginStart = dp(15f) }); cards[0 to sectionIds.size + 1] = avatar
        }
        stage.addView(bar, FrameLayout.LayoutParams(-2, dp(36f), Gravity.TOP or Gravity.END).apply { topMargin = dp(21f); rightMargin = dp(56f) })
    }
    private fun buildRow(ui: TvDesign, row: Int, title: String, spec: HomeLayout.Row) {
        val stage = stage!!
        val list = tiles(row)
        place(stage, text(title, 15f, weight = 600), 56f, spec.titleY, 700f, 20f)
        val scroll = GlideHorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; clipChildren = false; clipToPadding = false; setPadding(dp(56f), dp(10f), dp(56f), dp(12f)) }
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false; clipToPadding = false }
        scroll.addView(line)
        list.forEachIndexed { i, tile ->
            val view = if (row == 1) poster(ui, tile, i, spec) else tile(ui, tile, row, i, spec.width, spec.height, true)
            line.addView(view, LinearLayout.LayoutParams(dp(spec.width), dp(spec.height + spec.labelHeight)).apply { if (i != list.lastIndex) rightMargin = dp(spec.gap) })
        }
        place(stage, scroll, 0f, spec.top, 960f, spec.bottom - spec.top + 12f)
        rows[row] = scroll
    }
    private fun face(tile: Tile, row: Int, index: Int) = FrameLayout(this).apply {
        clipToOutline = true; isFocusable = true; isFocusableInTouchMode = true
        contentDescription = "${tile.label}. ${getString(R.string.openHint)}"
        setOnClickListener { pick(row, index); updateFocus(); activate(tile) }
        setOnLongClickListener { pick(row, index); contextMenu(); true }
    }
    private fun pick(row: Int, index: Int) { if (grid) { tabFocus = false; gridIndex = index } else { cursor.row = row; cursor.column = index } }
    private fun poster(ui: TvDesign, tile: Tile, index: Int, spec: HomeLayout.Row): View {
        val face = face(tile, 1, index)
        ui.style(face, ui.cardStyle(14f, 1.04f))
        val banner = tile.app?.takeIf { kind(tile) == AppIcon.Kind.GENERIC || it.packageName == "dev.streamarr.app" }?.let { appArt.banner(it, dark) }
        val card = FavoriteCard.build(ui, face, spec, tile.label, banner ?: android.graphics.drawable.BitmapDrawable(resources, art(tile, false)), if (banner == null) icon(tile) else null)
        cards[1 to index] = face; labels[1 to index] = card.label
        return card.root
    }
    private fun tile(ui: TvDesign, tile: Tile, row: Int, index: Int, width: Float, height: Float, caption: Boolean): View {
        val face = face(tile, row, index)
        val hue = tone(tile)
        ui.style(face, FocusStyle(Ambience.mix(ui.surface, hue, .1f), ui.tileBorder(hue), Ambience.mix(ui.surface, hue, .1f), ui.radii(14f), 1.05f, ui.ring, 1.75f, 6f))
        place(face, View(this).apply { background = ui.tile(hue) }, 0f, 0f, width, height)
        val size = if (caption) height * .38f else height * .46f
        place(face, ImageView(this).apply { setImageDrawable(icon(tile)) }, (width - size) / 2, if (caption) height * .16f else (height - size) / 2, size, size)
        if (caption) place(face, text(tile.label, 11.5f, ui.foreground, weight = 500).apply { gravity = Gravity.CENTER }, 6f, height * .63f, width - 12f, height * .26f)
        cards[row to index] = face
        return face
    }
    private fun buildGrid(ui: TvDesign) {
        val stage = stage!!
        val list = gridApps()
        if (list.isEmpty()) place(stage, text(getString(R.string.empty), 16f, ui.muted).apply { gravity = Gravity.CENTER }, 0f, 240f, 960f, 30f)
        val scroll = GlideScrollView(this).apply { follow = false; clipChildren = false; clipToPadding = false; isVerticalScrollBarEnabled = false; setPadding(dp(48f), dp(18f), dp(48f), dp(24f)) }
        val content = FrameLayout(this).apply { clipChildren = false; clipToPadding = false }
        list.forEachIndexed { i, app ->
            val x = (i % 6) * 146.8f; val y = (i / 6) * 120f
            place(content, tile(ui, Tile(app.packageName, app.label, app), 3, i, 130f, 78f, false), x, y, 130f, 78f)
            val label = text(app.label, 12.5f, ui.muted, weight = 500).apply { gravity = Gravity.CENTER }
            place(content, label, x - 6f, y + 88f, 142f, 18f)
            labels[3 to i] = label
        }
        scroll.addView(content, ViewGroup.LayoutParams(dp(864f), dp(ceil(list.size / 6f) * 120f)))
        place(stage, scroll, 0f, 80f, 960f, 460f)
        gridScroll = scroll
    }
    private fun updateFocus(animate: Boolean = true) {
        val chosen = when { grid && tabFocus -> 0 to tabColumn; grid -> 3 to gridIndex; else -> cursor.row to cursor.column }
        val ui = design
        cards.forEach { (key, view) ->
            val focused = chosen == key
            ui.focus(view, focused, animate)
            view.isSelected = focused
            if (key.first == 0 && key.second in sectionIds.indices && view is TextView) view.setTextColor(if (focused || sectionIds[key.second] == section) ui.foreground else ui.muted)
            if (key.first == 0 && view is FrameLayout) ((view.getChildAt(0) as ImageView).drawable as Glyph).tint(if (focused) ui.foreground else ui.muted)
            if (focused) view.requestFocus()
        }
        labels.forEach { (key, label) -> label.setTextColor(if (key == chosen) ui.foreground else ui.muted) }
        val spec = layout.rows.getOrNull(cursor.row - 1)
        val offset = if (grid) dp(max(0, gridIndex / 6 - 1) * 120f) else dp(max(0, cursor.column - (spec?.lead ?: 0)) * (spec?.step ?: 0f))
        val glide = if (grid) gridScroll?.glide else rows[cursor.row]?.glide
        if (animate) glide?.to(offset) else glide?.jump(offset)
        if (grid) return
        handler.removeCallbacks(settle)
        if (animate && Motion.animated) handler.postDelayed(settle, Motion.SETTLE) else hero(current(), false)
    }
    private fun hero(tile: Tile, animate: Boolean) {
        if (heroShown == tile.id && animate) return
        val previous = heroShown
        heroShown = tile.id
        val content: () -> Unit = {
            heroName?.setTextIfChanged(if (tile.id == "tab_home") "Streamybox" else tile.label)
            heroIcon?.setImageDrawable(icon(tile))
        }
        val front = heroBackdrop ?: return
        // Hide the under-layer instead of clearing it: a drawable size change would relayout the whole stage.
        if (!animate || previous == null || !Motion.animated) { content(); front.animate().cancel(); front.alpha = 1f; front.setImageBitmap(art(tile)); heroUnder?.setImageDrawable(front.drawable); heroUnder?.visibility = View.INVISIBLE; heroArt?.setLayerType(View.LAYER_TYPE_HARDWARE, null); return }
        heroArt?.setLayerType(View.LAYER_TYPE_NONE, null)
        heroUnder?.setImageDrawable(front.drawable); heroUnder?.visibility = View.VISIBLE
        front.animate().cancel(); front.alpha = 0f; front.setImageBitmap(art(tile))
        front.animate().alpha(1f).setStartDelay(0).setDuration(Motion.duration(Motion.EMPHASIZED)).setInterpolator(Motion.standard).withEndAction { heroUnder?.visibility = View.INVISIBLE; heroArt?.setLayerType(View.LAYER_TYPE_HARDWARE, null) }.start()
        val shift = dp(10f).toFloat()
        val parts = listOfNotNull(heroName, heroIcon)
        Motion.swap(parts, shift, content)
    }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!grid && topShelf.visible && dialog == null) return topShelf.dispatch(event) { super.dispatchKeyEvent(event) }
        val code = event.keyCode
        if (code == KeyEvent.KEYCODE_MENU) {
            if (event.action == KeyEvent.ACTION_UP && current().app?.packageName == "org.jellyfin.androidtv") contextMenu()
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastMenu > 3000) menuCount = 0
                lastMenu = now; menuCount++
                if (menuCount >= 5) { menuCount = 0; developer() }
            }
            return true
        }
        if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                pressing = true; held = false; handler.postDelayed(hold, 550)
            } else if (event.action == KeyEvent.ACTION_DOWN && event.isLongPress && !held) {
                held = true; handler.removeCallbacks(hold); contextMenu()
            } else if (event.action == KeyEvent.ACTION_UP) {
                handler.removeCallbacks(hold); pressing = false
                if (!held) activate(current())
                held = false
            }
            return true
        }
        if (code == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP && grid) home()
            return true
        }
        val dx = when (code) { KeyEvent.KEYCODE_DPAD_LEFT -> -1; KeyEvent.KEYCODE_DPAD_RIGHT -> 1; else -> 0 }
        val dy = when (code) { KeyEvent.KEYCODE_DPAD_UP -> -1; KeyEvent.KEYCODE_DPAD_DOWN -> 1; else -> 0 }
        if (dx != 0 || dy != 0) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (grid) {
                    val count = gridApps().size
                    if (tabFocus) { if (dy == 1 && count > 0) tabFocus = false else if (dx != 0) tabColumn = (tabColumn + dx).coerceIn(0, sectionIds.size + if (avatarShown()) 1 else 0) }
                    else if (dy == -1 && gridIndex < 6) { tabFocus = true; tabColumn = sectionIds.indexOf(section) }
                    else gridIndex = cursor.gridMove(gridIndex, dx, dy, count)
                } else cursor.move(dx, dy, layout.lengths(tiles(0).size, tiles(1).size, apps.size))
                updateFocus()
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }
    private fun home() {
        handler.removeCallbacks(hold); pressing = false; held = false
        dialog?.dismiss(); dialog = null
        val from = section
        section = "home"; tabFocus = false; cursor.row = 1; cursor.column = 0
        buildHome(if (from == "home") 0 else -1)
    }
    private fun activate(tile: Tile) {
        when (tile.id) {
            "apps" -> open("apps", false)
            "tab_home" -> if (grid) home()
            "tab_media" -> open("media", true)
            "tab_extras" -> open("extras", true)
            "tab_apps" -> open("apps", true)
            "settings" -> if (!catalog.settings(options())) toast(R.string.launchFailed)
            FavoritesEditor.TILE -> if (!FavoritesEditor.open(this, options())) toast(R.string.launchFailed)
            "quick" -> quickMenu()
            "profile" -> profileTap()
            else -> if (tile.app != null && !catalog.launch(tile.app, options())) toast(R.string.launchFailed)
        }
    }
    private fun open(name: String, tabs: Boolean) {
        val direction = if (!tabs || section == "home") RISE else (sectionIds.indexOf(name) - sectionIds.indexOf(section)).sign
        section = name; gridIndex = 0; tabFocus = tabs || gridApps().isEmpty(); tabColumn = sectionIds.indexOf(name)
        buildHome(direction)
    }
    private fun options(): Bundle? {
        val card = cards[if (grid && tabFocus) 0 to tabColumn else if (grid) 3 to gridIndex else cursor.row to cursor.column]
        launched = true
        return when {
            Motion.level == Motion.Level.OFF -> null
            Motion.level == Motion.Level.REDUCED || card == null -> ActivityOptions.makeCustomAnimation(this, dev.streamybox.design.R.anim.sb_fade_enter, dev.streamybox.design.R.anim.sb_fade_exit).toBundle()
            else -> ActivityOptions.makeScaleUpAnimation(card, 0, 0, card.width, card.height).toBundle()
        }
    }
    private fun toast(message: Int) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun panel(title: String, options: List<Pair<String, () -> Unit>>, info: String? = null) {
        if (dialog?.isShowing == true) return
        dialog = design.panel(title, options, info ?: "").apply {
            setOnKeyListener { _, code, event ->
                if (code in listOf(KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER) && event.action == KeyEvent.ACTION_UP && held) { held = false; pressing = false; true } else false
            }
            setOnDismissListener { dialog = null; pressing = false; handler.removeCallbacks(hold); immersive() }
        }
    }
    private fun quickMenu() {
        val intent = Intent("dev.streamybox.action.QUICK_MENU").setPackage("dev.streamybox.settings").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (runCatching { startActivity(intent) }.isFailure) toast(R.string.launchFailed)
    }
    private fun savePins() { scenes.clear(); val snapshot = pins.toList(); worker.execute { database.savePins(snapshot) }; buildHome() }
    private fun contextMenu(target: AppEntry? = null) {
        val tile = target?.let { Tile(it.packageName, it.label, it) } ?: current()
        if (tile.id == "settings") { developer(); return }
        val app = tile.app ?: return
        val pinned = app.packageName in pins
        val options = mutableListOf<Pair<String, () -> Unit>>()
        if (app.packageName == "org.jellyfin.androidtv") options += getString(R.string.topshelf_connect) to { dev.streamybox.launcher.topshelf.TopShelfHome.connect(this) }
        options += getString(if (pinned) R.string.unpin else R.string.pin) to {
            if (pinned) pins.remove(app.packageName) else pins.add(app.packageName)
            cursor.column = cursor.column.coerceAtMost(tiles(cursor.row).lastIndex.coerceAtLeast(0)); savePins()
        }
        if (pinned) {
            for ((delta, label) in listOf(-1 to R.string.moveLeft, 1 to R.string.moveRight)) options += getString(label) to {
                val index = pins.indexOf(app.packageName)
                val next = index + delta
                if (next in pins.indices) { Collections.swap(pins, index, next); cursor.row = 1; cursor.column = next; savePins() }
            }
        }
        options += getString(R.string.favoritesEdit) to { if (!FavoritesEditor.open(this)) toast(R.string.launchFailed) }
        options += getString(R.string.appInfo) to { if (!catalog.info(app)) toast(R.string.launchFailed) }
        if (!catalog.protected(app)) options += getString(R.string.uninstall) to {
            panel(getString(R.string.uninstallQuestion), listOf(
                getString(R.string.cancel) to {}, getString(R.string.uninstall) to { if (!catalog.uninstall(app)) toast(R.string.launchFailed) }
            ), app.label)
        }
        panel(app.label, options, if (catalog.protected(app)) getString(R.string.protectedApp) else null)
    }
    private fun developer() {
        worker.execute {
            val device = DeviceStatus.read(this)
            handler.post {
                if (isDestroyed) return@post
                val details = "${DeviceStatus.description()}\n\n${getString(R.string.usbAdb)}: ${getString(if (device.usb) R.string.enabled else R.string.disabled)}\n" +
                    "${getString(R.string.adbNetwork)}: ${getString(if (device.tcp == "5555") R.string.enabled else R.string.disabled)}\n" +
                    if (device.ip.isEmpty()) "${getString(R.string.noAddress)}\nadb connect <ip>:5555" else "adb connect ${device.ip}:5555"
                panel(getString(R.string.developer), catalog.applications(true).filter { catalog.hidden(it.packageName) }.map { app ->
                    app.label to { if (!catalog.launchDeveloper(app)) toast(R.string.launchFailed) }
                }, details)
            }
        }
    }
}

// Hidden until a content provider supplies actual playback data.
class PlaybackPlaceholder(context: Context) : LinearLayout(context) {
    init {
        visibility = GONE
        contentDescription = "${context.getString(R.string.continueWatching)} / ${context.getString(R.string.nowPlaying)}"
    }
}

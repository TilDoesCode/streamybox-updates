# Streamybox Launcher — corresponding source

* Package: `dev.streamybox.launcher.debug`, Streamybox 1.6.1 (10033)
* Commit: `19ddb98a521680b771c2eb082973b9fb7447905a` (also in `SOURCE_COMMIT`)
* Licence: GPL-3.0, see `LICENSE`. Contains code derived from Arc Launcher and FLauncher (GPL-3.0, see launcher/README.md). The Inter font in design/src/main/assets/fonts is licensed under the SIL Open Font License 1.1 (Inter-OFL.txt).

Every file is unchanged from that commit, except `launcher/settings.gradle.kts`, which lists only the
modules this app is built from.

## Build

Requirements: JDK 17 or newer, Android SDK with platform 36 and build-tools 36.0.0 (`ANDROID_HOME`).

1. Create your own PKCS12 signing key and a properties file:
   `storeFile=/path/key.p12`, `storePassword=…`, `keyAlias=streamybox` (optional `keyPassword=…`).
2. Put the SHA-256 fingerprint of your certificate into `device/rock4d/store/streamybox-repo.json`
   (`fingerprint`); the build refuses any other certificate.
3. `cd launcher && STREAMYBOX_SIGNING_PROPERTIES=/path/key.properties ./gradlew :app:assembleRelease`

Output: `launcher/app/build/outputs/apk/release/app-release.apk`.

## Install a modified version

APKs signed with another key cannot update the shipped app. Change `applicationId` in
`launcher/app/build.gradle.kts` and install your build then pick it as Home. Streamybox boxes are userdebug builds with `adb root`, so the system copy (`/product/app/StreamyboxLauncher`) can also be replaced.

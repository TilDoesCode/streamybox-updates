# Player packaging: identity, licence, external-player contract

Packaging metadata for `dev.streamybox.player` (app source: `player/`, built in `feat/dv-player`, architecture
`docs/57`, integration `docs/58`). The app owns its TV artwork; this folder owns the licence, the third-party
notice and the checks that keep both sides consistent.

## Launcher identity (verified in `player/`, 2026-10-28)

| Item | Value |
| --- | --- |
| Label | `@string/app_name` = „Streamybox Player“ (DE identical, `values-de/strings.xml`) |
| Banner | `@drawable/sb_player_banner`, vector 320×180 dp (leanback card) |
| Icon | `@mipmap/sb_player_icon`, adaptive icon (background/foreground/monochrome) |
| Launcher activity | `MAIN` + `LEANBACK_LAUNCHER` (the launcher lists the app without code changes) |

`scripts/check-player-integration.sh` verifies these from the manifest and resources (banner size, icon, label,
German string coverage) and from the APK (`application-label-de`, `application-icon`, `banner`). If the artwork
moves or is renamed, the checker is the place to update; do not duplicate drawables here — a second
`sb_player_banner` in an added `res` directory would fight the app's own resource merge.

The Store/Software Update entry is not local UI: it appears when the component is published in the signed
update repository (`device/rock4d/store/publish-policy.json`).

## Embedded renderer contract (Streamarr)

Since 1.5.5 the player also exports `dev.streamybox.player/.render.RenderService` (action
`dev.streamybox.player.RENDER`, AIDL `IRenderService`/`IRenderCallback`, `apiVersion() == 1`). A client binds
it, hands over its `SurfaceView` `Surface` and keeps its own overlay; the player renders mpv with the same DV/HDR
pipeline as `PlayerActivity` and reports JSON events. Clients detect it with
`hasSystemFeature("dev.streamybox.dolby_vision")` + `queryIntentServices` + `apiVersion() >= 1`. Full contract:
`player/README.md` ("Embedded renderer"), tests and box re-test: `docs/59-player-embedded-render.md`.

## External-player contract (Jellyfin handoff)

Jellyfin Android TV lists every app answering `ACTION_VIEW("http://jellyfin.local/query.mp4", video/*)` in its
"Externen Player verwenden" picker, stores the chosen component and starts `ACTION_VIEW` with the direct-play
URL plus `title` (String) and `position` (Int, ms). The player implements that filter, `video/*` for
`content`/`file`/`http`/`https`, and the explicit handoff action:

| Sender | Intent | Extras |
| --- | --- | --- |
| Jellyfin Android TV | `android.intent.action.VIEW`, data = stream URL, type `video/*` | `title`, `position` (Int ms) |
| Streamybox / other apps | `dev.streamybox.player.PLAY` | `url`, `headers` (String[] „Name: value“), `startPositionMs` (Long), `title` |

Activity exported, returns `RESULT_OK` when playback ends normally so Jellyfin advances its queue. Jellyfin's
fallback parser reports no position, so the player owns resume state for external playback.

**Default-route caveat:** Streamybox Settings installs preferred activities for `video/*` on
`dev.streamybox.settings/.MinimalIntentActivity` (forwarder to Kodi/VLC/Just Player/Jellyfin). A bare
`am start -a VIEW -t video/*` therefore does **not** reach the player. Jellyfin still does, because it sets the
component explicitly; for shell tests use `-p dev.streamybox.player` (`scripts/test-player-intent.sh` does).

## Licence

GPL-3.0. The native core is **GPL-3.0-or-later** (FFmpeg `--enable-gpl --enable-version3` linked into mpv
GPL-2.0-or-later). `LICENSE` is the canonical text used by `scripts/lib/source-archive.py` and
`scripts/lib/os-source.py`; the checker compares it with `player/LICENSE` so the two copies cannot drift.

`native-sources.json` is the machine-readable GPL gate manifest from B's build (`feat/dv-mpv`):
11 git pins (mpv `ad5877e`, libplacebo `275f7de` + 4 submodules, FFmpeg `16efe69`, mpv-android `3cc4665`,
libass, dav1d, FreeType), 8 sha256-pinned release tarballs, 3 patches with sha256, NDK r27.1 / API 23 /
16 KB pages and the FFmpeg configure line. `native/` holds the exact build script and patch files this
packaging ships (copies from `tools/dv-mpv/`; the checker fails on drift). `NOTICE.md` lists every component
and its licence.

`scripts/prepare-player-native-sources.sh [--check]` fetches or verifies all pins under `$SB_WORK`
(git checkouts, libplacebo submodules, tarballs with sha256). `scripts/lib/os-source.py` refuses an OS release
unless every pin, patch and tarball matches, and then embeds them in the corresponding-source archive.

#!/usr/bin/env bash
# Reproducible arm64-v8a libmpv/libplacebo build for the ROCK 4D (RK3576).
# Produces $SB_WORK/dv-mpv/out/libmpv-arm64-hdr-dv-spdif.{so,aar} (player jniLibs) plus the mpv-android APK.
#
# Prerequisites (host):
#   brew install bash coreutils gnu-sed wget
#   python3 -m venv "$SB_WORK/buildenv"
#   "$SB_WORK/buildenv/bin/pip" install meson ninja glad2 jinja2 markupsafe
#   Android SDK platform 36 + build-tools 36.0.0 and NDK 27.1.12297006
#
# Usage: tools/dv-mpv/build.sh [--clean]
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
SB_WORK="${SB_WORK:-/Volumes/DevSSD/Development/streamybox-work}"
ANDROID_HOME="${ANDROID_HOME:-/Volumes/DevSSD/SDKs/Android/sdk}"
# shellcheck source=/dev/null
source "$ROOT/scripts/env.sh" 2>/dev/null || true

MPV_COMMIT=ad5877edabdb05c0c62aad444722938d37666e2d
PLACEBO_COMMIT=275f7dea27924cdd34ab2e6c20e448b6bc4fab65
FFMPEG_COMMIT=16efe6927d850d23766aee15820abedcb1219121
ANDROID_COMMIT=3cc4665ed1a38fcaa10b7f400219f21d022d06e9
NDK_VERSION=27.1.12297006

BUILD="$SB_WORK/dv-mpv/build"
SRC="$SB_WORK/dv-mpv/src"
OUT="$SB_WORK/dv-mpv/out"
LOG="$SB_WORK/dv-mpv/logs"
VENV="$SB_WORK/buildenv/bin"
BASH5="$(command -v /opt/homebrew/bin/bash || command -v bash)"

mkdir -p "$BUILD" "$SRC" "$OUT" "$LOG"

# --- sources -----------------------------------------------------------------
fetch() { # name url commit dest
    local name=$1 url=$2 commit=$3 dest=$4
    if [ ! -d "$dest/.git" ]; then
        git clone "$url" "$dest"
    fi
    git -C "$dest" fetch --all --tags --quiet || true
    git -C "$dest" checkout --quiet "$commit"
}

fetch mpv https://github.com/mpv-player/mpv "$MPV_COMMIT" "$SRC/mpv"
fetch libplacebo https://github.com/haasn/libplacebo "$PLACEBO_COMMIT" "$SRC/libplacebo"
git -C "$SRC/libplacebo" submodule update --init --recursive \
    3rdparty/fast_float 3rdparty/glad 3rdparty/jinja 3rdparty/markupsafe
fetch ffmpeg https://github.com/FFmpeg/FFmpeg "$FFMPEG_COMMIT" "$SRC/ffmpeg"

if [ ! -d "$SRC/mpv-android/.git" ]; then
    git clone https://github.com/mpv-android/mpv-android "$SRC/mpv-android"
fi
git -C "$SRC/mpv-android" checkout --quiet "$ANDROID_COMMIT"

# --- patches -----------------------------------------------------------------
(cd "$SRC/mpv" && git checkout -- . && git apply "$HERE/patches/mpv/0001-android-hdr10-egl-surface.patch" \
    && git apply "$HERE/patches/mpv/0002-ao-audiotrack-iec61937-hbr.patch")
(cd "$SRC/ffmpeg" && git checkout -- . && git apply "$HERE/patches/ffmpeg/0001-libavcodec-mediacodec-attach-DOVI-RPU-metadata.patch")
(cd "$SRC/mpv-android" && git checkout -- . && git apply "$HERE/patches/mpv-android/0001-local-build-tweaks.patch" \
    && git apply "$HERE/patches/mpv-android/0002-ffmpeg-enable-spdif-muxer.patch")

# --- build tree --------------------------------------------------------------
# mpv-android resolves ../../scripts relative to the real path, so the sources
# must be real directories inside buildscripts/deps (symlinks break the build).
D="$SRC/mpv-android/buildscripts/deps"
mkdir -p "$D"
for s in mpv libplacebo ffmpeg; do
    rm -rf "$D/$s"
    cp -a "$SRC/$s" "$D/$s"
done

# SDK + NDK discovery (buildall.sh expects these paths).
mkdir -p "$SRC/mpv-android/buildscripts/sdk"
ln -sfn "$ANDROID_HOME" "$SRC/mpv-android/buildscripts/sdk/android-sdk-$( [ "$(uname)" = Darwin ] && echo mac || echo linux )"
ln -sfn "$ANDROID_HOME/ndk/$NDK_VERSION" "$SRC/mpv-android/buildscripts/sdk/android-ndk-$NDK_VERSION"

# Other dependencies: version-pinned downloads into buildscripts/deps.
(cd "$SRC/mpv-android/buildscripts" && WGET=wget ./include/download-deps.sh)

if [ "${1:-}" = "--clean" ]; then
    rm -rf "$SRC/mpv-android/buildscripts/prefix"
    rm -rf "$D"/mpv/_build_arm64 "$D"/libplacebo/_build_arm64
fi

# --- build -------------------------------------------------------------------
export PATH="$VENV:/opt/homebrew/opt/coreutils/libexec/gnubin:$PATH"
cd "$SRC/mpv-android/buildscripts"
"$BASH5" ./buildall.sh --arch arm64 mpv-android 2>&1 | tee "$LOG/build-$(date +%Y%m%d-%H%M).log"

# --- collect -----------------------------------------------------------------
NAME=libmpv-arm64-hdr-dv-spdif
cp "$SRC/mpv-android/buildscripts/prefix/arm64/lib/libmpv.so" "$OUT/$NAME.so"
cp "$SRC/mpv-android/app/build/outputs/apk/default/debug/app-default-arm64-v8a-debug.apk" \
   "$OUT/mpv-android-arm64-hdr-dv-spdif.apk"
# Player input (player/scripts/sync-mpv-libs.sh): libmpv + FFmpeg shared libraries and headers as an AAR.
AAR="$(mktemp -d)"
mkdir -p "$AAR/jni/arm64-v8a" "$AAR/include"
printf '<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="is.xyz.mpv.lib"/>\n' > "$AAR/AndroidManifest.xml"
cp "$SRC/mpv-android/buildscripts/prefix/arm64/lib/"lib{mpv,avcodec,avdevice,avfilter,avformat,avutil,swresample,swscale}.so "$AAR/jni/arm64-v8a/"
cp -R "$SRC/mpv-android/buildscripts/prefix/arm64/include/mpv" "$AAR/include/"
(cd "$AAR" && rm -f "$OUT/$NAME.aar" && zip -qr -X "$OUT/$NAME.aar" AndroidManifest.xml jni include)
rm -rf "$AAR"
sha256sum "$OUT/$NAME.so" "$OUT/$NAME.aar" "$OUT/mpv-android-arm64-hdr-dv-spdif.apk" | tee "$OUT/SHA256SUMS-spdif"
echo "done: $OUT"

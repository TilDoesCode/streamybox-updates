# Third-party notices — Streamybox Player (`dev.streamybox.player`)

The player is GPL-3.0. Its native core (`libmpv.so` plus FFmpeg's shared libraries) is **GPL-3.0-or-later**:
FFmpeg is built with `--enable-gpl --enable-version3` and linked into mpv (`GPL-2.0-or-later`). All other
libraries are compatible with that result.

Exact pins, patches, URLs and hashes: `native-sources.json` (machine-readable) and
`native/` (the build script and patch files this packaging ships). Build and test provenance:
`docs/58-libmpv-hdr10-android.md` in `feat/dv-mpv`, `docs/57`/`docs/58` here.

## Linked native components

| Component | Pin | Licence |
| --- | --- | --- |
| mpv (libmpv) | `ad5877edabdb05c0c62aad444722938d37666e2d` (0.41.0-dev) + HDR10 surface patch + AudioTrack IEC 61937 (passthrough) patch | GPL-2.0-or-later |
| libplacebo | `275f7dea27924cdd34ab2e6c20e448b6bc4fab65` (v7.387.0) + 4 submodules | LGPL-2.1-or-later |
| FFmpeg | `16efe6927d850d23766aee15820abedcb1219121` + MediaCodec DV RPU patch, `spdif` muxer enabled (mpv-android patch 0002) | GPL-3.0-or-later |
| mpv-android (build scripts) | `3cc4665ed1a38fcaa10b7f400219f21d022d06e9` + local build tweaks | MIT |
| libass | `f61db567e6593df3470e91594bcd4ad2d0473aff` | ISC |
| dav1d | `c6f51c881d80b43830b7c1fff2ba0d48599e8073` | BSD-2-Clause |
| FreeType | `37515cf56ba3349656049edbed89ffc6f6466f2d` (VER-2-15-0) | FTL OR GPL-2.0-or-later |
| fontconfig 2.18.3 | release tarball, sha256 pinned | MIT |
| fribidi 1.0.17 | release tarball, sha256 pinned | LGPL-2.1-or-later |
| harfbuzz 14.6.0 | release tarball, sha256 pinned | MIT |
| libunibreak 8.0 | release tarball, sha256 pinned | Zlib |
| libxml2 2.15.4 | release tarball, sha256 pinned | MIT |
| Lua 5.2.4 | release tarball, sha256 pinned | MIT |
| curl 8.23.0 | release tarball, sha256 pinned | curl |
| Mbed TLS 3.6.7 | release tarball, sha256 pinned | Apache-2.0 OR GPL-2.0-or-later |
| Kotlin stdlib, AndroidX/Compose, Media3 (if used) | Gradle dependencies | Apache-2.0 |
| Inter (bundled via `design/`) | SIL OFL-1.1 | OFL-1.1 |

Native binaries stay build artifacts in `$SB_WORK`; they are never committed. A published APK or OS image that
contains them is only allowed together with their complete corresponding source:
`scripts/lib/source-archive.py` (update repo) and `scripts/lib/os-source.py` (OS image). The OS gate fails closed
unless every source checkout is at its pin, every release tarball matches its sha256 and every patch matches its
recorded hash.

## Reproduction

```sh
scripts/prepare-player-native-sources.sh          # clone/checkout pins, init submodules, fetch tarballs
scripts/prepare-player-native-sources.sh --check  # verify only
device/rock4d/player/native/build.sh              # upstream copy: tools/dv-mpv/build.sh
```

`native-sources.json` records the NDK (r27.1.12297006), min API 23, 16 KB page size and the FFmpeg
configure line. The four release tarballs and the seven git checkouts cover every library linked into
`libmpv.so`; the build script is shipped unchanged.

## Copyright

Project code: Streamybox contributors. Third-party copyright notices are those of the upstream projects listed
above; the corresponding-source archives contain their `COPYING`/`LICENSE` files unchanged.

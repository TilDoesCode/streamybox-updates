package dev.streamybox.remote.contract

import android.content.Context
import android.content.Intent

object RemoteWake {
    const val PERMISSION = "dev.streamybox.permission.WAKE"
    const val ACTION = "dev.streamybox.remote.WAKE"
    fun wake(context: Context) {
        context.sendBroadcast(Intent(ACTION).addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES).setClassName("dev.streamybox.remote", "dev.streamybox.remote.WakeReceiver"))
    }
}

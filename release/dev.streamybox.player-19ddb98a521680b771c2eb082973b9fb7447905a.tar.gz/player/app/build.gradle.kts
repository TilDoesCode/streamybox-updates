plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.streamybox.player"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.streamybox.player"
        minSdk = 34
        targetSdk = 34
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        ndk { abiFilters += listOf("arm64-v8a") }
        buildConfigField("String", "PLAY_INTENT_ACTION", "\"dev.streamybox.player.PLAY\"")
    }

    buildFeatures {
        buildConfig = true
        aidl = true
    }

    buildTypes {
        debug { isMinifyEnabled = false }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // The JNI bridge is only built once the prebuilt libmpv tree is present.
    // scripts/sync-mpv-libs.sh copies it into src/main/jniLibs/arm64-v8a.
    val mpvLib = file("src/main/jniLibs/arm64-v8a/libmpv.so")
    if (mpvLib.exists()) {
        ndkVersion = "27.1.12297006"
        externalNativeBuild { cmake { path = file("src/main/jni/CMakeLists.txt"); version = "3.22.1" } }
    }

    packaging {
        jniLibs { useLegacyPackaging = false }
        resources { excludes += "/META-INF/*.kotlin_module" }
    }
}

dependencies {
    implementation(project(":design"))
    testImplementation("junit:junit:4.13.2")
}

apply(from = rootProject.file("../gradle/streamybox-release.gradle"))

package dev.streamybox.player

import org.junit.Assert.assertEquals
import org.junit.Test

class HdrSupportTest {
    @Test fun automaticPicksHdr10OnlyOnThePatchedBox() {
        assertEquals(HdrKind.HDR10, HdrSupport.outputKind(true, HdrMode.AUTO))
        assertEquals(HdrKind.SDR, HdrSupport.outputKind(false, HdrMode.AUTO))
    }

    @Test fun explicitModesWin() {
        assertEquals(HdrKind.HDR10, HdrSupport.outputKind(false, HdrMode.HDR10))
        assertEquals(HdrKind.SDR, HdrSupport.outputKind(true, HdrMode.SDR))
    }
}

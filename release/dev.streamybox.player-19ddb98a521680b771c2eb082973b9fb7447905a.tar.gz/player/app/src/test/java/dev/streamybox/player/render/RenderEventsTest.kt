package dev.streamybox.player.render

import dev.streamybox.player.EngineInfo
import dev.streamybox.player.HdrKind
import dev.streamybox.player.Phase
import dev.streamybox.player.PlaybackStatus
import dev.streamybox.player.Track
import dev.streamybox.player.TrackKind
import dev.streamybox.player.VideoStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RenderEventsTest {
    private var now = 0L
    private val mapper = RenderEventMapper { now }

    private fun type(json: String) = (Json.parse(json) as Map<*, *>)["type"]
    private fun obj(json: String) = Json.parse(json) as Map<*, *>
    private fun playing(pos: Long, paused: Boolean = false, buffering: Boolean = false) =
        PlaybackStatus(Phase.PLAYING, paused = paused, buffering = buffering, positionMs = pos, durationMs = 60_000)

    @Test fun simpleEventsMatchTheContract() {
        assertEquals("""{"type":"state","state":"playing"}""", RenderEvents.state("playing"))
        assertEquals("""{"type":"time","positionMs":1000,"durationMs":5000,"bufferedMs":3000}""", RenderEvents.time(1000, 5000, 3000))
        assertEquals("""{"type":"time","positionMs":1000,"durationMs":5000}""", RenderEvents.time(1000, 5000, null))
        assertEquals("""{"type":"buffering","buffering":true}""", RenderEvents.buffering(true))
        assertEquals("""{"type":"firstFrame"}""", RenderEvents.firstFrame())
        assertEquals("""{"type":"ended"}""", RenderEvents.ended())
        assertEquals("""{"type":"error","reason":"load_failed","fatal":true,"status":404}""", RenderEvents.error("load_failed", true, 404))
        assertEquals("""{"type":"stats","decoder":"hevc (mediacodec)","droppedFrames":2,"totalFrames":100,"hwdec":"mediacodec"}""",
            RenderEvents.stats("hevc (mediacodec)", 2, 100, "mediacodec"))
    }

    @Test fun tracksEventHasAudioSubtitlesAndVideo() {
        val tracks = listOf(
            Track("1", TrackKind.AUDIO, "English · eac3", true, language = "eng", codec = "eac3", channels = 6),
            Track("2", TrackKind.AUDIO, "Deutsch · ac3", false, language = "ger", codec = "ac3", channels = 2),
            Track("1", TrackKind.SUBTITLE, "Forced", false, forced = true, language = "ger", codec = "subrip"),
            Track("3", TrackKind.SUBTITLE, "Deutsch · extern", true, external = true, language = "de"),
            Track("x", TrackKind.SUBTITLE, "broken id", false),
        )
        val video = VideoStatus(width = 3840, height = 2160, fps = 23.976023, codec = "hevc", hwdec = "mediacodec",
            primaries = "bt.2020", gamma = "pq", dvProfile = 8, dvLevel = 6)
        val json = obj(RenderEvents.tracks(tracks, video, HdrKind.HDR10))
        val audio = json["audio"] as List<*>
        assertEquals(mapOf("id" to 1L, "label" to "English · eac3", "language" to "eng", "codec" to "eac3", "channels" to 6L, "selected" to true), audio[0])
        val subs = json["subtitles"] as List<*>
        assertEquals(2, subs.size)
        assertEquals(mapOf("id" to 1L, "label" to "Forced", "language" to "ger", "codec" to "subrip", "selected" to false, "forced" to true, "external" to false), subs[0])
        assertEquals(true, (subs[1] as Map<*, *>)["external"])
        assertEquals(
            mapOf("width" to 3840L, "height" to 2160L, "codec" to "hevc", "frameRate" to 23.976, "range" to "pq",
                "dolbyVisionProfile" to 8L, "dolbyVision" to true, "output" to "hdr10", "hwdec" to "mediacodec"),
            json["video"],
        )
    }

    @Test fun rangeAndOutput() {
        assertEquals("hlg", RenderEvents.range(VideoStatus(gamma = "hlg", dvProfile = 8)))
        assertEquals("pq", RenderEvents.range(VideoStatus(dvProfile = 5)))
        assertEquals("pq", RenderEvents.range(VideoStatus(dvDetected = true)))
        assertEquals("sdr", RenderEvents.range(VideoStatus(primaries = "bt.709", gamma = "bt.1886")))
        val sdr = RenderEvents.video(VideoStatus(width = 1920, height = 1080, codec = "h264"), HdrKind.SDR)!!
        assertEquals("sdr", sdr["output"])
        assertEquals("no", sdr["hwdec"])
        assertNull(sdr["dolbyVisionProfile"])
        assertNull(RenderEvents.video(VideoStatus(), HdrKind.SDR))
    }

    @Test fun stateMapping() {
        assertEquals("loading", RenderEvents.stateOf(PlaybackStatus(Phase.LOADING)))
        assertEquals("paused", RenderEvents.stateOf(playing(0, paused = true, buffering = true)))
        assertEquals("buffering", RenderEvents.stateOf(playing(0, buffering = true)))
        assertEquals("playing", RenderEvents.stateOf(playing(0)))
        assertEquals("ended", RenderEvents.stateOf(PlaybackStatus(Phase.ENDED)))
        assertEquals("error", RenderEvents.stateOf(PlaybackStatus(Phase.ERROR)))
        assertEquals("idle", RenderEvents.stateOf(PlaybackStatus(Phase.IDLE)))
    }

    @Test fun statesAreDeduplicated() {
        assertEquals("""{"type":"state","state":"loading"}""", mapper.forceState("loading"))
        assertNull(mapper.forceState("loading"))
        assertEquals(listOf("buffering"), mapper.status(PlaybackStatus(Phase.LOADING), null).map(::type))
        assertTrue(mapper.status(PlaybackStatus(Phase.LOADING), null).isEmpty())
        val events = mapper.status(playing(0), null)
        assertEquals(listOf("state", "time"), events.map(::type))
        now += 100
        assertTrue(mapper.status(playing(0), null).isEmpty())
    }

    @Test fun timeIsAtMostFourPerSecond() {
        mapper.status(playing(0), null)
        var times = 0
        for (step in 1..100) {
            now += 10
            times += mapper.status(playing(step * 10L), 5.0).count { type(it) == "time" }
        }
        assertEquals(3, times)
        now += 300
        val time = obj(mapper.status(playing(1_300), 5.0).single())
        assertEquals(6_300L, time["bufferedMs"])
        assertEquals(60_000L, time["durationMs"])
    }

    @Test fun throttleSpansLoads() {
        mapper.status(playing(0), null)
        mapper.reset()
        now += 100
        assertEquals(listOf("state", "buffering"), mapper.status(playing(100), null).map(::type))
        now += 200
        assertEquals("time", type(mapper.status(playing(300), null).single()))
    }

    @Test fun bufferedNeverExceedsDuration() {
        val time = obj(mapper.status(playing(59_000), 30.0).first { type(it) == "time" })
        assertEquals(60_000L, time["bufferedMs"])
    }

    @Test fun bufferingAndPauseTransitions() {
        mapper.status(playing(0), null)
        now += 300
        val stall = mapper.status(playing(10, buffering = true), null).map(::type)
        assertEquals(listOf("state", "buffering", "time"), stall)
        now += 300
        val resumed = mapper.status(playing(20), null).map { obj(it) }
        assertEquals("playing", resumed[0]["state"])
        assertEquals(false, resumed[1]["buffering"])
        now += 300
        assertEquals("paused", obj(mapper.status(playing(20, paused = true), null).first())["state"])
    }

    @Test fun engineErrorOrIdlePhasesNeverBecomeStateEvents() {
        mapper.markIdle()
        assertEquals(emptyList<String>(), mapper.status(PlaybackStatus(Phase.IDLE), null).map(::type))
        assertEquals("loading", obj(mapper.forceState("loading")!!)["state"])
        assertTrue(mapper.status(PlaybackStatus(Phase.ERROR, error = "[cplayer] warning"), null).none { obj(it)["state"] == "error" })
        assertEquals("playing", obj(mapper.status(playing(0), null).first())["state"])
        assertEquals(listOf("error", "state"), mapper.error("load_failed", true, null, null).map(::type))
    }

    @Test fun sessionStartSendsNoIdle() {
        mapper.markIdle()
        assertNull(mapper.forceState("idle"))
    }

    @Test fun dolbyVisionFromDecodedFramesWithoutConfigRecord() {
        val base = VideoStatus(width = 3840, height = 2160, codec = "hevc", gamma = "pq", primaries = "bt.2020")
        assertNull(RenderEvents.video(base, HdrKind.HDR10)!!["dolbyVision"])
        val decoded = RenderEvents.video(base.copy(dvDetected = true), HdrKind.HDR10)!!
        assertEquals(true, decoded["dolbyVision"])
        assertNull(decoded["dolbyVisionProfile"])
        val configured = RenderEvents.video(base.copy(dvProfile = 8, dvLevel = 6), HdrKind.HDR10)!!
        assertEquals(8, configured["dolbyVisionProfile"])
        assertEquals(true, configured["dolbyVision"])
        // A late DV detection changes the JSON, so the mapper sends a second tracks event.
        assertTrue(mapper.tracks(emptyList(), base, HdrKind.HDR10) != null)
        assertTrue(mapper.tracks(emptyList(), base.copy(dvDetected = true), HdrKind.HDR10)!!.contains("\"dolbyVision\":true"))
    }

    @Test fun audioTracksCarryTheirOutput() {
        val tracks = listOf(
            Track("1", TrackKind.AUDIO, "TrueHD", true, codec = "truehd", channels = 8, output = "passthrough:truehd"),
            Track("2", TrackKind.AUDIO, "AAC", false, codec = "aac", channels = 6, output = "pcm:2"),
            Track("3", TrackKind.SUBTITLE, "Sub", false, output = "pcm:2"),
        )
        val json = obj(RenderEvents.tracks(tracks, VideoStatus(), HdrKind.SDR))
        val audio = json["audio"] as List<*>
        assertEquals("passthrough:truehd", (audio[0] as Map<*, *>)["output"])
        assertEquals("pcm:2", (audio[1] as Map<*, *>)["output"])
        assertNull(((json["subtitles"] as List<*>)[0] as Map<*, *>)["output"])
    }

    @Test fun endedOnce() {
        val first = mapper.status(PlaybackStatus(Phase.ENDED), null).map(::type)
        assertEquals(listOf("state", "ended"), first)
        assertTrue(mapper.status(PlaybackStatus(Phase.ENDED), null).isEmpty())
    }

    @Test fun fatalErrorLatchesUntilReset() {
        mapper.forceState("loading")
        val events = mapper.error("load_failed", true, 403, "HTTP error 403 Forbidden").map(::obj)
        assertEquals(mapOf("type" to "error", "reason" to "load_failed", "fatal" to true, "status" to 403L, "message" to "HTTP error 403 Forbidden"), events[0])
        assertEquals("error", events[1]["state"])
        assertTrue(mapper.error("load_failed", true, null, null).isEmpty())
        assertTrue(mapper.status(PlaybackStatus(Phase.LOADING), null).isEmpty())
        assertEquals(1, mapper.error("subtitle", false, null, null).size)
        mapper.reset()
        assertEquals("loading", obj(mapper.forceState("loading")!!)["state"])
    }

    @Test fun tracksOnlyWhenChanged() {
        val video = VideoStatus(width = 1920, height = 1080, codec = "h264")
        assertNull(mapper.tracks(emptyList(), VideoStatus(), HdrKind.SDR))
        val first = mapper.tracks(emptyList(), video, HdrKind.SDR)
        assertEquals("tracks", type(first!!))
        assertNull(mapper.tracks(emptyList(), video, HdrKind.SDR))
        val audio = listOf(Track("1", TrackKind.AUDIO, "A", true))
        assertEquals("tracks", type(mapper.tracks(audio, video, HdrKind.SDR)!!))
    }

    @Test fun statsEveryTwoSecondsOrOnHwdecChange() {
        val info = EngineInfo(hwdec = "mediacodec", videoCodec = "hevc", droppedFrames = 3)
        val video = VideoStatus(codec = "hevc")
        val first = obj(mapper.stats(info, video, 48, playing = true)!!)
        assertEquals("hevc (mediacodec)", first["decoder"])
        assertEquals(3L, first["droppedFrames"])
        assertEquals(48L, first["totalFrames"])
        now += 1_000
        assertNull(mapper.stats(info, video, 72, playing = true))
        val copy = obj(mapper.stats(info.copy(hwdec = "mediacodec-copy"), video, 80, playing = true)!!)
        assertEquals("mediacodec-copy", copy["hwdec"])
        now += 2_000
        assertNull(mapper.stats(info.copy(hwdec = "mediacodec-copy"), video, 90, playing = false))
        assertEquals("hevc (software)", obj(mapper.stats(info.copy(hwdec = "no"), video, null, playing = false)!!)["decoder"])
        assertNull(mapper.stats(EngineInfo(), VideoStatus(), null, playing = true))
    }
}

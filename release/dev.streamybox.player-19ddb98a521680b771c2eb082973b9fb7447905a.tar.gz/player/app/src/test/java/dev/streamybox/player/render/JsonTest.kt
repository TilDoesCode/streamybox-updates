package dev.streamybox.player.render

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

class JsonTest {
    @Test fun parsesContractOptions() {
        val value = Json.parse("""{"title":"Film ä","startPositionMs":125000,"muted":false,"headers":["A: b"],"x":[1.5,null,true]}""") as Map<*, *>
        assertEquals("Film ä", value["title"])
        assertEquals(125000L, value["startPositionMs"])
        assertEquals(false, value["muted"])
        assertEquals(listOf("A: b"), value["headers"])
        assertEquals(listOf(1.5, null, true), value["x"])
    }

    @Test fun writesEscapedStringsAndSkipsNulls() {
        val json = Json.write(mapOf("type" to "error", "reason" to "a\"b\\c\n\u0001", "status" to null, "fatal" to true))
        assertEquals("""{"type":"error","reason":"a\"b\\c\n\u0001","fatal":true}""", json)
    }

    @Test fun writesNumbers() {
        assertEquals("""[1,23.976,0,null]""", Json.write(listOf(1L, 23.976, 0.0, Double.NaN)))
    }

    @Test fun roundTrip() {
        val source = mapOf("a" to listOf(1L, "x", mapOf("b" to false)), "c" to "ü\t")
        assertEquals(source, Json.parse(Json.write(source)))
    }

    @Test fun rejectsBrokenInput() {
        for (bad in listOf("{", "{\"a\":}", "[1,]", "tru", "{\"a\":1} x", "\"unterminated", "{a:1}")) {
            assertThrows(bad, Json.SyntaxError::class.java) { Json.parse(bad) }
        }
    }

    @Test fun limitsNestingAndSize() {
        assertThrows(Json.SyntaxError::class.java) { Json.parse("[".repeat(40) + "]".repeat(40)) }
        assertThrows(Json.SyntaxError::class.java) { Json.parse("\"" + "x".repeat(Json.MAX_INPUT) + "\"") }
        assertNull(Json.parse(" null "))
    }
}

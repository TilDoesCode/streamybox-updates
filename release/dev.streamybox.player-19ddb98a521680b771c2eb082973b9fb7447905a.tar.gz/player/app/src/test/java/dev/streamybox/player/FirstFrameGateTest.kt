package dev.streamybox.player

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FirstFrameGateTest {
    @Test fun waitsForTheStartSeek() {
        val gate = FirstFrameGate()
        gate.arm()
        assertFalse(gate.playbackRestart(true)) // frame at 0 behind the loading screen
        gate.seekIssued()
        assertFalse(gate.finalized(true))
        assertTrue(gate.playbackRestart(true))
        assertFalse(gate.playbackRestart(true))
    }

    @Test fun withoutStartPositionTheLoadRestartCounts() {
        val gate = FirstFrameGate()
        gate.arm()
        assertFalse(gate.playbackRestart(true))
        assertTrue(gate.finalized(true))
    }

    @Test fun needsASurface() {
        val gate = FirstFrameGate()
        gate.arm()
        gate.playbackRestart(false)
        assertFalse(gate.finalized(false))
        assertTrue(gate.surfaceAttached())
        assertFalse(gate.surfaceAttached())
    }

    @Test fun hwdecReloadStartsOver() {
        val gate = FirstFrameGate()
        gate.arm()
        gate.playbackRestart(true)
        gate.reload()
        assertFalse(gate.surfaceAttached())
        gate.seekIssued()
        assertFalse(gate.finalized(true))
        assertTrue(gate.playbackRestart(true))
    }

    @Test fun firesOncePerLoadAndIgnoresUnarmedEvents() {
        val gate = FirstFrameGate()
        assertFalse(gate.playbackRestart(true))
        assertFalse(gate.finalized(true))
        gate.arm()
        gate.playbackRestart(true)
        assertTrue(gate.finalized(true))
        gate.reload()
        gate.playbackRestart(true)
        assertFalse(gate.finalized(true))
        gate.arm()
        gate.playbackRestart(true)
        assertTrue(gate.finalized(true))
    }
}

package dev.streamybox.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class EndFilePolicyTest {
    @Test fun eofIsEndedNotFailure() {
        assertEquals(EndAction.ENDED, EndFilePolicy.action(EndFilePolicy.EOF))
        assertNotEquals(EndAction.ERROR, EndFilePolicy.action(EndFilePolicy.EOF))
    }

    @Test fun errorIsFailure() {
        assertEquals(EndAction.ERROR, EndFilePolicy.action(EndFilePolicy.ERROR))
        assertEquals(EndAction.ERROR, EndFilePolicy.action(99))
    }

    @Test fun intentionalStopQuitRedirectAreIgnored() {
        assertEquals(EndAction.IGNORE, EndFilePolicy.action(EndFilePolicy.STOP))
        assertEquals(EndAction.IGNORE, EndFilePolicy.action(EndFilePolicy.QUIT))
        assertEquals(EndAction.IGNORE, EndFilePolicy.action(EndFilePolicy.REDIRECT))
    }

    @Test fun legacyEofFallback() {
        assertEquals(EndAction.ENDED, EndFilePolicy.actionForLegacyEof(true))
        assertEquals(EndAction.ERROR, EndFilePolicy.actionForLegacyEof(false))
    }
}

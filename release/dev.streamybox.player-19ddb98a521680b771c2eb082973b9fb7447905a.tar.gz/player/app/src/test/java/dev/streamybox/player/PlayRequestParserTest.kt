package dev.streamybox.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayRequestParserTest {
    private fun ok(values: IntentValues): PlayRequest {
        val result = PlayRequestParser.parse(values)
        assertTrue("expected Ok, got $result", result is ParseResult.Ok)
        return (result as ParseResult.Ok).request
    }

    private fun error(values: IntentValues): RequestError {
        val result = PlayRequestParser.parse(values)
        assertTrue("expected Invalid, got $result", result is ParseResult.Invalid)
        return (result as ParseResult.Invalid).error
    }

    @Test fun playIntentCarriesUrlHeadersTitleAndPosition() {
        val request = ok(
            IntentValues(
                action = PlayRequestParser.ACTION_PLAY,
                extraUrl = "https://jellyfin.example/Videos/42/stream?static=true",
                extraTitle = "Blade Runner 2049",
                headerExtras = listOf("Authorization: MediaBrowser Token=\"abc\"\nX-Emby-Token: abc"),
                startPositionMs = 125_000L,
                type = "video/x-matroska",
            )
        )
        assertEquals("https://jellyfin.example/Videos/42/stream?static=true", request.url)
        assertEquals("Blade Runner 2049", request.title)
        assertEquals(125_000L, request.startPositionMs)
        assertEquals(2, request.headers.size)
        assertEquals("Authorization", request.headers[0].name)
        assertEquals("MediaBrowser Token=\"abc\"", request.headers[0].value)
        assertEquals("X-Emby-Token", request.headers[1].name)
    }

    @Test fun viewIntentNeedsVideoMimeType() {
        assertEquals(
            RequestError.NOT_VIDEO,
            error(IntentValues(action = PlayRequestParser.ACTION_VIEW, type = "audio/mpeg", data = "https://example.test/song.mp3")),
        )
        val request = ok(
            IntentValues(action = PlayRequestParser.ACTION_VIEW, type = "video/mp4", data = "https://example.test/movie.mp4")
        )
        assertEquals("movie", request.title)
    }

    @Test fun viewIntentAcceptsAllSupportedSchemes() {
        listOf(
            "https://example.test/a.mkv",
            "http://example.test/a.mkv",
            "file:///sdcard/Movies/a.mkv",
            "content://com.example.provider/video/1",
        ).forEach { url ->
            assertEquals(url, ok(IntentValues(action = PlayRequestParser.ACTION_VIEW, data = url)).url)
        }
    }

    @Test fun rejectsDangerousOrMalformedSchemes() {
        assertEquals(RequestError.UNSUPPORTED_SCHEME, error(IntentValues(action = PlayRequestParser.ACTION_VIEW, data = "javascript:alert(1)")))
        assertEquals(RequestError.UNSUPPORTED_SCHEME, error(IntentValues(action = PlayRequestParser.ACTION_VIEW, data = "data:video/mp4;base64,AAAA")))
        assertEquals(RequestError.MALFORMED_URL, error(IntentValues(action = PlayRequestParser.ACTION_VIEW, data = "https://exa mple.test/a.mkv")))
        assertEquals(RequestError.MISSING_HOST, error(IntentValues(action = PlayRequestParser.ACTION_VIEW, data = "http:///a.mkv")))
        assertEquals(RequestError.MALFORMED_URL, error(IntentValues(action = PlayRequestParser.ACTION_VIEW, data = "file://")))
    }

    @Test fun emptyUrlIsRejected() {
        assertEquals(RequestError.EMPTY_URL, error(IntentValues(action = PlayRequestParser.ACTION_PLAY, extraUrl = "   ")))
        assertEquals(RequestError.BAD_ACTION, error(IntentValues(action = "android.intent.action.SEND", data = "https://example.test/a.mkv")))
    }

    @Test fun headerValidationRejectsInjectionAndMalformedNames() {
        val badName = PlayRequestParser.parseHeaders(listOf("Bad Header: value"))
        assertTrue(badName is PlayRequestParser.HeaderResult.Invalid)
        val noColon = PlayRequestParser.parseHeaders(listOf("NoColon"))
        assertTrue(noColon is PlayRequestParser.HeaderResult.Invalid)
        val nul = PlayRequestParser.parseHeaders(listOf("X-Test: a\u0000b"))
        assertTrue(nul is PlayRequestParser.HeaderResult.Invalid)
        val tooMany = PlayRequestParser.parseHeaders((0 until 40).map { "X-$it: value" })
        assertTrue(tooMany is PlayRequestParser.HeaderResult.Invalid)
    }

    @Test fun headerBlockIsCrLfTerminated() {
        val request = ok(
            IntentValues(
                action = PlayRequestParser.ACTION_PLAY,
                extraUrl = "https://example.test/a.mkv",
                headerExtras = listOf("A: one", "B: two"),
            )
        )
        assertEquals("A: one\r\nB: two\r\n", request.headerFields())
        assertEquals(mapOf("A" to "one", "B" to "two"), request.headerMap())
    }

    @Test fun startPositionIsClamped() {
        assertEquals(0L, ok(IntentValues(action = PlayRequestParser.ACTION_PLAY, extraUrl = "https://example.test/a.mkv", startPositionMs = -10L)).startPositionMs)
        assertEquals(PlayRequestParser.MAX_POSITION_MS, ok(IntentValues(action = PlayRequestParser.ACTION_PLAY, extraUrl = "https://example.test/a.mkv", startPositionMs = Long.MAX_VALUE)).startPositionMs)
        assertEquals(90_000L, ok(IntentValues(action = PlayRequestParser.ACTION_PLAY, extraUrl = "https://example.test/a.mkv", startPositionText = "90000")).startPositionMs)
        assertEquals(RequestError.BAD_POSITION, error(IntentValues(action = PlayRequestParser.ACTION_PLAY, extraUrl = "https://example.test/a.mkv", startPositionText = "soon")))
    }

    @Test fun titleIsDecodedAndCleaned() {
        assertEquals("My Movie", PlayRequestParser.deriveTitle("https://example.test/media/My%20Movie.mkv?token=1"))
        assertEquals("example.test", PlayRequestParser.deriveTitle("https://example.test/"))
        assertEquals("video", PlayRequestParser.deriveTitle("content://provider/video"))
        assertEquals("custom", ok(IntentValues(action = PlayRequestParser.ACTION_PLAY, extraUrl = "https://example.test/a.mkv", extraTitle = "  custom  ")).title)
    }

    @Test fun contentTitlesNeedLookupOnlyForProviderIds() {
        assertTrue(PlayRequestParser.needsContentTitle("content://media/external/video/media/1000000049", "1000000049"))
        assertTrue(PlayRequestParser.needsContentTitle("content://media/external/video/media/1000000049", ""))
        assertTrue(!PlayRequestParser.needsContentTitle("https://example.test/My%20Movie.mkv", "My Movie"))
        assertTrue(!PlayRequestParser.needsContentTitle("content://provider/movie", "My Movie"))
    }

    @Test fun videoMimeTypes() {
        assertTrue(PlayRequestParser.isVideoMime("video/mp4"))
        assertTrue(PlayRequestParser.isVideoMime("application/dash+xml"))
        assertTrue(!PlayRequestParser.isVideoMime("audio/mp4"))
    }
}

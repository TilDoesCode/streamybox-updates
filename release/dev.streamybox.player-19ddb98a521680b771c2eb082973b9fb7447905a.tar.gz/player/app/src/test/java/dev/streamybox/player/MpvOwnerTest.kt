package dev.streamybox.player

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Test

class MpvOwnerTest {
    private val log = mutableListOf<String>()
    private val activity = MpvOwner.Holder { log += "activity yields" }
    private val service = MpvOwner.Holder { log += "service yields" }

    @After fun clear() {
        MpvOwner.release(activity)
        MpvOwner.release(service)
    }

    @Test fun newestHolderWinsAndThePreviousYieldsFirst() {
        MpvOwner.acquire(activity)
        MpvOwner.acquire(service)
        assertEquals(listOf("activity yields"), log)
        assertSame(service, MpvOwner.holder)
        MpvOwner.acquire(activity)
        assertEquals(listOf("activity yields", "service yields"), log)
    }

    @Test fun reacquireAndReleaseAreNoOps() {
        MpvOwner.acquire(service)
        MpvOwner.acquire(service)
        MpvOwner.release(activity)
        assertSame(service, MpvOwner.holder)
        assertEquals(emptyList<String>(), log)
        MpvOwner.release(service)
        assertNull(MpvOwner.holder)
    }

    @Test fun yieldingHolderSeesNoOwner() {
        val seen = mutableListOf<MpvOwner.Holder?>()
        val probe = MpvOwner.Holder { seen += MpvOwner.holder }
        MpvOwner.acquire(probe)
        MpvOwner.acquire(activity)
        assertEquals(listOf<MpvOwner.Holder?>(null), seen)
    }
}

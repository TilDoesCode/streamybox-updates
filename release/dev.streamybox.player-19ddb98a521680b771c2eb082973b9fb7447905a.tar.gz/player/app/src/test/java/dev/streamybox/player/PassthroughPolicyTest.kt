package dev.streamybox.player

import dev.streamybox.player.PassthroughPolicy.ENCODING_AC3
import dev.streamybox.player.PassthroughPolicy.ENCODING_DOLBY_TRUEHD
import dev.streamybox.player.PassthroughPolicy.ENCODING_DTS
import dev.streamybox.player.PassthroughPolicy.ENCODING_DTS_HD
import dev.streamybox.player.PassthroughPolicy.ENCODING_E_AC3
import dev.streamybox.player.PassthroughPolicy.ENCODING_IEC61937
import dev.streamybox.player.PassthroughPolicy.ENCODING_PCM
import dev.streamybox.player.PassthroughPolicy.IEC_192K
import dev.streamybox.player.PassthroughPolicy.IEC_48K
import dev.streamybox.player.PassthroughPolicy.IEC_HBR
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** The box: SADs from /sys/class/drm/card0-HDMI-A-1/edid ("LG TV SSCR2"), CEA data block collection, read 2026-10-28. */
internal object BoxEdid {
    const val SADS = "095707,570603,150750,670403"
    val formats = PassthroughPolicy.parseSadSetting(SADS)!!
}

class PassthroughPolicyTest {
    // ROCK 4D hdmi_bitstream mix port (AC3, E-AC3, DTS, DTS-HD, IEC61937; IEC 2/6/8 ch up to 192 kHz) + the LG EDID.
    private val box = PassthroughSink(
        spdifMuxer = true,
        digitalRoute = true,
        iec = setOf(IEC_48K, IEC_192K, IEC_HBR),
        directEncodings = setOf(ENCODING_AC3, ENCODING_E_AC3, ENCODING_DTS, ENCODING_DTS_HD, ENCODING_IEC61937),
        reported = BoxEdid.formats,
    )

    @Test fun boxGetsAc3Eac3AndTrueHdButNoDts() {
        assertEquals(listOf("ac3", "eac3", "truehd"), PassthroughPolicy.codecs(box))
    }

    @Test fun noSpdifMuxerMeansPcm() {
        assertEquals(emptyList<String>(), PassthroughPolicy.codecs(box.copy(spdifMuxer = false)))
    }

    @Test fun speakerOrEmulatorRouteMeansPcm() {
        assertEquals(emptyList<String>(), PassthroughPolicy.codecs(box.copy(digitalRoute = false)))
        assertEquals(emptyList<String>(), PassthroughPolicy.codecs(box.copy(iec = emptySet(), directEncodings = emptySet())))
    }

    @Test fun eac3NeedsFourTimesTheIecRateAndTrueHdTheEightChannelFrames() {
        assertEquals(listOf("ac3"), PassthroughPolicy.codecs(box.copy(iec = setOf(IEC_48K))))
        assertEquals(listOf("ac3", "eac3"), PassthroughPolicy.codecs(box.copy(iec = setOf(IEC_48K, IEC_192K))))
    }

    @Test fun unknownEdidAllowsOnlyTheDolbyDigitalFamily() {
        assertEquals(listOf("ac3", "eac3"), PassthroughPolicy.codecs(box.copy(reported = null)))
    }

    @Test fun reportedEdidGatesEveryCodec() {
        assertEquals(emptyList<String>(), PassthroughPolicy.codecs(box.copy(reported = PassthroughPolicy.parseSadSetting(""))))
        assertEquals(listOf("ac3"), PassthroughPolicy.codecs(box.copy(reported = PassthroughPolicy.parseSadSetting("095707,150750"))))
    }

    @Test fun dtsAndDtsHdOnlyWhenTheSinkReportsThem() {
        val dtsCore = PassthroughPolicy.parseSadSetting(BoxEdid.SADS + ",3d0750")
        assertEquals(listOf("ac3", "eac3", "truehd", "dts"), PassthroughPolicy.codecs(box.copy(reported = dtsCore)))
        val dtsHd = PassthroughPolicy.parseSadSetting(BoxEdid.SADS + ",3d0750,5f7e01")
        assertEquals(listOf("ac3", "eac3", "truehd", "dts", "dts-hd"), PassthroughPolicy.codecs(box.copy(reported = dtsHd)))
        val hdOnly = PassthroughPolicy.parseSadSetting("5f7e01")
        assertEquals(listOf("dts-hd", "dts"), PassthroughPolicy.codecs(box.copy(reported = hdOnly)))
    }

    @Test fun trueHdNeedsTheHalToTakeIt() {
        val noTrueHdPath = box.copy(directEncodings = setOf(ENCODING_AC3, ENCODING_E_AC3))
        assertEquals(listOf("ac3", "eac3"), PassthroughPolicy.codecs(noTrueHdPath))
        val nativeTrueHd = noTrueHdPath.copy(directEncodings = noTrueHdPath.directEncodings + ENCODING_DOLBY_TRUEHD)
        assertEquals(listOf("ac3", "eac3", "truehd"), PassthroughPolicy.codecs(nativeTrueHd))
    }

    @Test fun mutedPcmSettingAndStallMeanPcm() {
        val probed = { listOf("ac3", "eac3", "truehd") }
        assertEquals(probed(), PassthroughPolicy.effective(AudioPassthrough.AUTO, broken = false, muted = false, probe = probed))
        assertEquals(emptyList<String>(), PassthroughPolicy.effective(AudioPassthrough.AUTO, broken = false, muted = true, probe = probed))
        assertEquals(emptyList<String>(), PassthroughPolicy.effective(AudioPassthrough.AUTO, broken = true, muted = false, probe = probed))
        assertEquals(emptyList<String>(), PassthroughPolicy.effective(AudioPassthrough.PCM, broken = false, muted = false, probe = probed))
    }

    @Test fun outputPerTrack() {
        val spdif = PassthroughPolicy.codecs(box)
        assertEquals("passthrough:truehd", PassthroughPolicy.output("truehd", 8, spdif, 2))
        assertEquals("passthrough:eac3", PassthroughPolicy.output("EAC3", 6, spdif, 2))
        assertEquals("pcm:2", PassthroughPolicy.output("dts", 6, spdif, 2))
        assertEquals("pcm:6", PassthroughPolicy.output("aac", 6, emptyList(), null))
        assertEquals("pcm:2", PassthroughPolicy.output("ac3", 6, emptyList(), 2))
        assertEquals("passthrough:dts", PassthroughPolicy.output("dts", 6, listOf("dts-hd", "dts"), 8))
    }

    @Test fun mirroredConstantsMatchAndroid() {
        assertEquals(android.media.AudioFormat.ENCODING_PCM_16BIT, ENCODING_PCM)
        assertEquals(android.media.AudioFormat.ENCODING_AC3, ENCODING_AC3)
        assertEquals(android.media.AudioFormat.ENCODING_E_AC3, ENCODING_E_AC3)
        assertEquals(android.media.AudioFormat.ENCODING_DTS, ENCODING_DTS)
        assertEquals(android.media.AudioFormat.ENCODING_DTS_HD, ENCODING_DTS_HD)
        assertEquals(android.media.AudioFormat.ENCODING_IEC61937, ENCODING_IEC61937)
        assertEquals(android.media.AudioFormat.ENCODING_DOLBY_TRUEHD, ENCODING_DOLBY_TRUEHD)
        assertEquals(android.media.AudioFormat.ENCODING_E_AC3_JOC, PassthroughPolicy.ENCODING_E_AC3_JOC)
        assertEquals(android.media.AudioFormat.ENCODING_DOLBY_MAT, PassthroughPolicy.ENCODING_DOLBY_MAT)
    }
}

class SadDecodeTest {
    @Test fun lgTvDescriptorsFromTheBoxEdid() {
        // LPCM 2ch, E-AC-3 8ch, AC-3 6ch, MLP/TrueHD 8ch.
        assertEquals(mapOf(ENCODING_PCM to 2, ENCODING_E_AC3 to 8, ENCODING_AC3 to 6, ENCODING_DOLBY_TRUEHD to 8), BoxEdid.formats.channels)
        assertEquals(2, BoxEdid.formats.lpcmChannels)
    }

    @Test fun formatCodesAndChannels() {
        assertEquals(ENCODING_DTS, PassthroughPolicy.encodingOfSad(byteArrayOf(0x3d, 0x07, 0x50)))
        assertEquals(6, PassthroughPolicy.channelsOfSad(byteArrayOf(0x3d, 0x07, 0x50)))
        assertEquals(ENCODING_DTS_HD, PassthroughPolicy.encodingOfSad(byteArrayOf(0x5f, 0x7e, 0x01)))
        assertNull(PassthroughPolicy.encodingOfSad(byteArrayOf(0x7f, 0x07, 0x00)))
        assertNull(PassthroughPolicy.encodingOfSad(byteArrayOf()))
    }

    @Test fun settingFormat() {
        assertEquals(emptyMap<Int, Int>(), PassthroughPolicy.parseSadSetting("")!!.channels)
        assertNull(PassthroughPolicy.parseSadSetting(null))
        assertNull(PassthroughPolicy.parseSadSetting("0957"))
        assertNull(PassthroughPolicy.parseSadSetting("095707,zz0000"))
        assertEquals(BoxEdid.formats, PassthroughPolicy.parseSadSetting(" 095707, 570603 ,150750,670403 "))
    }
}

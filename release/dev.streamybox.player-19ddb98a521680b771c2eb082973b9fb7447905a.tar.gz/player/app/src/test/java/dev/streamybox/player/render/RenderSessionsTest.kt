package dev.streamybox.player.render

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RenderSessionsTest {
    @Test fun attachReturnsPositiveIncreasingIds() {
        val sessions = RenderSessions()
        val first = sessions.attach(10_100)
        assertEquals(1, first.id)
        assertNull(first.replaced)
        val second = sessions.attach(10_100)
        assertEquals(2, second.id)
        assertEquals(1, second.replaced)
    }

    @Test fun staleOrForeignCallsAreIgnored() {
        val sessions = RenderSessions()
        val old = sessions.attach(10_100).id
        val current = sessions.attach(10_200).id
        assertFalse(sessions.isCurrent(old, 10_100))
        assertTrue(sessions.isCurrent(current, 10_200))
        assertFalse(sessions.isCurrent(current, 10_100))
        assertFalse(sessions.isCurrent(0, 10_200))
        assertFalse(sessions.isCurrent(-1, 10_200))
    }

    @Test fun detachOnlyTheCurrentSession() {
        val sessions = RenderSessions()
        val old = sessions.attach(1).id
        val current = sessions.attach(1).id
        assertFalse(sessions.detach(old))
        assertEquals(current, sessions.current)
        assertTrue(sessions.detach(current))
        assertNull(sessions.current)
        assertFalse(sessions.isCurrent(current))
        assertFalse(sessions.detach(current))
    }

    @Test fun idsAreNotReusedAfterDetach() {
        val sessions = RenderSessions()
        val first = sessions.attach(1).id
        sessions.detach(first)
        assertTrue(sessions.attach(1).id > first)
    }
}

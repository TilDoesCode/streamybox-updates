package dev.streamybox.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MpvOptionsTest {
    @Test fun defaultOptionsTargetGpuNextOnAndroid() {
        val options = MpvOptions.build(PlayerConfig())
        assertEquals("gpu-next", options["vo"])
        assertEquals("android", options["gpu-context"])
        assertEquals("opengl", options["gpu-api"])
        assertEquals("mediacodec", options["hwdec"])
        assertEquals("yes", options["target-colorspace-hint"])
        assertEquals("no", options["android-hdr"])
        assertEquals("rgb10_a2", options["egl-output-format"])
        assertEquals("yes", options["cache"])
        assertEquals("no", options["save-position-on-quit"])
        assertEquals("fuzzy", options["sub-auto"])
        assertFalse("PCM unless the sink accepts a bitstream", options.containsKey("audio-spdif"))
    }

    @Test fun hdrModesMapToExplicitTargets() {
        val hdr10 = MpvOptions.build(PlayerConfig(hdr = HdrMode.HDR10))
        assertEquals("yes", hdr10["target-colorspace-hint"])
        assertEquals("yes", hdr10["android-hdr"])

        val sdr = MpvOptions.build(PlayerConfig(hdr = HdrMode.SDR))
        assertEquals("yes", sdr["target-colorspace-hint"])
        assertEquals("no", sdr["android-hdr"])
    }

    @Test fun automaticUsesHdrOnlyWhenTheBoxAdvertisesIt() {
        val patched = MpvOptions.build(PlayerConfig(hdr = HdrMode.AUTO), hdr10Rgb = true)
        assertEquals("yes", patched["android-hdr"])
        val stock = MpvOptions.build(PlayerConfig(hdr = HdrMode.AUTO), hdr10Rgb = false)
        assertEquals("no", stock["android-hdr"])
    }

    @Test fun copyBackSelection() {
        val copy = MpvOptions.build(PlayerConfig(hwdecode = HwDecode.COPY))
        assertEquals("mediacodec-copy", copy["hwdec"])
    }

    @Test fun playbackToggles() {
        val software = MpvOptions.build(PlayerConfig(hwdecode = HwDecode.SOFTWARE, cache = NetworkCache.OFF, passthrough = AudioPassthrough.PCM))
        assertEquals("no", software["hwdec"])
        assertEquals("no", software["cache"])
        assertFalse(software.containsKey("audio-spdif"))
    }

    @Test fun languagesAndSubtitles() {
        val options = MpvOptions.build(
            PlayerConfig(audioLanguage = "de", subtitleLanguage = "en", subtitleMode = SubtitleMode.OFF)
        )
        assertEquals("de", options["alang"])
        assertEquals("en", options["slang"])
        assertEquals("no", options["sub-auto"])
        assertEquals("no", options["sid"])

        val forced = MpvOptions.build(PlayerConfig(subtitleMode = SubtitleMode.FORCED))
        assertEquals("fuzzy", forced["sub-auto"])
        assertFalse(forced.containsKey("sub-forced-only"))
    }

    @Test fun without10BitEglTheDefault8BitSurfaceIsUsed() {
        val options = MpvOptions.build(PlayerConfig(hdr = HdrMode.HDR10), hdr10Rgb = true, rgb10a2 = false)
        assertFalse(options.containsKey("egl-output-format"))
        assertEquals("no", options["android-hdr"])
        assertEquals("rgb10_a2", MpvOptions.build(PlayerConfig(), hdr10Rgb = true)["egl-output-format"])
        assertEquals("yes", MpvOptions.build(PlayerConfig(), hdr10Rgb = true)["android-hdr"])
    }

    @Test fun passthroughUsesOnlyTheProbedCodecs() {
        assertEquals("ac3,eac3", MpvOptions.build(PlayerConfig(), spdifCodecs = listOf("ac3", "eac3"))["audio-spdif"])
        assertFalse(MpvOptions.build(PlayerConfig(passthrough = AudioPassthrough.PCM), spdifCodecs = listOf("ac3")).containsKey("audio-spdif"))
    }
}

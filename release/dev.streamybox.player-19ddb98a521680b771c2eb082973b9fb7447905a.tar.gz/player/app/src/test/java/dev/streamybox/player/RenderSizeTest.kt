package dev.streamybox.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RenderSizeTest {
    @Test fun uhdVideoGetsAFullUhdBufferOnAUhdDisplay() {
        assertEquals(3840 to 2160, RenderSize.choose(3840, 2160, 3840, 2160))
        assertEquals(3840 to 2160, RenderSize.choose(4096, 2160, 3840, 2160))
    }

    @Test fun hdVideoStaysAtHdOnAUhdDisplay() {
        assertEquals(1920 to 1080, RenderSize.choose(1920, 1080, 3840, 2160))
        assertEquals(1920 to 1080, RenderSize.choose(1280, 720, 3840, 2160))
    }

    @Test fun neverExceedsTheDisplay() {
        assertEquals(1920 to 1080, RenderSize.choose(3840, 2160, 1920, 1080))
        assertEquals(1280 to 720, RenderSize.choose(1920, 1080, 1280, 720))
    }

    @Test fun unknownDimensionsAreIgnored() {
        assertNull(RenderSize.choose(0, 0, 3840, 2160))
        assertNull(RenderSize.choose(3840, 2160, 0, 0))
    }
}

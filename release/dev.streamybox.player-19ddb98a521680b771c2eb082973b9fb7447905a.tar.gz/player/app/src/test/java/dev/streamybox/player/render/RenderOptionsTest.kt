package dev.streamybox.player.render

import dev.streamybox.player.ExternalSubtitle
import dev.streamybox.player.Header
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RenderOptionsTest {
    private val privateDirs = listOf("/data/user/0/dev.streamybox.player", "/data/data/dev.streamybox.player")

    private fun ok(url: String, json: String?, muted: Boolean = false) =
        (RenderOptions.request(url, json, privateDirs, muted) as LoadResult.Ok).request

    private fun invalid(url: String?, json: String?) = RenderOptions.request(url, json, privateDirs, false) as LoadResult.Invalid

    @Test fun fullContractOptions() {
        val request = ok(
            "https://srv.example/Videos/1/stream?static=true",
            """{"title":"Blade Runner","startPositionMs":125000,"headers":["X-Emby-Token: abc"],"muted":true,
               "audioTrack":2,"subtitleTrack":-1,
               "externalSubtitles":[{"url":"https://srv.example/sub.srt","title":"Deutsch","language":"de"}]}""",
        )
        assertEquals("Blade Runner", request.title)
        assertEquals(125_000L, request.startPositionMs)
        assertEquals(listOf(Header("X-Emby-Token", "abc")), request.headers)
        assertTrue(request.muted)
        assertEquals(2, request.audioTrack)
        assertEquals(-1, request.subtitleTrack)
        assertEquals(listOf(ExternalSubtitle("https://srv.example/sub.srt", "Deutsch", "de")), request.externalSubtitles)
    }

    @Test fun emptyOptionsUseDefaults() {
        for (json in listOf(null, "", "{}")) {
            val request = ok("http://h/movie.mkv", json, muted = true)
            assertEquals("movie", request.title)
            assertEquals(0L, request.startPositionMs)
            assertTrue(request.muted)
            assertNull(request.audioTrack)
            assertNull(request.subtitleTrack)
        }
    }

    @Test fun acceptsOnlyMediaSchemes() {
        assertEquals("http://h/a.mp4", ok("http://h/a.mp4", null).url)
        assertEquals("content://media/external/video/1", ok("content://media/external/video/1", null).url)
        assertEquals("file:///sdcard/Movies/a.mkv", ok("file:///sdcard/Movies/a.mkv", null).url)
        for (bad in listOf("javascript:alert(1)", "data:video/mp4;base64,AA", "rtsp://h/x", "ftp://h/x", "", "http:///nohost", "http://h/a b")) {
            assertEquals(bad, "invalid_url", invalid(bad, null).reason)
        }
        assertEquals("invalid_url", invalid(null, null).reason)
    }

    @Test fun refusesThePlayersOwnFiles() {
        assertEquals("private_path", invalid("file:///data/user/0/dev.streamybox.player/shared_prefs/resume.xml", null).detail)
        assertEquals("private_path", invalid("file:///data/data/dev.streamybox.player/../dev.streamybox.player/files/x", null).detail)
        assertEquals("file:///data/data/dev.streamybox.player2/x", ok("file:///data/data/dev.streamybox.player2/x", null).url)
    }

    @Test fun invalidOptionsAreRejected() {
        assertEquals("invalid_options", invalid("http://h/a", "[1]").reason)
        assertEquals("invalid_options", invalid("http://h/a", "{broken").reason)
        assertEquals("invalid_options", invalid("http://h/a", """{"headers":["bad header"]}""").reason)
        assertEquals("invalid_options", invalid("http://h/a", """{"headers":["X: a\r\n: b"]}""").reason)
        assertEquals("invalid_options", invalid("http://h/a", """{"headers":[1]}""").reason)
    }

    @Test fun multiLineHeaderEntriesAreSplitAndValidatedPerLine() {
        val request = ok("http://h/a", """{"headers":"X-A: 1\r\nX-B: 2"}""")
        assertEquals(listOf(Header("X-A", "1"), Header("X-B", "2")), request.headers)
    }

    @Test fun clampsAndFiltersValues() {
        val request = ok(
            "http://h/a",
            """{"startPositionMs":-5,"audioTrack":0,"subtitleTrack":-7,"title":"   ",
               "externalSubtitles":[{"url":"javascript:x"},{"url":"file:///data/data/dev.streamybox.player/files/r"},
                 {"url":"http://h/s.vtt","language":"de; rm","title":"T\u0000"},"nope",{"title":"no url"}]}""",
        )
        assertEquals(0L, request.startPositionMs)
        assertNull(request.audioTrack)
        assertNull(request.subtitleTrack)
        assertEquals("a", request.title)
        assertEquals(listOf(ExternalSubtitle("http://h/s.vtt", "T", null)), request.externalSubtitles)
        assertEquals(RenderOptionsTest.WEEK, ok("http://h/a", """{"startPositionMs":9.9E15}""").startPositionMs)
        assertEquals(1500L, ok("http://h/a", """{"startPositionMs":1500.7}""").startPositionMs)
    }

    @Test fun limitsSubtitleCount() {
        val many = (1..40).joinToString(",") { """{"url":"http://h/$it.srt"}""" }
        assertEquals(RenderOptions.MAX_SUBTITLES, ok("http://h/a", """{"externalSubtitles":[$many]}""").externalSubtitles.size)
        assertFalse(ok("http://h/a", "{}").externalSubtitles.any())
    }

    private companion object { const val WEEK = 7L * 24 * 60 * 60 * 1000 }
}

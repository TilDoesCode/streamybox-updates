package dev.streamybox.player

import org.junit.Assert.assertEquals
import org.junit.Test

class DecodePolicyTest {
    @Test fun zeroCopyForP8AndNonDv() {
        assertEquals("mediacodec", DecodePolicy.hwdec(HwDecode.MEDIACODEC, 8))
        assertEquals("mediacodec", DecodePolicy.hwdec(HwDecode.MEDIACODEC, null))
        assertEquals("mediacodec", DecodePolicy.hwdec(HwDecode.MEDIACODEC, 0))
    }

    @Test fun p5NeverUsesZeroCopy() {
        assertEquals("mediacodec-copy", DecodePolicy.hwdec(HwDecode.MEDIACODEC, 5))
        assertEquals("mediacodec-copy", DecodePolicy.hwdec(HwDecode.COPY, 8))
        assertEquals("no", DecodePolicy.hwdec(HwDecode.SOFTWARE, 5))
    }
}

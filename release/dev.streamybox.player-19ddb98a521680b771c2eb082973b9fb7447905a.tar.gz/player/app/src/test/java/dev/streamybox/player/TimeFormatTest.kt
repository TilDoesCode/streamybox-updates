package dev.streamybox.player

import org.junit.Assert.assertEquals
import org.junit.Test

class TimeFormatTest {
    @Test fun clockBelowAnHour() {
        assertEquals("0:00", TimeFormat.clock(0))
        assertEquals("0:59", TimeFormat.clock(59_999))
        assertEquals("1:00", TimeFormat.clock(60_000))
        assertEquals("59:59", TimeFormat.clock(3_599_000))
    }

    @Test fun clockWithHours() {
        assertEquals("1:00:00", TimeFormat.clock(3_600_000))
        assertEquals("1:01:01", TimeFormat.clock(3_661_000))
        assertEquals("100:00:00", TimeFormat.clock(100L * 3_600_000))
    }

    @Test fun negativeClampsToZero() {
        assertEquals("0:00", TimeFormat.clock(-5))
        assertEquals("0:00:00", TimeFormat.clockLong(-1))
    }

    @Test fun longFormAlwaysHasHours() {
        assertEquals("0:01:05", TimeFormat.clockLong(65_000))
    }

    @Test fun remainingNeverGoesPositive() {
        assertEquals("-1:00", TimeFormat.remaining(30_000, 90_000))
        assertEquals("-0:00", TimeFormat.remaining(120_000, 90_000))
    }
}

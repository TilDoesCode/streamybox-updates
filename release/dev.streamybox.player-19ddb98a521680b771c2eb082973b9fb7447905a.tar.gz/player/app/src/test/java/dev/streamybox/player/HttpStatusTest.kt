package dev.streamybox.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HttpStatusTest {
    @Test fun parsesFfmpegMessages() {
        assertEquals(404, HttpStatus.parse("HTTP error 404 Not Found"))
        assertEquals(403, HttpStatus.parse("http: Server returned 403 Forbidden (access denied)"))
        assertEquals(500, HttpStatus.parse("Server returned 5XX Server Error reply"))
        assertEquals(400, HttpStatus.parse("Server returned 4XX Client Error, but not one of 40{0,1,3,4}"))
        assertNull(HttpStatus.parse("Failed to open http://h/a.mkv."))
        assertNull(HttpStatus.parse("HTTP error 9999"))
    }
}

package dev.streamybox.player

import org.junit.Assert.assertEquals
import org.junit.Test

class HdrDetectTest {
    @Test fun dolbyVisionWinsOverPrimaries() {
        val info = HdrDetect.detect("bt.2020", "pq", 8, 6)
        assertEquals(HdrKind.DV, info.kind)
        assertEquals("P8", info.dvLabel)
        assertEquals(8, info.dvProfile)
        assertEquals(6, info.dvLevel)
    }

    @Test fun hdr10AndHlg() {
        assertEquals(HdrKind.HDR10, HdrDetect.detect("bt.2020", "pq", null, null).kind)
        assertEquals(HdrKind.HLG, HdrDetect.detect("bt.2020", "hlg", null, null).kind)
        assertEquals(HdrKind.SDR, HdrDetect.detect("bt.709", "bt.1886", null, null).kind)
        assertEquals(HdrKind.UNKNOWN, HdrDetect.detect(null, null, null, null).kind)
    }

    @Test fun decoderDolbyVisionFallback() {
        val status = VideoStatus(dvDetected = true)
        assertEquals(HdrKind.DV, status.hdr.kind)
        assertEquals(null, status.hdr.dvLabel)
    }

    @Test fun videoStatusFormats() {
        val status = VideoStatus(width = 3840, height = 2160, fps = 23.976, primaries = "bt.2020", gamma = "pq")
        assertEquals("3840×2160", status.resolution)
        assertEquals("23.976", status.fpsText)
        assertEquals(HdrKind.HDR10, status.hdr.kind)
        assertEquals("60", VideoStatus(fps = 60.0).fpsText)
        assertEquals("29.97", VideoStatus(fps = 29.970001).fpsText)
    }
}

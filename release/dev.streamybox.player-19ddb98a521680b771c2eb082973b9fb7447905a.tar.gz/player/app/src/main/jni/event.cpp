/*
 * Adapted from mpv-android (https://github.com/mpv-android/mpv-android), jni/event.cpp.
 * Copyright (c) 2016 Ilya Zhuravlev, sfan5 <sfan5@live.de>, MIT licensed.
 * Modifications: Streamybox package name, null guards for unavailable properties.
 *
 * This file is part of the Streamybox Player, licensed GPL-3.0-or-later.
 */
#include <jni.h>

#include <mpv/client.h>

#include "globals.h"
#include "jni_utils.h"
#include "log.h"

static void sendPropertyUpdateToJava(JNIEnv *env, mpv_event_property *prop) {
    if (!prop)
        return;
    jstring jprop = env->NewStringUTF(prop->name);
    jstring jvalue = NULL;

    if (!prop->data) {
        env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_eventProperty_S, jprop);
        env->DeleteLocalRef(jprop);
        return;
    }

    switch (prop->format) {
    case MPV_FORMAT_NONE:
        env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_eventProperty_S, jprop);
        break;
    case MPV_FORMAT_FLAG:
        env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_eventProperty_Sb, jprop,
            static_cast<jboolean>(*static_cast<int *>(prop->data) != 0));
        break;
    case MPV_FORMAT_INT64:
        env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_eventProperty_Sl, jprop,
            static_cast<jlong>(*static_cast<int64_t *>(prop->data)));
        break;
    case MPV_FORMAT_DOUBLE:
        env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_eventProperty_Sd, jprop,
            static_cast<jdouble>(*static_cast<double *>(prop->data)));
        break;
    case MPV_FORMAT_STRING: {
        const char *value = *static_cast<const char **>(prop->data);
        if (value) {
            jvalue = env->NewStringUTF(value);
            env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_eventProperty_SS, jprop, jvalue);
        } else {
            env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_eventProperty_S, jprop);
        }
        break;
    }
    default:
        ALOGV("sendPropertyUpdateToJava: unknown property format %d", prop->format);
        break;
    }

    if (jprop)
        env->DeleteLocalRef(jprop);
    if (jvalue)
        env->DeleteLocalRef(jvalue);
}

static void sendEventToJava(JNIEnv *env, int event) {
    env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_event, event);
}

static void sendEndFileToJava(JNIEnv *env, int reason) {
    env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_endFile, reason);
}

static void sendLogMessageToJava(JNIEnv *env, mpv_event_log_message *msg) {
    // Java strings must be valid UTF-8; drop the worst malformed sequences.
    const auto invalid_utf8 = [](unsigned char c) {
        return c == 0xc0 || c == 0xc1 || c >= 0xf5;
    };
    for (int i = 0; msg->text[i]; i++) {
        if (invalid_utf8(static_cast<unsigned char>(msg->text[i])))
            return;
    }

    jstring jprefix = env->NewStringUTF(msg->prefix);
    jstring jtext = env->NewStringUTF(msg->text);

    env->CallStaticVoidMethod(mpv_MPVLib, mpv_MPVLib_logMessage_SiS,
        jprefix, static_cast<jint>(msg->log_level), jtext);

    if (jprefix)
        env->DeleteLocalRef(jprefix);
    if (jtext)
        env->DeleteLocalRef(jtext);
}

void *event_thread(void *arg) {
    JNIEnv *env = NULL;
    acquire_jni_env(g_vm, &env);
    if (!env)
        die("failed to acquire java env");

    while (true) {
        mpv_event *mp_event;
        mpv_event_property *mp_property = NULL;
        mpv_event_log_message *msg = NULL;

        mp_event = mpv_wait_event(g_mpv, -1.0);

        if (g_event_thread_request_exit)
            break;
        if (mp_event->event_id == MPV_EVENT_NONE)
            continue;

        switch (mp_event->event_id) {
        case MPV_EVENT_LOG_MESSAGE:
            msg = static_cast<mpv_event_log_message *>(mp_event->data);
            ALOGV("[%s:%s] %s", msg->prefix, msg->level, msg->text);
            sendLogMessageToJava(env, msg);
            break;
        case MPV_EVENT_PROPERTY_CHANGE:
            mp_property = static_cast<mpv_event_property *>(mp_event->data);
            sendPropertyUpdateToJava(env, mp_property);
            break;
        case MPV_EVENT_END_FILE: {
            auto *end = static_cast<mpv_event_end_file *>(mp_event->data);
            sendEndFileToJava(env, end ? end->reason : MPV_END_FILE_REASON_ERROR);
            break;
        }
        default:
            ALOGV("event: %s", mpv_event_name(mp_event->event_id));
            sendEventToJava(env, mp_event->event_id);
            break;
        }
    }

    g_vm->DetachCurrentThread();
    return NULL;
}

/*
 * Adapted from mpv-android (https://github.com/mpv-android/mpv-android), jni/main.cpp.
 * Copyright (c) 2016 Ilya Zhuravlev, sfan5 <sfan5@live.de>, MIT licensed.
 * Modifications: Streamybox package name, dynamic FFmpeg JNI lookup.
 *
 * This file is part of the Streamybox Player, licensed GPL-3.0-or-later.
 */
#include <jni.h>
#include <dlfcn.h>
#include <locale.h>
#include <pthread.h>
#include <stdlib.h>
#include <atomic>

#include <mpv/client.h>

#include "jni_utils.h"
#include "log.h"
#include "event.h"

#define ARRAYLEN(a) (sizeof(a) / sizeof(a[0]))

extern "C" {
    jni_func(void, create, jobject appctx);
    jni_func(void, init);
    jni_func(void, destroy);
    jni_func(void, command, jobjectArray jarray);
    jni_func(void, commandAsync, jobjectArray jarray);
    jni_func(jboolean, spdifMuxerAvailable);
};

JavaVM *g_vm;
mpv_handle *g_mpv;
std::atomic<bool> g_event_thread_request_exit(false);

static pthread_t event_thread_id;
static jobject global_appctx;

static void prepare_environment(JNIEnv *env, jobject appctx) {
    setlocale(LC_NUMERIC, "C");

    g_vm = NULL;
    env->GetJavaVM(&g_vm);
    if (!g_vm)
        die("failed to get jvm");

    // libavcodec is a dependency of libmpv and may be linked statically or as a
    // shared library depending on the dv-mpv build. Resolve the JNI hooks at
    // runtime so this bridge links against either layout.
    using SetJavaVm = int (*)(void *, void *);
    using SetAndroidAppCtx = int (*)(void *, void *);
    auto set_java_vm = reinterpret_cast<SetJavaVm>(dlsym(RTLD_DEFAULT, "av_jni_set_java_vm"));
    auto set_app_ctx = reinterpret_cast<SetAndroidAppCtx>(dlsym(RTLD_DEFAULT, "av_jni_set_android_app_ctx"));
    if (set_java_vm) {
        set_java_vm(g_vm, NULL);
    } else {
        ALOGE("av_jni_set_java_vm not found; MediaCodec hardware decoding may fail");
    }

    if (global_appctx)
        env->DeleteGlobalRef(global_appctx);
    global_appctx = env->NewGlobalRef(appctx);
    if (global_appctx && set_app_ctx) {
        set_app_ctx(global_appctx, NULL);
    } else if (!set_app_ctx) {
        ALOGE("av_jni_set_android_app_ctx not found");
    }

    init_methods_cache(env);
}

jni_func(void, create, jobject appctx) {
    if (g_mpv)
        die("mpv is already initialized");

    prepare_environment(env, appctx);

    g_mpv = mpv_create();
    if (!g_mpv)
        die("context init failed");

    mpv_request_log_messages(g_mpv, "terminal-default");
    mpv_set_option_string(g_mpv, "msg-level", "all=warn");
}

jni_func(void, init) {
    if (!g_mpv)
        die("mpv is not created");

    if (mpv_initialize(g_mpv) < 0)
        die("mpv init failed");

    g_event_thread_request_exit = false;
    if (pthread_create(&event_thread_id, NULL, event_thread, NULL) != 0)
        die("thread create failed");
    pthread_setname_np(event_thread_id, "sbplayer-mpv");
}

jni_func(void, destroy) {
    if (!g_mpv) {
        ALOGV("mpv destroy called but it is already destroyed");
        return;
    }

    g_event_thread_request_exit = true;
    mpv_wakeup(g_mpv);
    pthread_join(event_thread_id, NULL);

    mpv_terminate_destroy(g_mpv);
    g_mpv = NULL;
}

static void run_command(JNIEnv *env, jobjectArray jarray, bool async) {
    CHECK_MPV_INIT();

    jstring strings[64] = {0};
    const char *arguments[65] = {0};
    jsize len = env->GetArrayLength(jarray);
    if (len >= static_cast<jsize>(ARRAYLEN(arguments)))
        die("too many command arguments");

    for (jsize i = 0; i < len; ++i) {
        strings[i] = static_cast<jstring>(env->GetObjectArrayElement(jarray, i));
        if (!strings[i])
            die("null command argument");
        arguments[i] = env->GetStringUTFChars(strings[i], NULL);
    }

    // Async commands (network sub-add) must not block the calling UI thread.
    int result = async ? mpv_command_async(g_mpv, 0, arguments) : mpv_command(g_mpv, arguments);
    if (result < 0)
        ALOGE("mpv_command(%s) failed: %s", arguments[0] ? arguments[0] : "?", mpv_error_string(result));

    for (jsize i = 0; i < len; ++i) {
        env->ReleaseStringUTFChars(strings[i], arguments[i]);
        env->DeleteLocalRef(strings[i]);
    }
}

jni_func(void, command, jobjectArray jarray) {
    run_command(env, jarray, false);
}

jni_func(void, commandAsync, jobjectArray jarray) {
    run_command(env, jarray, true);
}

// Audio passthrough needs FFmpeg's spdif muxer (ad_spdif); lean builds disable all muxers. No mpv needed.
jni_func(jboolean, spdifMuxerAvailable) {
    using GuessFormat = const void *(*)(const char *, const char *, const char *);
    auto guess = reinterpret_cast<GuessFormat>(dlsym(RTLD_DEFAULT, "av_guess_format"));
    if (!guess) {
        void *lavf = dlopen("libavformat.so", RTLD_NOW | RTLD_NOLOAD);
        if (lavf)
            guess = reinterpret_cast<GuessFormat>(dlsym(lavf, "av_guess_format"));
    }
    if (!guess) {
        ALOGE("av_guess_format not found; audio passthrough disabled");
        return JNI_FALSE;
    }
    return guess("spdif", NULL, NULL) ? JNI_TRUE : JNI_FALSE;
}

package dev.streamybox.player

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import dev.streamybox.design.ControllerNavigation
import dev.streamybox.design.TvDesign
import dev.streamybox.player.mpv.MPVLib
import dev.streamybox.player.ui.PlayerScreen
import java.util.Locale

class PlayerActivity : Activity(), PlayerEngine.Listener {
    private lateinit var ui: TvDesign
    private lateinit var screen: PlayerScreen
    private lateinit var settings: PlayerSettings
    private lateinit var resumeStore: ResumeStore

    private var engine: PlayerEngine? = null
    private var request: PlayRequest? = null
    private var pendingResume: ResumeEntry? = null
    private var latestStatus = PlaybackStatus()
    private var latestVideo = VideoStatus()
    private var latestTracks: List<Track> = emptyList()
    private var latestInfo = EngineInfo()
    private var lastSavedAt = 0L
    private var swallowUp = false
    private var lastStatusLog = 0L

    // The embedded render service took mpv over: stop here, the client app owns the screen now.
    private val mpvHolder = MpvOwner.Holder {
        releaseEngine()
        finish()
    }

    private val callbacks = object : PlayerScreen.Callbacks {
        override fun onPlayPause() = togglePlayback()
        override fun onSeekBack() = seekRelative(-SEEK_MS)
        override fun onSeekForward() = seekRelative(SEEK_MS)
        override fun onAudio() = chooseTrack(TrackKind.AUDIO)
        override fun onSubtitles() = chooseTrack(TrackKind.SUBTITLE)
        override fun onInfo() = showInfo()
        override fun onSettings() {
            engine?.pause()
            startActivity(Intent(this@PlayerActivity, SettingsActivity::class.java))
        }
        override fun onClose() = finish()
        override fun onResume() {
            val resume = pendingResume ?: return
            startPlayback((request ?: return).copy(startPositionMs = resume.positionMs))
        }
        override fun onStartOver() { startPlayback((request ?: return).copy(startPositionMs = 0L)) }
        override fun onRetry() {
            val current = request ?: return
            startPlayback(current.copy(startPositionMs = latestStatus.positionMs.takeIf { it > 5_000 } ?: current.startPositionMs))
        }
        override fun onReplay() = replay()
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ui = TvDesign(this, light = false)
        settings = PlayerSettings(this)
        resumeStore = ResumeStore(this)
        screen = PlayerScreen(this, ui, callbacks)
        setContentView(screen.root)
        ControllerNavigation.install(window, menu = { showInfo() })
        immersive()
        handleIntent(intent)
    }

    override fun onNewIntent(next: Intent) {
        super.onNewIntent(next)
        setIntent(next)
        screen.dismissModal()
        screen.setControlsVisible(true)
        releaseEngine()
        latestStatus = PlaybackStatus()
        latestVideo = VideoStatus()
        latestTracks = emptyList()
        latestInfo = EngineInfo()
        handleIntent(next)
    }

    private fun handleIntent(intent: Intent) {
        val parsed = PlayRequestParser.parse(PlayerIntents.values(intent))
        screen.resetPlayback()
        when (parsed) {
            is ParseResult.Invalid -> {
                screen.setTitle(getString(R.string.app_name), "")
                screen.setLoading(false)
                screen.showError(getString(R.string.player_invalid_title), reason(parsed.error), retryable = false)
            }
            is ParseResult.Ok -> {
                val next = ContentTitles.resolve(this, parsed.request)
                request = next
                screen.setTitle(next.title, sourceLabel(next))
                val resume = if (next.startPositionMs == 0L && settings.config.rememberPosition) {
                    resumeStore.find(next.url)?.takeIf {
                        it.durationMs > 0 && it.positionMs >= 30_000 && it.positionMs < it.durationMs - 15_000
                    }
                } else null
                if (resume != null) {
                    pendingResume = resume
                    screen.setLoading(false)
                    screen.showResume(resume, next.title)
                } else {
                    startPlayback(next)
                }
            }
        }
    }

    private fun startPlayback(next: PlayRequest) {
        releaseEngine()
        screen.dismissModal()
        pendingResume = null
        request = next
        screen.setTitle(next.title, sourceLabel(next))
        screen.setControlsVisible(true)

        if (MPVLib.available) MpvOwner.acquire(mpvHolder)
        val created: PlayerEngine = if (MPVLib.available) MpvEngine(this, settings.config) else MissingEngine()
        engine = created
        screen.bindSurface(created.surface)
        created.setListener(this)
        if (!created.available) {
            screen.setLoading(false)
            screen.showError(getString(R.string.player_error_title), getString(R.string.player_error_native), retryable = false)
            return
        }
        screen.setLoading(true)
        created.prepare(next)
    }

    private fun releaseEngine() {
        engine?.release()
        engine = null
        MpvOwner.release(mpvHolder)
        screen.bindSurface(null)
    }

    private fun togglePlayback() {
        if (latestStatus.phase == Phase.ENDED) {
            replay()
            return
        }
        engine?.togglePause()
        screen.kick()
    }

    private fun replay() {
        // mpv with keep-open=no has unloaded the file at EOF; a fresh load is reliable.
        startPlayback((request ?: return).copy(startPositionMs = 0L))
    }

    private fun seekRelative(deltaMs: Long) {
        val status = latestStatus
        if (status.phase == Phase.LOADING || status.phase == Phase.IDLE) return
        val max = if (status.durationMs > 0) status.durationMs else Long.MAX_VALUE
        val target = (status.positionMs + deltaMs).coerceIn(0L, max)
        engine?.seekBy(deltaMs)
        latestStatus = status.copy(positionMs = target)
        screen.setProgress(target, status.durationMs)
        screen.flashSeek(deltaMs, target)
        screen.kick()
    }

    private fun chooseTrack(kind: TrackKind) {
        screen.setControlsVisible(true)
        screen.showTrackDialog(kind, latestTracks) { id ->
            if (kind == TrackKind.AUDIO) engine?.selectAudio(id ?: "auto")
            else engine?.selectSubtitle(id ?: "auto")
        }
    }

    private fun showInfo() {
        val current = request ?: return
        val video = latestVideo
        val info = latestInfo
        val hdr = when (video.hdr.kind) {
            HdrKind.DV -> getString(R.string.badge_dv, video.hdr.dvLabel ?: getString(R.string.badge_dv_generic))
            HdrKind.HDR10 -> getString(R.string.badge_hdr10)
            HdrKind.HLG -> getString(R.string.badge_hlg)
            HdrKind.SDR -> getString(R.string.badge_sdr)
            HdrKind.UNKNOWN -> getString(R.string.info_none)
        }
        val videoText = listOfNotNull(
            video.codec,
            video.resolution,
            video.fpsText?.let { getString(R.string.info_fps_value, it) },
        ).joinToString(" · ").ifBlank { getString(R.string.info_none) }
        val audioText = listOfNotNull(info.audioCodec, info.audioChannels).joinToString(" · ").ifBlank { getString(R.string.info_none) }
        val decoderText = listOfNotNull(info.hwdec ?: video.hwdec, info.videoCodec).joinToString(" · ").ifBlank { getString(R.string.info_none) }
        val position = if (latestStatus.durationMs > 0) {
            "${TimeFormat.clock(latestStatus.positionMs)} / ${TimeFormat.clock(latestStatus.durationMs)}"
        } else TimeFormat.clock(latestStatus.positionMs)
        val lines = mutableListOf(
            getString(R.string.info_source) to current.url,
            getString(R.string.info_video) to videoText,
            getString(R.string.info_audio) to audioText,
            getString(R.string.info_audio_out) to audioOutputText(),
            getString(R.string.info_hdr) to hdr,
            getString(R.string.info_hdr_out) to outputText(),
            getString(R.string.info_decoder) to decoderText,
            getString(R.string.info_position) to position,
            getString(R.string.info_engine) to (info.version ?: getString(if (MPVLib.available) R.string.settings_engine_ready else R.string.settings_engine_missing)),
            getString(R.string.info_cache) to (info.cacheSeconds?.let { String.format(Locale.ROOT, "%.1f s", it) } ?: getString(R.string.info_none)),
        )
        if (video.hdr.kind == HdrKind.DV) {
            lines += getString(R.string.info_dovi_profile) to listOfNotNull(video.hdr.dvLabel, video.hdr.dvLevel?.let { "Level $it" }).joinToString(" · ")
        }
        screen.setControlsVisible(true)
        screen.showInfo(lines)
    }

    override fun onStatus(status: PlaybackStatus) {
        val wasError = latestStatus.phase == Phase.ERROR
        latestStatus = status
        if (status.phase == Phase.LOADING && (wasError || screen.blockingModal)) {
            screen.dismissModal()
            screen.setLoading(true)
        }
        val now = SystemClock.elapsedRealtime()
        if (BuildConfig.DEBUG && now - lastStatusLog > 2_000) {
            lastStatusLog = now
            android.util.Log.d("SbPlayer", "phase=${status.phase} pos=${status.positionMs} dur=${status.durationMs} paused=${status.paused} buffering=${status.buffering}")
        }
        screen.setStatus(status)
        if (status.phase == Phase.ERROR) {
            screen.showError(getString(R.string.player_error_title), status.error ?: getString(R.string.player_error_detail), retryable = true)
        }
        if (status.phase == Phase.PLAYING && SystemClock.elapsedRealtime() - lastSavedAt > 5_000) savePosition()
    }

    override fun onVideo(status: VideoStatus) {
        val shown = status.copy(outputOverride = HdrSupport.outputKind(this, settings.config.hdr))
        latestVideo = shown
        screen.setVideo(shown)
    }

    override fun onTracks(tracks: List<Track>) { latestTracks = tracks }

    override fun onInfo(info: EngineInfo) { latestInfo = info }

    override fun onFileLoaded() {
        screen.setLoading(false)
        screen.setControlsVisible(true)
    }

    override fun onEnded() {
        request?.let { resumeStore.remove(it.url) }
        screen.setLoading(false)
        screen.showEnded(request?.title.orEmpty())
        releaseAfterPlayback()
    }

    override fun onError(detail: String?) {
        screen.setLoading(false)
        screen.showError(getString(R.string.player_error_title), detail ?: getString(R.string.player_error_detail), retryable = true)
        releaseAfterPlayback()
    }

    // Replay/retry start a fresh engine; dropping the SurfaceView now takes its PQ layer (HDR) off the screen.
    private fun releaseAfterPlayback() {
        val finished = engine ?: return
        screen.root.post { if (engine === finished) releaseEngine() }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Android would run onBackPressed() on the unconsumed ACTION_UP, so handled keys own both events.
        if (event.action == KeyEvent.ACTION_UP && swallowUp) {
            swallowUp = false
            return true
        }
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                    screen.setControlsVisible(true)
                    togglePlayback()
                    return consume()
                }
                KeyEvent.KEYCODE_MEDIA_REWIND -> { seekRelative(-SEEK_MS); return consume() }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekRelative(SEEK_MS); return consume() }
                KeyEvent.KEYCODE_MEDIA_STOP -> { finish(); return consume() }
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO -> { showInfo(); return consume() }
                KeyEvent.KEYCODE_BACK -> {
                    if (screen.blockingModal) { finish(); return consume() }
                    if (screen.controlsShown) { screen.setControlsVisible(false); return consume() }
                    finish()
                    return consume()
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> if (!screen.controlsShown) { seekRelative(-SEEK_MS); return consume() }
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (!screen.controlsShown) { seekRelative(SEEK_MS); return consume() }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    if (!screen.controlsShown) { screen.setControlsVisible(true); return consume() }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun consume(): Boolean {
        swallowUp = true
        return true
    }

    override fun onPause() {
        super.onPause()
        if (!isChangingConfigurations) {
            if (latestStatus.durationMs > 0) engine?.pause()
            savePosition(force = true)
        }
    }

    override fun onStop() {
        super.onStop()
        savePosition(force = true)
    }

    override fun onDestroy() {
        savePosition(force = true)
        releaseEngine()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    private fun savePosition(force: Boolean = false) {
        val current = request ?: return
        val status = latestStatus
        if (!settings.config.rememberPosition) return
        if (status.durationMs <= 0) return
        if (status.positionMs < 30_000) return
        if (status.positionMs >= status.durationMs - 15_000) {
            resumeStore.remove(current.url)
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastSavedAt < 5_000) return
        lastSavedAt = now
        resumeStore.save(
            ResumeEntry(
                url = current.url,
                title = current.title,
                headers = current.headers.map { "${it.name}: ${it.value}" },
                positionMs = status.positionMs,
                durationMs = status.durationMs,
                updatedAt = System.currentTimeMillis(),
                mimeType = current.mimeType,
            )
        )
    }

    private fun audioOutputText(): String {
        val output = latestTracks.firstOrNull { it.kind == TrackKind.AUDIO && it.selected }?.output ?: return getString(R.string.info_none)
        val (kind, value) = output.split(':', limit = 2).let { it[0] to it.getOrElse(1) { "" } }
        return when (kind) {
            "passthrough" -> getString(R.string.info_audio_bitstream, codecName(value))
            else -> value.toIntOrNull()?.let { getString(R.string.info_audio_pcm, it) } ?: getString(R.string.info_none)
        }
    }

    private fun codecName(codec: String): String = when (codec) {
        "ac3" -> "Dolby Digital"
        "eac3" -> "Dolby Digital Plus"
        "truehd" -> "Dolby TrueHD"
        "dts" -> "DTS"
        "dts-hd" -> "DTS-HD"
        else -> codec.uppercase(Locale.ROOT)
    }

    private fun outputText(): String = when (HdrSupport.outputKind(this, settings.config.hdr)) {
        HdrKind.HDR10 -> getString(R.string.badge_hdr10_out)
        HdrKind.HLG -> getString(R.string.badge_hlg_out)
        else -> getString(R.string.badge_sdr_out)
    }

    private fun reason(error: RequestError): String = requestErrorText(this, error)

    private fun sourceLabel(next: PlayRequest): String {
        val uri = runCatching { Uri.parse(next.url) }.getOrNull()
        return when (uri?.scheme?.lowercase(Locale.ROOT)) {
            "content", "file" -> getString(R.string.source_local)
            "http", "https" -> uri.host ?: getString(R.string.source_stream)
            else -> getString(R.string.source_stream)
        }
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        val decor = runCatching { window.decorView }.getOrNull() ?: return
        decor.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private companion object { const val SEEK_MS = 10_000L }
}

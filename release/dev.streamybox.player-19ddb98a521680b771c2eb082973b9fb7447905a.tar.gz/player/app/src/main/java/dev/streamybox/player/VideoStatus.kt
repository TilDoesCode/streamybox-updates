package dev.streamybox.player

enum class HdrKind { DV, HDR10, HLG, SDR, UNKNOWN }

data class HdrInfo(val kind: HdrKind, val dvProfile: Int? = null, val dvLevel: Int? = null) {
    /** Short DV profile label, e.g. `P8`; null when this is not Dolby Vision. */
    val dvLabel: String? get() = dvProfile?.let { "P$it" }
}

/** Values reported by mpv. Kept pure so the badge logic is unit tested. */
data class VideoStatus(
    val width: Int? = null,
    val height: Int? = null,
    val fps: Double? = null,
    val codec: String? = null,
    val hwdec: String? = null,
    val primaries: String? = null,
    val gamma: String? = null,
    val dvProfile: Int? = null,
    val dvLevel: Int? = null,
    val sigPeak: Double? = null,
    val targetPrimaries: String? = null,
    val targetGamma: String? = null,
    val targetPeak: Double? = null,
    val dvDetected: Boolean = false,
    /** Set by the activity from the HDR setting and the system feature; wins over mpv's target hints. */
    val outputOverride: HdrKind? = null,
) {
    val hdr: HdrInfo
        get() = if (dvDetected && (dvProfile ?: 0) <= 0) HdrInfo(HdrKind.DV)
        else HdrDetect.detect(primaries, gamma, dvProfile, dvLevel)

    /** What the VO actually sends to the TV; HDR10/SDR here is the tone-mapped output. */
    val outputHdr: HdrInfo
        get() = HdrDetect.detect(targetPrimaries, targetGamma, null, null)

    val resolution: String?
        get() = if ((width ?: 0) > 0 && (height ?: 0) > 0) "$width×$height" else null

    val fpsText: String?
        get() = fps?.takeIf { it > 0 }?.let { HdrDetect.fps(it) }
}

object HdrDetect {
    fun detect(primaries: String?, gamma: String?, dvProfile: Int?, dvLevel: Int?): HdrInfo {
        val profile = dvProfile?.takeIf { it > 0 }
        if (profile != null) return HdrInfo(HdrKind.DV, profile, dvLevel?.takeIf { it > 0 })
        val p = primaries?.lowercase()
        val g = gamma?.lowercase()
        return when {
            g == "pq" || g == "st2084" || g == "smpte2084" -> HdrInfo(if (p == "bt.2020" || p == "bt2020") HdrKind.HDR10 else HdrKind.HDR10)
            g == "hlg" -> HdrInfo(HdrKind.HLG)
            p != null || g != null -> HdrInfo(HdrKind.SDR)
            else -> HdrInfo(HdrKind.UNKNOWN)
        }
    }

    fun fps(value: Double): String {
        val rounded = kotlin.math.round(value * 1000.0) / 1000.0
        return if (rounded == kotlin.math.floor(rounded)) rounded.toInt().toString()
        else java.lang.String.format(java.util.Locale.ROOT, "%.3f", rounded).trimEnd('0').trimEnd('.')
    }
}

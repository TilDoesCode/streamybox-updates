package dev.streamybox.player

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class ResumeEntry(
    val url: String,
    val title: String,
    val headers: List<String>,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAt: Long,
    val mimeType: String? = null,
) {
    val fraction: Float get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    fun toRequest(): PlayRequest? {
        val result = PlayRequestParser.parse(
            IntentValues(
                action = PlayRequestParser.ACTION_PLAY,
                type = mimeType,
                extraUrl = url,
                extraTitle = title,
                headerExtras = headers,
                startPositionMs = positionMs,
            )
        )
        return (result as? ParseResult.Ok)?.request
    }
}

/** Last position per stream, local only. Sized for a TV box (12 entries). */
class ResumeStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("resume", Context.MODE_PRIVATE)

    fun list(): List<ResumeEntry> {
        val entries = ArrayList<ResumeEntry>()
        for ((key, raw) in prefs.all) {
            if (!key.startsWith(PREFIX) || raw !is String) continue
            val entry = runCatching { decode(JSONObject(raw)) }.getOrNull()
            if (entry == null) prefs.edit().remove(key).apply() else entries += entry
        }
        return entries.sortedByDescending { it.updatedAt }
    }

    fun find(url: String): ResumeEntry? = list().firstOrNull { it.url == url }

    fun save(entry: ResumeEntry) {
        val stored = entry.copy(updatedAt = System.currentTimeMillis())
        prefs.edit().putString(PREFIX + key(stored.url), encode(stored)).apply()
        prune()
    }

    fun remove(url: String) {
        prefs.edit().remove(PREFIX + key(url)).apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }

    private fun prune() {
        val entries = list()
        if (entries.size <= MAX_ENTRIES) return
        val edit = prefs.edit()
        entries.drop(MAX_ENTRIES).forEach { edit.remove(PREFIX + key(it.url)) }
        edit.apply()
    }

    private fun key(url: String): String {
        val digest = MessageDigest.getInstance("SHA-1").digest(url.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun encode(entry: ResumeEntry): String = JSONObject().apply {
        put("url", entry.url)
        put("title", entry.title)
        put("position", entry.positionMs)
        put("duration", entry.durationMs)
        put("updated", entry.updatedAt)
        entry.mimeType?.let { put("mime", it) }
        put("headers", JSONArray(entry.headers))
    }.toString()

    private fun decode(json: JSONObject): ResumeEntry? {
        val url = json.optString("url").takeIf { it.isNotBlank() } ?: return null
        val headers = json.optJSONArray("headers")?.let { array ->
            (0 until array.length()).mapNotNull { array.optString(it).takeIf(String::isNotBlank) }
        }.orEmpty()
        return ResumeEntry(
            url = url,
            title = json.optString("title").ifBlank { PlayRequestParser.deriveTitle(url) },
            headers = headers,
            positionMs = json.optLong("position").coerceAtLeast(0L),
            durationMs = json.optLong("duration").coerceAtLeast(0L),
            updatedAt = json.optLong("updated"),
            mimeType = json.optString("mime").takeIf { it.isNotBlank() },
        )
    }

    private companion object {
        const val PREFIX = "r."
        const val MAX_ENTRIES = 12
    }
}

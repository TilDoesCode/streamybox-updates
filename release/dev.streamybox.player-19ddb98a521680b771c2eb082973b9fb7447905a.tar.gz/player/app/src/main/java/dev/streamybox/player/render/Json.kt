package dev.streamybox.player.render

import java.util.Locale

/**
 * Minimal JSON for the render contract (no android.* so the JVM tests cover it).
 * Parses to Map/List/String/Long/Double/Boolean/null; [write] skips null map values.
 */
object Json {
    const val MAX_INPUT = 64 * 1024
    private const val MAX_DEPTH = 16

    class SyntaxError(message: String) : IllegalArgumentException(message)

    fun parse(text: String): Any? {
        if (text.length > MAX_INPUT) throw SyntaxError("input too large")
        val reader = Reader(text)
        val value = reader.value(0)
        reader.skipSpace()
        if (!reader.done) throw SyntaxError("trailing data at ${reader.pos}")
        return value
    }

    fun write(value: Any?): String = StringBuilder().also { append(it, value) }.toString()

    private fun append(out: StringBuilder, value: Any?) {
        when (value) {
            null -> out.append("null")
            is String -> quote(out, value)
            is Boolean -> out.append(value)
            is Int, is Long, is Short, is Byte -> out.append(value)
            is Double -> if (value.isFinite()) out.append(number(value)) else out.append("null")
            is Float -> append(out, value.toDouble())
            is Map<*, *> -> {
                out.append('{')
                var first = true
                for ((key, item) in value) {
                    if (item == null) continue
                    if (!first) out.append(',')
                    first = false
                    quote(out, key.toString())
                    out.append(':')
                    append(out, item)
                }
                out.append('}')
            }
            is Iterable<*> -> {
                out.append('[')
                value.forEachIndexed { index, item ->
                    if (index > 0) out.append(',')
                    append(out, item)
                }
                out.append(']')
            }
            else -> quote(out, value.toString())
        }
    }

    private fun number(value: Double): String =
        if (value == Math.rint(value) && kotlin.math.abs(value) < 1e15) value.toLong().toString()
        else String.format(Locale.ROOT, "%.3f", value).trimEnd('0').trimEnd('.')

    private fun quote(out: StringBuilder, text: String) {
        out.append('"')
        for (ch in text) {
            when (ch) {
                '"' -> out.append("\\\"")
                '\\' -> out.append("\\\\")
                '\n' -> out.append("\\n")
                '\r' -> out.append("\\r")
                '\t' -> out.append("\\t")
                '\b' -> out.append("\\b")
                '\u000c' -> out.append("\\f")
                else -> if (ch < ' ' || ch == ' ' || ch == ' ') {
                    out.append(String.format(Locale.ROOT, "\\u%04x", ch.code))
                } else out.append(ch)
            }
        }
        out.append('"')
    }

    private class Reader(val text: String) {
        var pos = 0
        val done: Boolean get() = pos >= text.length

        fun skipSpace() {
            while (pos < text.length && text[pos] in " \t\r\n") pos++
        }

        fun value(depth: Int): Any? {
            if (depth > MAX_DEPTH) throw SyntaxError("nesting too deep")
            skipSpace()
            if (done) throw SyntaxError("unexpected end")
            return when (val ch = text[pos]) {
                '{' -> obj(depth)
                '[' -> array(depth)
                '"' -> string()
                't' -> literal("true", true)
                'f' -> literal("false", false)
                'n' -> literal("null", null)
                else -> if (ch == '-' || ch in '0'..'9') number() else throw SyntaxError("unexpected '$ch' at $pos")
            }
        }

        private fun obj(depth: Int): Map<String, Any?> {
            pos++
            val result = LinkedHashMap<String, Any?>()
            skipSpace()
            if (peek('}')) { pos++; return result }
            while (true) {
                skipSpace()
                if (!peek('"')) throw SyntaxError("expected key at $pos")
                val key = string()
                skipSpace()
                expect(':')
                result[key] = value(depth + 1)
                skipSpace()
                if (peek(',')) { pos++; continue }
                expect('}')
                return result
            }
        }

        private fun array(depth: Int): List<Any?> {
            pos++
            val result = ArrayList<Any?>()
            skipSpace()
            if (peek(']')) { pos++; return result }
            while (true) {
                result += value(depth + 1)
                skipSpace()
                if (peek(',')) { pos++; continue }
                expect(']')
                return result
            }
        }

        private fun string(): String {
            pos++
            val out = StringBuilder()
            while (true) {
                if (done) throw SyntaxError("unterminated string")
                val ch = text[pos++]
                when {
                    ch == '"' -> return out.toString()
                    ch == '\\' -> {
                        if (done) throw SyntaxError("bad escape")
                        when (val esc = text[pos++]) {
                            '"', '\\', '/' -> out.append(esc)
                            'b' -> out.append('\b')
                            'f' -> out.append('\u000c')
                            'n' -> out.append('\n')
                            'r' -> out.append('\r')
                            't' -> out.append('\t')
                            'u' -> {
                                if (pos + 4 > text.length) throw SyntaxError("bad unicode escape")
                                out.append(text.substring(pos, pos + 4).toIntOrNull(16)?.toChar() ?: throw SyntaxError("bad unicode escape"))
                                pos += 4
                            }
                            else -> throw SyntaxError("bad escape '$esc'")
                        }
                    }
                    ch < ' ' -> throw SyntaxError("control character in string")
                    else -> out.append(ch)
                }
            }
        }

        private fun number(): Any {
            val start = pos
            if (peek('-')) pos++
            while (pos < text.length && text[pos] in "0123456789.eE+-") pos++
            val raw = text.substring(start, pos)
            return raw.toLongOrNull() ?: raw.toDoubleOrNull()?.takeIf { it.isFinite() } ?: throw SyntaxError("bad number '$raw'")
        }

        private fun literal(word: String, value: Any?): Any? {
            if (!text.startsWith(word, pos)) throw SyntaxError("unexpected literal at $pos")
            pos += word.length
            return value
        }

        private fun peek(ch: Char) = pos < text.length && text[pos] == ch

        private fun expect(ch: Char) {
            if (!peek(ch)) throw SyntaxError("expected '$ch' at $pos")
            pos++
        }
    }
}

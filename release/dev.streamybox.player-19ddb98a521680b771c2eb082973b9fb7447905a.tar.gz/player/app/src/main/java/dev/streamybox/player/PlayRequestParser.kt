package dev.streamybox.player

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Locale

data class Header(val name: String, val value: String)

data class ExternalSubtitle(val url: String, val title: String? = null, val language: String? = null)

/** A validated, already normalised playback request. */
data class PlayRequest(
    val url: String,
    val title: String,
    val headers: List<Header> = emptyList(),
    val startPositionMs: Long = 0L,
    val mimeType: String? = null,
    val externalSubtitles: List<ExternalSubtitle> = emptyList(),
    /** mpv track ids to select after loading; subtitle -1 = off. */
    val audioTrack: Int? = null,
    val subtitleTrack: Int? = null,
    val muted: Boolean = false,
) {
    /** Header block for mpv's `http-header-fields` property. */
    fun headerFields(): String = headers.joinToString(separator = "") { "${it.name}: ${it.value}\r\n" }

    fun headerMap(): Map<String, String> = headers.associate { it.name to it.value }
}

enum class RequestError {
    EMPTY_URL,
    BAD_ACTION,
    UNSUPPORTED_SCHEME,
    MALFORMED_URL,
    MISSING_HOST,
    NOT_VIDEO,
    BAD_HEADER,
    BAD_POSITION,
}

sealed interface ParseResult {
    data class Ok(val request: PlayRequest) : ParseResult
    data class Invalid(val error: RequestError, val detail: String? = null) : ParseResult
}

/**
 * Platform independent view of an intent. Kept free of android.* so the parser is unit tested on the JVM.
 */
data class IntentValues(
    val action: String? = null,
    val type: String? = null,
    val data: String? = null,
    val extraUrl: String? = null,
    val extraTitle: String? = null,
    val headerExtras: List<String> = emptyList(),
    val startPositionMs: Long? = null,
    val startPositionText: String? = null,
    val platformStartPositionMs: Long? = null,
)

object PlayRequestParser {
    const val ACTION_PLAY = "dev.streamybox.player.PLAY"
    const val ACTION_VIEW = "android.intent.action.VIEW"

    const val EXTRA_URL = "url"
    const val EXTRA_HEADERS = "headers"
    const val EXTRA_START_MS = "start_position_ms"
    const val EXTRA_TITLE = "title"

    const val MAX_HEADERS = 32
    const val MAX_HEADER_NAME = 64
    const val MAX_HEADER_VALUE = 2048
    const val MAX_URL = 8192
    const val MAX_POSITION_MS = 7L * 24 * 60 * 60 * 1000

    private val videoExtensions = setOf("mp4", "m4v", "mkv", "webm", "ts", "m2ts", "mts", "mov", "avi", "mpg", "mpeg", "vob", "ogv", "3gp")
    private val extraMimeTypes = setOf(
        "application/vnd.apple.mpegurl",
        "application/x-mpegurl",
        "application/dash+xml",
        "application/mp4",
    )

    fun parse(values: IntentValues): ParseResult {
        val action = values.action ?: if (values.data != null) ACTION_VIEW else ACTION_PLAY
        if (action != ACTION_VIEW && action != ACTION_PLAY) return ParseResult.Invalid(RequestError.BAD_ACTION)

        val rawUrl = if (action == ACTION_PLAY) values.extraUrl ?: values.data else values.data ?: values.extraUrl
        val url = rawUrl?.trim().orEmpty()
        validateAddress(url)?.let { return ParseResult.Invalid(it) }

        if (action == ACTION_VIEW && values.type != null && !isVideoMime(values.type)) {
            return ParseResult.Invalid(RequestError.NOT_VIDEO, values.type)
        }

        val headers = when (val parsed = parseHeaders(values.headerExtras)) {
            is HeaderResult.Ok -> parsed.headers
            is HeaderResult.Invalid -> return ParseResult.Invalid(RequestError.BAD_HEADER, parsed.detail)
        }

        val position = when {
            values.startPositionMs != null -> values.startPositionMs
            values.startPositionText != null -> {
                if (values.startPositionText.isBlank()) 0L
                else values.startPositionText.trim().toLongOrNull()
                    ?: return ParseResult.Invalid(RequestError.BAD_POSITION, values.startPositionText)
            }
            values.platformStartPositionMs != null -> values.platformStartPositionMs
            else -> 0L
        }.coerceIn(0L, MAX_POSITION_MS)

        val title = values.extraTitle?.trim()?.take(200)?.takeIf { it.isNotEmpty() } ?: deriveTitle(url)
        return ParseResult.Ok(PlayRequest(url, title, headers, position, values.type))
    }

    /** Null when [raw] is a playable address, otherwise the reason shown by the open screen. */
    fun validateAddress(raw: String): RequestError? {
        val value = raw.trim()
        if (value.isEmpty()) return RequestError.EMPTY_URL
        if (value.length > MAX_URL) return RequestError.MALFORMED_URL
        if (value.any { it.isWhitespace() || it.isISOControl() }) return RequestError.MALFORMED_URL
        val uri = runCatching { URI(value) }.getOrNull() ?: return RequestError.MALFORMED_URL
        return when (uri.scheme?.lowercase(Locale.ROOT)) {
            null -> RequestError.MALFORMED_URL
            "http", "https" -> if (uri.host.isNullOrBlank()) RequestError.MISSING_HOST else null
            "file" -> if (uri.path.isNullOrBlank()) RequestError.MALFORMED_URL else null
            "content" -> if (uri.authority.isNullOrBlank()) RequestError.MALFORMED_URL else null
            else -> RequestError.UNSUPPORTED_SCHEME
        }
    }

    /** Content providers expose a row id as the last path segment; ask for DISPLAY_NAME instead. */
    fun needsContentTitle(url: String, title: String): Boolean =
        url.startsWith("content://") &&
            (title.isBlank() || title.all(Char::isDigit) || title == url.trimEnd('/').substringAfterLast('/'))

    fun isVideoMime(type: String): Boolean {
        val value = type.trim().lowercase(Locale.ROOT)
        return value.startsWith("video/") || value in extraMimeTypes
    }

    /** Accepts `Name: value` lines, each entry may carry several newline separated headers. */
    fun parseHeaders(entries: List<String>): HeaderResult {
        val headers = ArrayList<Header>()
        for (entry in entries) {
            for (line in entry.split("\r\n", "\n", "\r")) {
                val text = line.trim()
                if (text.isEmpty()) continue
                if (headers.size >= MAX_HEADERS) return HeaderResult.Invalid("too many headers")
                val colon = text.indexOf(':')
                if (colon <= 0) return HeaderResult.Invalid(text.take(80))
                val name = text.substring(0, colon).trim()
                val value = text.substring(colon + 1).trim()
                if (!validHeaderName(name)) return HeaderResult.Invalid(name.take(80))
                if (value.length > MAX_HEADER_VALUE || value.any { it == '\r' || it == '\n' || it == '\u0000' }) {
                    return HeaderResult.Invalid(name)
                }
                headers += Header(name, value)
            }
        }
        return HeaderResult.Ok(headers)
    }

    /** Safe display name from the last URL path segment, without the usual container suffix. */
    fun deriveTitle(url: String): String {
        val uri = runCatching { URI(url) }.getOrNull()
        val segment = uri?.rawPath?.trimEnd('/')?.substringAfterLast('/')?.takeIf { it.isNotEmpty() }
        val decoded = segment?.let { runCatching { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) }.getOrDefault(it) }
        val title = decoded?.takeIf { it.isNotBlank() } ?: uri?.host ?: uri?.authority ?: "Stream"
        val dot = title.lastIndexOf('.')
        val base = if (dot > 0 && title.substring(dot + 1).lowercase(Locale.ROOT) in videoExtensions) title.substring(0, dot) else title
        return base.ifBlank { "Stream" }.take(200)
    }

    private fun validHeaderName(name: String): Boolean {
        if (name.isEmpty() || name.length > MAX_HEADER_NAME) return false
        return name.all { ch ->
            val c = ch.code
            c in 0x61..0x7a || c in 0x41..0x5a || c in 0x30..0x39 || ch in "!#$%&'*+-.^_`|~"
        }
    }

    sealed interface HeaderResult {
        data class Ok(val headers: List<Header>) : HeaderResult
        data class Invalid(val detail: String?) : HeaderResult
    }
}

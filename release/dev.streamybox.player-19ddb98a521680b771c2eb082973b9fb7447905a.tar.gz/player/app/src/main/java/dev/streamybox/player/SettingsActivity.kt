package dev.streamybox.player

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import dev.streamybox.design.ControllerNavigation
import dev.streamybox.design.Motion
import dev.streamybox.design.SharedState
import dev.streamybox.design.TvDesign
import dev.streamybox.design.card
import dev.streamybox.player.mpv.MPVLib

class SettingsActivity : Activity() {
    private lateinit var ui: TvDesign
    private lateinit var settings: PlayerSettings
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private val rows = mutableListOf<View>()
    private var lastRowIndex = 0

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val shared = runCatching { SharedState.read(this) }.getOrDefault(Bundle())
        ui = TvDesign(this, shared.getBoolean("light", false))
        settings = PlayerSettings(this)
        ControllerNavigation.install(window, menu = { finish() })
        build()
        immersive()
    }

    private fun build() {
        val root = FrameLayout(this)
        root.setBackgroundDrawable(ui.backdrop())
        setContentView(root)

        scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            isFocusable = false
            isFocusableInTouchMode = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            clipToPadding = false
        }
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(64f), ui.dp(44f), ui.dp(64f), ui.dp(40f))
            clipChildren = false
            clipToPadding = false
        }
        scroll.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.viewTreeObserver.addOnGlobalFocusChangeListener { _, next ->
            val index = rows.indexOf(next)
            if (index >= 0) lastRowIndex = index
        }
        Motion.enter(content, dy = ui.dp(12f).toFloat())
        render()
    }

    private fun render() {
        content.removeAllViews()
        rows.clear()
        val config = settings.config

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = ui.key(getString(R.string.back), 1) { finish() }.apply {
            setPadding(ui.dp(22f), 0, ui.dp(22f), 0)
        }
        header.addView(back, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui.dp(44f)))
        header.addView(ui.text(getString(R.string.settings_title), TvDesign.TYPE_H1, ui.foreground, weight = 650), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = ui.dp(20f) })
        content.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(ui.text(getString(R.string.settings_subtitle), 14f, ui.muted).apply { setPadding(0, ui.dp(8f), 0, ui.dp(18f)) })

        addGroup(
            getString(R.string.settings_picture),
            listOf(
                ui.item(getString(R.string.settings_hdr), getString(R.string.settings_hdr_detail), hdrLabel(config.hdr), TvDesign.Trail.CHIP) {
                    choose(getString(R.string.settings_hdr), HdrMode.values().map { mode -> hdrLabel(mode) to { update { config -> config.copy(hdr = mode) } } }, config.hdr.ordinal)
                },
            ),
        )

        addGroup(
            getString(R.string.settings_playback),
            listOf(
                ui.item(getString(R.string.settings_hwdec), getString(R.string.settings_hwdec_detail), hwdecLabel(config.hwdecode), TvDesign.Trail.CHIP) {
                    choose(getString(R.string.settings_hwdec), HwDecode.values().map { mode -> hwdecLabel(mode) to { update { config -> config.copy(hwdecode = mode) } } }, config.hwdecode.ordinal)
                },
                ui.item(getString(R.string.settings_cache), getString(R.string.settings_cache_detail), cacheLabel(config.cache), TvDesign.Trail.CHIP) {
                    choose(getString(R.string.settings_cache), NetworkCache.values().map { mode -> cacheLabel(mode) to { update { config -> config.copy(cache = mode) } } }, config.cache.ordinal)
                },
                ui.item(getString(R.string.settings_remember), getString(R.string.settings_remember_detail), trail = if (config.rememberPosition) TvDesign.Trail.ON else TvDesign.Trail.OFF) {
                    update { config -> config.copy(rememberPosition = !config.rememberPosition) }
                },
            ),
        )

        addGroup(
            getString(R.string.settings_audio),
            listOf(
                ui.item(getString(R.string.settings_passthrough), getString(R.string.settings_passthrough_detail), passthroughLabel(config.passthrough), TvDesign.Trail.CHIP) {
                    choose(getString(R.string.settings_passthrough), AudioPassthrough.values().map { mode -> passthroughLabel(mode) to { update { config -> config.copy(passthrough = mode) } } }, config.passthrough.ordinal)
                },
                ui.item(getString(R.string.settings_audio_language), "", languageLabel(config.audioLanguage), TvDesign.Trail.CHIP) {
                    chooseLanguage(getString(R.string.settings_audio_language), selectedLanguage(config.audioLanguage)) { code ->
                        update { config -> config.copy(audioLanguage = code) }
                    }
                },
            ),
        )

        addGroup(
            getString(R.string.settings_subtitles),
            listOf(
                ui.item(getString(R.string.settings_subtitle_mode), getString(R.string.settings_subtitle_mode_detail), subtitleLabel(config.subtitleMode), TvDesign.Trail.CHIP) {
                    choose(getString(R.string.settings_subtitle_mode), SubtitleMode.values().map { mode -> subtitleLabel(mode) to { update { config -> config.copy(subtitleMode = mode) } } }, config.subtitleMode.ordinal)
                },
                ui.item(getString(R.string.settings_subtitle_language), "", languageLabel(config.subtitleLanguage), TvDesign.Trail.CHIP) {
                    chooseLanguage(getString(R.string.settings_subtitle_language), selectedLanguage(config.subtitleLanguage)) { code ->
                        update { config -> config.copy(subtitleLanguage = code) }
                    }
                },
            ),
        )

        val engineReady = MPVLib.available
        addGroup(
            getString(R.string.settings_about),
            listOf(
                ui.item(getString(R.string.settings_engine), if (engineReady) getString(R.string.open_engine_ready) else getString(R.string.open_engine_missing_detail), if (engineReady) getString(R.string.settings_engine_ready) else getString(R.string.settings_engine_missing)),
                ui.item(getString(R.string.settings_version), "", BuildConfig.VERSION_NAME),
                ui.item(getString(R.string.settings_license), getString(R.string.settings_license_detail), action = null),
                ui.item(getString(R.string.settings_source), getString(R.string.settings_source_detail), action = null),
            ),
        )
        content.addView(ui.text(getString(R.string.settings_applied), 12.5f, ui.faint).apply { setPadding(ui.dp(6f), ui.dp(18f), 0, 0) })
        content.post { (rows.getOrNull(lastRowIndex) ?: rows.firstOrNull())?.requestFocus() }
    }

    private fun addGroup(title: String, groupRows: List<View>) {
        content.addView(ui.header(title))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
        groupRows.forEach {
            box.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            rows += it
        }
        content.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ui.group(box)
    }

    private fun choose(title: String, options: List<Pair<String, () -> Unit>>, selected: Int = 0) {
        ui.card(title, options, focus = selected.coerceAtLeast(0))
    }

    private fun chooseLanguage(title: String, selected: Int, onPick: (String) -> Unit) {
        ui.card(title, languages().map { (label, code) -> label to { onPick(code) } }, focus = selected)
    }

    private fun update(block: (PlayerConfig) -> PlayerConfig) {
        settings.change(block)
        render()
    }

    private fun languages(): List<Pair<String, String>> = listOf(
        getString(R.string.language_system) to "",
        getString(R.string.language_german) to "de",
        getString(R.string.language_english) to "en",
    )

    private fun languageLabel(code: String): String = when (code) {
        "de" -> getString(R.string.language_german)
        "en" -> getString(R.string.language_english)
        else -> getString(R.string.language_system)
    }

    private fun selectedLanguage(code: String): Int = when (code) {
        "de" -> 1
        "en" -> 2
        else -> 0
    }

    private fun hdrLabel(mode: HdrMode): String = getString(
        when (mode) {
            HdrMode.AUTO -> R.string.settings_hdr_auto
            HdrMode.HDR10 -> R.string.settings_hdr_hdr10
            HdrMode.SDR -> R.string.settings_hdr_sdr
        }
    )

    private fun hwdecLabel(mode: HwDecode): String = getString(
        when (mode) {
            HwDecode.MEDIACODEC -> R.string.settings_hwdec_auto
            HwDecode.COPY -> R.string.settings_hwdec_copy
            HwDecode.SOFTWARE -> R.string.settings_hwdec_off
        }
    )

    private fun cacheLabel(mode: NetworkCache): String = getString(
        when (mode) {
            NetworkCache.AUTO -> R.string.settings_cache_auto
            NetworkCache.OFF -> R.string.settings_cache_off
        }
    )

    private fun passthroughLabel(mode: AudioPassthrough): String = getString(
        when (mode) {
            AudioPassthrough.AUTO -> R.string.settings_passthrough_auto
            AudioPassthrough.PCM -> R.string.settings_passthrough_pcm
        }
    )

    private fun subtitleLabel(mode: SubtitleMode): String = getString(
        when (mode) {
            SubtitleMode.AUTO -> R.string.settings_subtitle_auto
            SubtitleMode.FORCED -> R.string.settings_subtitle_forced
            SubtitleMode.OFF -> R.string.settings_subtitle_off
        }
    )

    @Suppress("DEPRECATION")
    private fun immersive() {
        val decor = runCatching { window.decorView }.getOrNull() ?: return
        decor.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }
}

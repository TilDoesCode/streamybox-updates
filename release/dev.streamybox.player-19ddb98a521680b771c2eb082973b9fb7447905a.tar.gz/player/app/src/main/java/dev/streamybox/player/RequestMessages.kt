package dev.streamybox.player

import android.content.Context

fun requestErrorText(context: Context, error: RequestError): String = when (error) {
    RequestError.EMPTY_URL, RequestError.MALFORMED_URL, RequestError.MISSING_HOST -> context.getString(R.string.open_url_malformed)
    RequestError.UNSUPPORTED_SCHEME -> context.getString(R.string.open_url_scheme)
    RequestError.NOT_VIDEO -> context.getString(R.string.player_not_video)
    RequestError.BAD_HEADER -> context.getString(R.string.player_bad_headers)
    RequestError.BAD_POSITION -> context.getString(R.string.player_bad_position)
    RequestError.BAD_ACTION -> context.getString(R.string.player_bad_action)
}

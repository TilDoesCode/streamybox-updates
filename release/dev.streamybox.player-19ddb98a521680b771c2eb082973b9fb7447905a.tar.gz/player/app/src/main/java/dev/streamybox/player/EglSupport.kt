package dev.streamybox.player

import android.opengl.EGL14
import android.opengl.EGLExt

/** Whether the GPU offers a 10-bit window config for `egl-output-format=rgb10_a2` (no window needed). */
object EglSupport {
    val rgb10a2: Boolean by lazy { runCatching { probe() }.getOrDefault(true) }

    private fun probe(): Boolean {
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (display == EGL14.EGL_NO_DISPLAY) return true
        val version = IntArray(2)
        if (!EGL14.eglInitialize(display, version, 0, version, 1)) return true
        val attributes = intArrayOf(
            EGL14.EGL_RED_SIZE, 10, EGL14.EGL_GREEN_SIZE, 10, EGL14.EGL_BLUE_SIZE, 10, EGL14.EGL_ALPHA_SIZE, 2,
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR or EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            EGL14.EGL_NONE,
        )
        val count = IntArray(1)
        val configs = arrayOfNulls<android.opengl.EGLConfig>(8)
        val ok = EGL14.eglChooseConfig(display, attributes, 0, configs, 0, configs.size, count, 0)
        // eglChooseConfig treats sizes as minimums; only an exact 10/10/10/2 config counts.
        val exact = ok && (0 until count[0]).any { index ->
            val config = configs[index] ?: return@any false
            val value = IntArray(1)
            fun size(attribute: Int) = if (EGL14.eglGetConfigAttrib(display, config, attribute, value, 0)) value[0] else -1
            size(EGL14.EGL_RED_SIZE) == 10 && size(EGL14.EGL_GREEN_SIZE) == 10 &&
                size(EGL14.EGL_BLUE_SIZE) == 10 && size(EGL14.EGL_ALPHA_SIZE) == 2
        }
        return exact
    }
}

package dev.streamybox.player.render

/**
 * One client session at a time. Ids are positive and never reused; a call must carry the current id
 * and come from the uid that attached it, otherwise it is ignored. Thread safe (binder threads).
 */
class RenderSessions {
    data class Attached(val id: Int, val replaced: Int?)

    private var next = 1
    private var currentId: Int? = null
    private var currentUid: Int? = null

    @Synchronized
    fun attach(uid: Int): Attached {
        val replaced = currentId
        val id = next
        next = if (next == Int.MAX_VALUE) 1 else next + 1
        currentId = id
        currentUid = uid
        return Attached(id, replaced)
    }

    @Synchronized
    fun isCurrent(id: Int, uid: Int): Boolean = id > 0 && id == currentId && uid == currentUid

    @Synchronized
    fun isCurrent(id: Int): Boolean = id > 0 && id == currentId

    @Synchronized
    fun detach(id: Int): Boolean {
        if (id <= 0 || id != currentId) return false
        currentId = null
        currentUid = null
        return true
    }

    @get:Synchronized
    val current: Int? get() = currentId
}

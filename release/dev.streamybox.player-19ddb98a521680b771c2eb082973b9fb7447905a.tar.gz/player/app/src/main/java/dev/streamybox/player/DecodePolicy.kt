package dev.streamybox.player

/** Hardware decode policy: P5 must avoid the OES zero-copy path, P8/non-DV use it. */
object DecodePolicy {
    fun hwdec(config: HwDecode, dvProfile: Int?): String = when (config) {
        HwDecode.MEDIACODEC -> if (dvProfile == 5) "mediacodec-copy" else "mediacodec"
        HwDecode.COPY -> "mediacodec-copy"
        HwDecode.SOFTWARE -> "no"
    }
}

package dev.streamybox.player.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import dev.streamybox.design.TvDesign

/** Thin seek/progress line. Deliberately not focusable; transport buttons own the D-pad. */
class ProgressLine(context: Context, private val ui: TvDesign) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var fraction = 0f

    init {
        minimumHeight = ui.dp(24f)
        isFocusable = false
    }

    fun setProgress(positionMs: Long, durationMs: Long) {
        val next = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
        if (next != fraction) { fraction = next; invalidate() }
    }

    override fun onDraw(canvas: Canvas) {
        val height = ui.dp(4f).toFloat()
        val thumb = ui.dp(4.5f).toFloat()
        val top = (this.height - height) / 2f
        val left = paddingLeft.toFloat()
        val right = width - paddingRight.toFloat()
        rect.set(left, top, right, top + height)
        paint.color = ui.track
        canvas.drawRoundRect(rect, height / 2f, height / 2f, paint)
        if (fraction > 0f) {
            rect.right = left + (right - left) * fraction
            paint.color = ui.accent
            canvas.drawRoundRect(rect, height / 2f, height / 2f, paint)
            val cx = left + (right - left) * fraction
            canvas.drawCircle(cx, this.height / 2f, thumb, paint)
        }
    }
}

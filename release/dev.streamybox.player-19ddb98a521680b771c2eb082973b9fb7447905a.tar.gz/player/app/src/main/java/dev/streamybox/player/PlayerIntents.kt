package dev.streamybox.player

import android.content.Intent

/** Maps an Android intent onto the pure parser without exposing android.* to unit tests. */
object PlayerIntents {
    fun values(intent: Intent): IntentValues {
        val extras = intent.extras
        val rawStart = extras?.get(PlayRequestParser.EXTRA_START_MS)
            ?: extras?.get(PLATFORM_START_POSITION)
        return IntentValues(
            action = intent.action,
            type = intent.type,
            data = intent.dataString,
            extraUrl = intent.getStringExtra(PlayRequestParser.EXTRA_URL),
            extraTitle = intent.getStringExtra(PlayRequestParser.EXTRA_TITLE) ?: intent.getStringExtra(EXTRA_TITLE),
            headerExtras = headers(intent),
            startPositionMs = (rawStart as? Number)?.toLong(),
            startPositionText = rawStart as? String,
            platformStartPositionMs = (extras?.get(PLATFORM_START_POSITION) as? Number)?.toLong(),
        )
    }

    fun toIntent(activity: android.app.Activity, request: PlayRequest, target: Class<*>): Intent =
        Intent(activity, target).apply {
            action = PlayRequestParser.ACTION_PLAY
            putExtra(PlayRequestParser.EXTRA_URL, request.url)
            putExtra(PlayRequestParser.EXTRA_TITLE, request.title)
            putExtra(PlayRequestParser.EXTRA_START_MS, request.startPositionMs)
            if (request.headers.isNotEmpty()) {
                putExtra(PlayRequestParser.EXTRA_HEADERS, request.headers.map { "${it.name}: ${it.value}" }.toTypedArray())
            }
            if (request.mimeType != null) type = request.mimeType
        }

    private fun headers(intent: Intent): List<String> {
        val array = runCatching { intent.getStringArrayExtra(PlayRequestParser.EXTRA_HEADERS) }.getOrNull()
        if (array != null) return array.toList()
        val list = runCatching { intent.getStringArrayListExtra(PlayRequestParser.EXTRA_HEADERS) }.getOrNull()
        if (list != null) return list
        return listOfNotNull(runCatching { intent.getStringExtra(PlayRequestParser.EXTRA_HEADERS) }.getOrNull())
    }

    private const val EXTRA_TITLE = "android.intent.extra.TITLE"
    private const val PLATFORM_START_POSITION = "android.intent.extra.START_POSITION"
}

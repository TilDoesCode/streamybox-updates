package dev.streamybox.player.render

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.util.Log
import android.view.Surface

/**
 * Queues one black SDR frame into a client Surface after mpv left it. The client's SurfaceView keeps showing
 * the last latched buffer; with mpv's BT2020_PQ dataspace that keeps the HWC in HDR under the client's SDR UI.
 * EGL sets the buffer dataspace on every window surface (UNKNOWN without a colorspace attribute) and
 * eglDestroySurface disconnects again, so mpv can attach the same Surface later. Main thread only.
 */
object SdrBlank {
    private const val TAG = "SbRenderService"

    fun blank(surface: Surface): Boolean {
        if (!surface.isValid) return false
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (display == EGL14.EGL_NO_DISPLAY) return false
        val version = IntArray(2)
        if (!EGL14.eglInitialize(display, version, 0, version, 1)) return false
        val config = config(display) ?: return false
        val context = EGL14.eglCreateContext(
            display, config, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0,
        )
        if (context == EGL14.EGL_NO_CONTEXT) return false
        val window = EGL14.eglCreateWindowSurface(display, config, surface, intArrayOf(EGL14.EGL_NONE), 0)
        if (window == EGL14.EGL_NO_SURFACE) {
            Log.w(TAG, "SDR blank: no window surface (0x${Integer.toHexString(EGL14.eglGetError())})")
            EGL14.eglDestroyContext(display, context)
            return false
        }
        return try {
            EGL14.eglMakeCurrent(display, window, window, context) &&
                run {
                    GLES20.glClearColor(0f, 0f, 0f, 1f)
                    GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                    EGL14.eglSwapBuffers(display, window)
                }
        } finally {
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(display, window)
            EGL14.eglDestroyContext(display, context)
            EGL14.eglReleaseThread()
        }
    }

    private fun config(display: android.opengl.EGLDisplay): EGLConfig? {
        val attributes = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            EGL14.EGL_NONE,
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val count = IntArray(1)
        if (!EGL14.eglChooseConfig(display, attributes, 0, configs, 0, 1, count, 0) || count[0] < 1) return null
        return configs[0]
    }
}

package dev.streamybox.player.render

import dev.streamybox.player.EngineInfo
import dev.streamybox.player.HdrKind
import dev.streamybox.player.Phase
import dev.streamybox.player.PlaybackStatus
import dev.streamybox.player.Track
import dev.streamybox.player.TrackKind
import dev.streamybox.player.VideoStatus
import kotlin.math.round

/** JSON events of the render contract (`type` discriminator). */
object RenderEvents {
    fun state(state: String) = Json.write(mapOf("type" to "state", "state" to state))

    fun time(positionMs: Long, durationMs: Long, bufferedMs: Long?) =
        Json.write(mapOf("type" to "time", "positionMs" to positionMs, "durationMs" to durationMs, "bufferedMs" to bufferedMs))

    fun buffering(buffering: Boolean) = Json.write(mapOf("type" to "buffering", "buffering" to buffering))

    fun firstFrame() = Json.write(mapOf("type" to "firstFrame"))

    fun ended() = Json.write(mapOf("type" to "ended"))

    fun error(reason: String, fatal: Boolean, status: Int? = null, message: String? = null) =
        Json.write(mapOf("type" to "error", "reason" to reason, "fatal" to fatal, "status" to status, "message" to message))

    fun stats(decoder: String?, droppedFrames: Long, totalFrames: Long?, hwdec: String) =
        Json.write(mapOf("type" to "stats", "decoder" to decoder, "droppedFrames" to droppedFrames, "totalFrames" to totalFrames, "hwdec" to hwdec))

    fun tracks(tracks: List<Track>, video: VideoStatus, output: HdrKind) = Json.write(
        mapOf(
            "type" to "tracks",
            "audio" to tracks.filter { it.kind == TrackKind.AUDIO }.mapNotNull { track(it, subtitle = false) },
            "subtitles" to tracks.filter { it.kind == TrackKind.SUBTITLE }.mapNotNull { track(it, subtitle = true) },
            "video" to video(video, output),
        )
    )

    private fun track(track: Track, subtitle: Boolean): Map<String, Any?>? {
        val id = track.id.toLongOrNull() ?: return null
        return mapOf(
            "id" to id,
            "label" to track.label,
            "language" to track.language,
            "codec" to track.codec,
            "channels" to if (subtitle) null else track.channels,
            "output" to if (subtitle) null else track.output,
            "selected" to track.selected,
            "forced" to if (subtitle) track.forced else null,
            "external" to if (subtitle) track.external else null,
        )
    }

    fun video(video: VideoStatus, output: HdrKind): Map<String, Any?>? {
        if ((video.width ?: 0) <= 0 && video.codec == null) return null
        return mapOf(
            "width" to video.width,
            "height" to video.height,
            "codec" to video.codec,
            "frameRate" to video.fps?.takeIf { it > 0 }?.let { round(it * 1000.0) / 1000.0 },
            "range" to range(video),
            "dolbyVisionProfile" to video.dvProfile?.takeIf { it > 0 },
            // Without a DOVI config record the profile number is unknown; the decoder still renders DV.
            "dolbyVision" to (video.hdr.kind == HdrKind.DV).takeIf { it },
            "output" to if (output == HdrKind.HDR10) "hdr10" else "sdr",
            "hwdec" to (video.hwdec?.takeIf { it.isNotBlank() } ?: "no"),
        )
    }

    /** Source transfer: DV P8.4 reports HLG, the other DV profiles and HDR10 are PQ. */
    fun range(video: VideoStatus): String {
        val gamma = video.gamma?.lowercase()
        return when {
            gamma == "hlg" -> "hlg"
            gamma == "pq" || gamma == "st2084" || gamma == "smpte2084" -> "pq"
            video.hdr.kind == HdrKind.DV -> "pq"
            else -> "sdr"
        }
    }

    fun stateOf(status: PlaybackStatus): String = when (status.phase) {
        Phase.IDLE -> "idle"
        Phase.LOADING -> "loading"
        Phase.ENDED -> "ended"
        Phase.ERROR -> "error"
        Phase.PLAYING -> when {
            status.paused -> "paused"
            status.buffering -> "buffering"
            else -> "playing"
        }
    }
}

/**
 * Turns engine callbacks into contract events: de-duplicated state/buffering/tracks, `time` at most
 * every [TIME_INTERVAL_MS] (≤ 4 Hz even with Binder jitter), `stats` every [STATS_INTERVAL_MS]. Pure.
 */
class RenderEventMapper(private val clock: () -> Long) {
    private var state: String? = null
    private var buffering: Boolean? = null
    private var lastTimeAt = Long.MIN_VALUE / 2
    private var lastTime: Pair<Long, Long>? = null
    private var lastTracks: String? = null
    private var lastStatsAt = Long.MIN_VALUE / 2
    private var lastHwdec: String? = null
    private var endedSent = false
    private var errorSent = false

    /** New load: forget everything except the time throttle, which spans loads. */
    fun reset() {
        state = null
        buffering = null
        lastTime = null
        lastTracks = null
        lastStatsAt = Long.MIN_VALUE / 2
        lastHwdec = null
        endedSent = false
        errorSent = false
    }

    /** Session start: the client already assumes idle, so no event. */
    fun markIdle() {
        state = "idle"
    }

    /** Forces a state (idle/loading after load/stop); returns the event when it changed. */
    fun forceState(next: String): String? {
        if (next != "error") errorSent = false
        if (state == next) return null
        state = next
        return RenderEvents.state(next)
    }

    fun status(status: PlaybackStatus, cacheSeconds: Double?): List<String> {
        if (errorSent) return emptyList()
        val events = ArrayList<String>(3)
        val next = RenderEvents.stateOf(status)
        // `error` only comes with its error event ([error]); `idle` only from stop/session start (forceState).
        if (next != state && next != "error" && next != "idle") {
            state = next
            events += RenderEvents.state(next)
        }
        if (status.phase == Phase.PLAYING || status.phase == Phase.LOADING) {
            val nowBuffering = status.buffering && status.phase == Phase.PLAYING
            if (buffering != nowBuffering) {
                buffering = nowBuffering
                events += RenderEvents.buffering(nowBuffering)
            }
        }
        if (status.phase == Phase.PLAYING) {
            val now = clock()
            val value = status.positionMs to status.durationMs
            if (value != lastTime && now - lastTimeAt >= TIME_INTERVAL_MS) {
                lastTime = value
                lastTimeAt = now
                val buffered = cacheSeconds?.takeIf { it >= 0 }?.let { status.positionMs + (it * 1000).toLong() }
                    ?.let { if (status.durationMs > 0) it.coerceAtMost(status.durationMs) else it }
                events += RenderEvents.time(status.positionMs, status.durationMs, buffered)
            }
        }
        if (status.phase == Phase.ENDED && !endedSent) {
            endedSent = true
            events += RenderEvents.ended()
        }
        return events
    }

    /** One error per load; later status updates no longer change the state. */
    fun error(reason: String, fatal: Boolean, status: Int?, message: String?): List<String> {
        if (errorSent && fatal) return emptyList()
        val events = mutableListOf(RenderEvents.error(reason, fatal, status, message))
        if (fatal) {
            errorSent = true
            if (state != "error") {
                state = "error"
                events += RenderEvents.state("error")
            }
        }
        return events
    }

    fun tracks(tracks: List<Track>, video: VideoStatus, output: HdrKind): String? {
        if (tracks.isEmpty() && RenderEvents.video(video, output) == null) return null
        val json = RenderEvents.tracks(tracks, video, output)
        if (json == lastTracks) return null
        lastTracks = json
        return json
    }

    fun stats(info: EngineInfo, video: VideoStatus, totalFrames: Long?, playing: Boolean): String? {
        val hwdec = info.hwdec ?: video.hwdec ?: return null
        val now = clock()
        val due = playing && now - lastStatsAt >= STATS_INTERVAL_MS
        if (!due && hwdec == lastHwdec) return null
        lastStatsAt = now
        lastHwdec = hwdec
        val codec = info.videoCodec ?: video.codec
        val decoder = codec?.let { if (hwdec == "no") "$it (software)" else "$it ($hwdec)" }
        return RenderEvents.stats(decoder, info.droppedFrames ?: 0L, totalFrames, hwdec)
    }

    companion object {
        const val TIME_INTERVAL_MS = 300L
        const val STATS_INTERVAL_MS = 2_000L
    }
}

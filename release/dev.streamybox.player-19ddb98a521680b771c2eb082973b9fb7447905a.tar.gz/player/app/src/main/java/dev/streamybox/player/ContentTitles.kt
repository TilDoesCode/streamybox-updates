package dev.streamybox.player

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns

/** Resolves the human title/MIME of a content:// URI; the path segment is often just a row id. */
object ContentTitles {
    fun resolve(context: Context, request: PlayRequest): PlayRequest {
        if (!PlayRequestParser.needsContentTitle(request.url, request.title)) return request
        val uri = runCatching { Uri.parse(request.url) }.getOrNull() ?: return request
        val name = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()
        val mime = request.mimeType ?: runCatching { context.contentResolver.getType(uri) }.getOrNull()
        return request.copy(
            title = name?.takeIf { it.isNotBlank() }?.let { PlayRequestParser.deriveTitle("file:///$it") } ?: request.title,
            mimeType = mime,
        )
    }
}

package dev.streamybox.player

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDescriptor
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.provider.Settings
import android.util.Log
import dev.streamybox.player.mpv.MPVLib

/** One IEC 61937 AudioTrack shape: mpv sends 2-channel frames, or 8-channel (7.1) frames for TrueHD/DTS-HD MA. */
data class IecShape(val rate: Int, val channels: Int)

/** What the HDMI sink reported in its EDID: encoding → max channels (Short Audio Descriptors). */
data class SinkFormats(val channels: Map<Int, Int>) {
    fun supports(encoding: Int) = encoding in channels
    val lpcmChannels: Int? get() = channels[PassthroughPolicy.ENCODING_PCM]
}

/** What the routed output accepts as bitstream; android.media values mirrored so the policy runs on the JVM. */
data class PassthroughSink(
    val spdifMuxer: Boolean,
    val digitalRoute: Boolean,
    val iec: Set<IecShape>,
    val directEncodings: Set<Int>,
    /** Null when no EDID source is available (the platform and the OS guard did not tell). */
    val reported: SinkFormats?,
)

/**
 * Picks mpv's `audio-spdif` codecs. AC-3/E-AC-3 need the HAL's IEC path (an unknown EDID still allows them, every
 * HDMI sink with surround takes AC-3); TrueHD, DTS and DTS-HD also need the sink to report them in its EDID.
 * Pure, unit tested.
 */
object PassthroughPolicy {
    const val ENCODING_PCM = 2
    const val ENCODING_AC3 = 5
    const val ENCODING_E_AC3 = 6
    const val ENCODING_DTS = 7
    const val ENCODING_DTS_HD = 8
    const val ENCODING_IEC61937 = 13
    const val ENCODING_DOLBY_TRUEHD = 14
    const val ENCODING_E_AC3_JOC = 18
    const val ENCODING_DOLBY_MAT = 19

    val IEC_48K = IecShape(48_000, 2)
    val IEC_192K = IecShape(192_000, 2)
    val IEC_HBR = IecShape(192_000, 8)
    val PROBED_SHAPES = listOf(IEC_48K, IEC_192K, IEC_HBR)

    private data class Codec(
        val names: List<String>,
        val sinkEncoding: Int,
        val directEncodings: Set<Int>,
        val shapes: Set<IecShape>,
        val needsReport: Boolean,
    )

    private val codecs = listOf(
        Codec(listOf("ac3"), ENCODING_AC3, setOf(ENCODING_AC3), setOf(IEC_48K), needsReport = false),
        Codec(listOf("eac3"), ENCODING_E_AC3, setOf(ENCODING_E_AC3, ENCODING_E_AC3_JOC), setOf(IEC_192K), needsReport = false),
        Codec(listOf("truehd"), ENCODING_DOLBY_TRUEHD, setOf(ENCODING_DOLBY_TRUEHD, ENCODING_DOLBY_MAT), setOf(IEC_HBR), needsReport = true),
        Codec(listOf("dts"), ENCODING_DTS, setOf(ENCODING_DTS), setOf(IEC_48K), needsReport = true),
        // "dts-hd" sends DTS-HD MA as 8-channel and HRA as stereo 192 kHz frames; the core alone stays "dts".
        Codec(listOf("dts-hd"), ENCODING_DTS_HD, setOf(ENCODING_DTS_HD), setOf(IEC_192K, IEC_HBR), needsReport = true),
    )

    /** CEA-861 Short Audio Descriptor → encoding: audio format code in bits 6..3 of byte 1, channels-1 in bits 2..0. */
    fun encodingOfSad(sad: ByteArray): Int? = when ((sad.firstOrNull()?.toInt() ?: 0) shr 3 and 0x0f) {
        1 -> ENCODING_PCM
        2 -> ENCODING_AC3
        7 -> ENCODING_DTS
        10 -> ENCODING_E_AC3
        11 -> ENCODING_DTS_HD
        12 -> ENCODING_DOLBY_TRUEHD
        else -> null
    }

    fun channelsOfSad(sad: ByteArray): Int = ((sad.firstOrNull()?.toInt() ?: 0) and 0x07) + 1

    /** SADs (3 bytes each) to [SinkFormats]; null for no valid descriptor. */
    fun sinkFormats(sads: List<ByteArray>): SinkFormats? {
        val channels = HashMap<Int, Int>()
        for (sad in sads) {
            if (sad.size != 3) continue
            val encoding = encodingOfSad(sad) ?: continue
            channels[encoding] = maxOf(channels[encoding] ?: 0, channelsOfSad(sad))
        }
        return if (sads.any { it.size == 3 }) SinkFormats(channels) else null
    }

    /** `streamybox_hdmi_audio_sads` (OS guard): comma-separated hex SADs, e.g. `095707,570603`; "" = EDID without audio. */
    fun parseSadSetting(value: String?): SinkFormats? {
        val text = value?.trim() ?: return null
        if (text.isEmpty()) return SinkFormats(emptyMap())
        val sads = text.split(',').map { it.trim() }
        if (sads.any { !it.matches(Regex("[0-9a-fA-F]{6}")) }) return null
        return sinkFormats(sads.map { hex -> ByteArray(3) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() } })
    }

    fun codecs(sink: PassthroughSink): List<String> {
        if (!sink.spdifMuxer || !sink.digitalRoute) return emptyList()
        return codecs.filter { codec ->
            codec.shapes.all { it in sink.iec } &&
                (sink.directEncodings.any { it in codec.directEncodings } || ENCODING_IEC61937 in sink.directEncodings) &&
                when (val reported = sink.reported) {
                    null -> !codec.needsReport
                    else -> reported.supports(codec.sinkEncoding)
                }
        }.flatMap { it.names }
            .let { names -> if ("dts-hd" in names && "dts" !in names) names + "dts" else names }
    }

    /** Bitstreams ignore volume and mute: muted, PCM-only setting or an earlier stall always mean PCM. */
    fun effective(mode: AudioPassthrough, broken: Boolean, muted: Boolean, probe: () -> List<String>): List<String> =
        if (mode != AudioPassthrough.AUTO || broken || muted) emptyList() else probe()

    /**
     * What one audio track reaches the sink as: `passthrough:<codec>` when its codec is in [spdif], else
     * `pcm:<channels>` capped at the sink's LPCM channels (the platform downmixes beyond that).
     */
    fun output(codec: String?, channels: Int?, spdif: List<String>, sinkLpcmChannels: Int?): String {
        val name = codec?.lowercase()
        if (name != null && (name in spdif || (name == "dts" && "dts-hd" in spdif))) return "passthrough:$name"
        val pcm = (channels ?: 2).let { count -> sinkLpcmChannels?.let { minOf(count, it) } ?: count }
        return "pcm:$pcm"
    }
}

/** Reads [PassthroughSink] for the output media is routed to right now. */
object PassthroughProbe {
    private const val TAG = "SbPlayerAudio"
    /** Written by the OS HDMI guard (root, reads the EDID that apps cannot); see device/rock4d/hdmi. */
    const val SETTING_SADS = "streamybox_hdmi_audio_sads"
    private val digitalTypes = setOf(
        AudioDeviceInfo.TYPE_HDMI, AudioDeviceInfo.TYPE_HDMI_ARC, AudioDeviceInfo.TYPE_HDMI_EARC,
        AudioDeviceInfo.TYPE_LINE_DIGITAL,
    )

    val spdifMuxer: Boolean by lazy { MPVLib.available && runCatching { MPVLib.spdifMuxerAvailable() }.getOrDefault(false) }

    /** Debug builds only (render option `debugSpdif`): forces audio-spdif to exercise fallback and mute on emulators. */
    @Volatile var debugSpdif: List<String>? = null

    /** Last probed sink; the engine reports `tracks[].output` from it. */
    @Volatile var lastSink: PassthroughSink? = null
        private set

    fun codecs(context: Context): List<String> {
        val sink = runCatching { sink(context) }.getOrElse {
            Log.w(TAG, "passthrough probe failed: ${it.message}")
            return emptyList()
        }
        lastSink = sink
        return PassthroughPolicy.codecs(sink).also { Log.i(TAG, "passthrough $it from $sink") }
    }

    private fun sink(context: Context): PassthroughSink {
        val manager = context.getSystemService(AudioManager::class.java)
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
            .build()
        val routed = manager.getAudioDevicesForAttributes(attributes)
        val sinks = routed.filter { it.type in digitalTypes }
        val iec = PassthroughPolicy.PROBED_SHAPES.filter { shape ->
            AudioTrack.isDirectPlaybackSupported(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_IEC61937)
                    .setSampleRate(shape.rate)
                    .setChannelMask(if (shape.channels == 8) AudioFormat.CHANNEL_OUT_7POINT1_SURROUND else AudioFormat.CHANNEL_OUT_STEREO)
                    .build(),
                attributes,
            )
        }.toSet()
        val direct = manager.getDirectProfilesForAttributes(attributes).map { it.format }.toSet()
        return PassthroughSink(spdifMuxer, sinks.isNotEmpty(), iec, direct, reported(context, sinks))
    }

    /**
     * EDID audio: platform descriptors, then the OS guard's setting. Bare device encodings are not trusted: on this
     * BSP they can mirror the HAL's static hdmi_bitstream profile (incl. DTS) instead of the sink.
     */
    private fun reported(context: Context, sinks: List<AudioDeviceInfo>): SinkFormats? {
        val sads = sinks.flatMap { device ->
            device.audioDescriptors.filter { it.standard == AudioDescriptor.STANDARD_EDID }.map { it.descriptor }
        }
        PassthroughPolicy.sinkFormats(sads)?.let { return it }
        val setting = runCatching { Settings.Global.getString(context.contentResolver, SETTING_SADS) }
            .onFailure { Log.w(TAG, "cannot read $SETTING_SADS: ${it.message}") }.getOrNull()
        return PassthroughPolicy.parseSadSetting(setting)
    }
}

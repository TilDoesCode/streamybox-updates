package dev.streamybox.player

/** Extracts the HTTP status from FFmpeg stream errors ("HTTP error 404 …", "Server returned 5XX …"). */
object HttpStatus {
    private val pattern = Regex("""(?:HTTP error|Server returned) ([1-5])(\d\d|XX)\b""", RegexOption.IGNORE_CASE)

    fun parse(text: String): Int? {
        val match = pattern.find(text) ?: return null
        val rest = match.groupValues[2].toIntOrNull() ?: 0
        return match.groupValues[1].toInt() * 100 + rest
    }
}

package dev.streamybox.player

/** Media clock formatting shared by the player chrome, resume prompt and history. */
object TimeFormat {
    /** [ms] as `m:ss`, or `h:mm:ss` once the value reaches an hour. Negative values clamp to zero. */
    fun clock(ms: Long): String {
        val total = (ms.coerceAtLeast(0) / 1000L)
        val seconds = total % 60
        val minutes = (total / 60) % 60
        val hours = total / 3600
        return if (hours > 0) "$hours:${two(minutes)}:${two(seconds)}" else "$minutes:${two(seconds)}"
    }

    /** Same as [clock] but always includes hours, for stable progress labels. */
    fun clockLong(ms: Long): String {
        val total = (ms.coerceAtLeast(0) / 1000L)
        return "${total / 3600}:${two((total / 60) % 60)}:${two(total % 60)}"
    }

    /** Remaining time as `-m:ss`; a finished or overrun stream shows `-0:00`. */
    fun remaining(positionMs: Long, durationMs: Long): String = "-" + clock(durationMs - positionMs)

    /** Compact duration for history rows, e.g. `1:23:45` or `12:34`. */
    fun duration(ms: Long): String = clock(ms)

    private fun two(value: Long): String = value.toString().padStart(2, '0')
}

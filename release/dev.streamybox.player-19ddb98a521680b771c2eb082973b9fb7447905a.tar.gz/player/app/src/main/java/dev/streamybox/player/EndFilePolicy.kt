package dev.streamybox.player

/** mpv end-file reasons and what the player should show. Pure, unit tested. */
enum class EndAction { ENDED, ERROR, IGNORE }

object EndFilePolicy {
    const val EOF = 0
    const val STOP = 2
    const val QUIT = 3
    const val ERROR = 4
    const val REDIRECT = 5

    fun action(reason: Int): EndAction = when (reason) {
        EOF -> EndAction.ENDED
        STOP, QUIT, REDIRECT -> EndAction.IGNORE
        else -> EndAction.ERROR
    }

    /** Fallback for a JNI bridge that only forwards eof-reached. */
    fun actionForLegacyEof(eof: Boolean): EndAction = if (eof) EndAction.ENDED else EndAction.ERROR
}

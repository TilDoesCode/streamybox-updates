package dev.streamybox.player

/**
 * Decides when the first picture of a load is visible: after the paused profile decision, after the
 * start-position seek has restarted playback, and only while a surface is attached. Pure, unit tested.
 */
class FirstFrameGate {
    private var armed = false
    private var fired = false
    private var finalized = false
    private var awaitingSeek = false
    private var restarted = false

    /** A new load: everything before this is ignored. */
    fun arm() {
        armed = true
        fired = false
        reload()
    }

    /** Same load reopened (hwdec switch); keeps an already reported first frame. */
    fun reload() {
        finalized = false
        awaitingSeek = false
        restarted = false
    }

    fun seekIssued() {
        awaitingSeek = true
        restarted = false
    }

    fun finalized(surface: Boolean): Boolean {
        finalized = true
        return check(surface)
    }

    fun playbackRestart(surface: Boolean): Boolean {
        if (!armed) return false
        awaitingSeek = false
        restarted = true
        return check(surface)
    }

    fun surfaceAttached(): Boolean = check(true)

    private fun check(surface: Boolean): Boolean {
        if (!armed || fired || !finalized || awaitingSeek || !restarted || !surface) return false
        fired = true
        return true
    }
}

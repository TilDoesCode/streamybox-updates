package dev.streamybox.player.render

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Surface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Bound service `dev.streamybox.player.RENDER`: renders mpv into a Surface the client owns (Streamarr's
 * SurfaceView) while the client keeps its own overlay. Contract: player/README.md "Embedded renderer".
 */
class RenderService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val sessions = RenderSessions()
    private lateinit var controller: RenderController

    private val binder = object : IRenderService.Stub() {
        override fun apiVersion(): Int = API_VERSION

        override fun attach(callback: IRenderCallback?): Int {
            val client = callback ?: return 0
            val attached = sessions.attach(Binder.getCallingUid())
            Log.i(TAG, "attach uid=${Binder.getCallingUid()} session=${attached.id} replaced=${attached.replaced}")
            onMain { controller.attach(attached.id, client) }
            return attached.id
        }

        override fun setSurface(session: Int, surface: Surface?, width: Int, height: Int) {
            if (!valid(session)) { surface?.release(); return }
            onMain { controller.setSurface(session, surface, width, height) }
        }

        // Waits briefly so mpv has left the surface before the client's surfaceDestroyed() returns.
        override fun clearSurface(session: Int) {
            if (valid(session)) onMainAndWait { controller.clearSurface(session) }
        }

        override fun load(session: Int, url: String?, optionsJson: String?) {
            if (valid(session)) onMain { controller.load(session, url, optionsJson) }
        }

        override fun play(session: Int) { if (valid(session)) onMain { controller.play(session) } }

        override fun pause(session: Int) { if (valid(session)) onMain { controller.pause(session) } }

        override fun seek(session: Int, positionMs: Long) { if (valid(session)) onMain { controller.seek(session, positionMs) } }

        override fun setAudioTrack(session: Int, id: Int) { if (valid(session)) onMain { controller.setAudioTrack(session, id) } }

        override fun setSubtitleTrack(session: Int, id: Int) { if (valid(session)) onMain { controller.setSubtitleTrack(session, id) } }

        override fun setMuted(session: Int, muted: Boolean) { if (valid(session)) onMain { controller.setMuted(session, muted) } }

        override fun stop(session: Int) { if (valid(session)) onMain { controller.stop(session) } }

        override fun detach(session: Int) { if (valid(session)) onMain { controller.detach(session) } }
    }

    override fun onCreate() {
        super.onCreate()
        controller = RenderController(this, sessions)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onUnbind(intent: Intent?): Boolean {
        onMain { controller.shutdown() }
        return false
    }

    override fun onDestroy() {
        controller.shutdown()
        super.onDestroy()
    }

    private fun valid(session: Int) = sessions.isCurrent(session, Binder.getCallingUid())

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    private fun onMainAndWait(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) { block(); return }
        val done = CountDownLatch(1)
        main.post { try { block() } finally { done.countDown() } }
        if (!done.await(CLEAR_WAIT_MS, TimeUnit.MILLISECONDS)) Log.w(TAG, "clearSurface: main thread busy, returned early")
    }

    companion object {
        const val ACTION_RENDER = "dev.streamybox.player.RENDER"
        const val API_VERSION = 1
        private const val TAG = "SbRenderService"
        private const val CLEAR_WAIT_MS = 1_000L
    }
}

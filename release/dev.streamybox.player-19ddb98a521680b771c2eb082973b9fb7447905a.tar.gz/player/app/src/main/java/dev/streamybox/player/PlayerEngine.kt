package dev.streamybox.player

import android.view.View

enum class TrackKind { AUDIO, SUBTITLE }

data class Track(
    val id: String,
    val kind: TrackKind,
    val label: String,
    val selected: Boolean,
    val forced: Boolean = false,
    val external: Boolean = false,
    val language: String? = null,
    val codec: String? = null,
    val channels: Int? = null,
    /** Audio only: `passthrough:<codec>` or `pcm:<channels>` as it reaches the sink. */
    val output: String? = null,
)

enum class Phase { IDLE, LOADING, PLAYING, ENDED, ERROR }

data class PlaybackStatus(
    val phase: Phase = Phase.IDLE,
    val paused: Boolean = false,
    val buffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val error: String? = null,
    val httpStatus: Int? = null,
)

data class EngineInfo(
    val version: String? = null,
    val videoCodec: String? = null,
    val audioCodec: String? = null,
    val audioChannels: String? = null,
    val hwdec: String? = null,
    val droppedFrames: Long? = null,
    val cacheSeconds: Double? = null,
)

/**
 * The player surface contract. [MpvEngine] is the real libmpv implementation;
 * [MissingEngine] is the honest fallback when this APK has no libmpv (no fake playback).
 */
interface PlayerEngine {
    val available: Boolean
    val surface: View?
    fun setListener(listener: Listener)
    fun prepare(request: PlayRequest)
    fun play()
    fun pause()
    fun togglePause()
    fun seekBy(deltaMs: Long)
    fun seekTo(positionMs: Long)
    fun selectAudio(id: String)
    fun selectSubtitle(id: String)
    fun release()

    interface Listener {
        fun onStatus(status: PlaybackStatus)
        fun onVideo(status: VideoStatus)
        fun onTracks(tracks: List<Track>)
        fun onInfo(info: EngineInfo)
        fun onFileLoaded()
        fun onEnded()
        fun onError(detail: String?)
        /** First picture of a load is on the surface (at/after the start position). */
        fun onFirstFrame() = Unit
    }
}

package dev.streamybox.player

/** Pure mapping from the user settings to libmpv options; verified by unit tests. */
object MpvOptions {
    /** [spdifCodecs]: what the routed output accepts as bitstream ([PassthroughProbe]); empty = PCM. */
    fun build(
        config: PlayerConfig,
        hdr10Rgb: Boolean = false,
        rgb10a2: Boolean = true,
        spdifCodecs: List<String> = emptyList(),
    ): Map<String, String> {
        val options = linkedMapOf(
            "vo" to "gpu-next",
            "gpu-api" to "opengl",
            "gpu-context" to "android",
            "opengl-es" to "yes",
            "egl-output-format" to "rgb10_a2",
            "hwdec" to when (config.hwdecode) {
                HwDecode.MEDIACODEC -> "mediacodec"
                HwDecode.COPY -> "mediacodec-copy"
                HwDecode.SOFTWARE -> "no"
            },
            "hwdec-codecs" to "h264,hevc,mpeg4,mpeg2video,vp8,vp9,av1",
            "tone-mapping" to "bt.2390",
            "hdr-compute-peak" to "yes",
            "target-colorspace-hint" to "yes",
            "android-hdr" to "no",
            "audio-client-name" to "Streamybox Player",
            "audio-set-media-role" to "yes",
            "user-agent" to "StreamyboxPlayer/0.1",
            "save-position-on-quit" to "no",
            "cache" to if (config.cache == NetworkCache.AUTO) "yes" else "no",
            "cache-secs" to "30",
            "demuxer-readahead-secs" to "20",
            "demuxer-max-bytes" to "192MiB",
            "demuxer-max-back-bytes" to "48MiB",
            "input-default-bindings" to "no",
            "input-vo-keyboard" to "no",
            "osc" to "no",
            "osd-level" to "0",
            "border" to "no",
            "keep-open" to "no",
            "idle" to "yes",
            "force-window" to "no",
            "config" to "no",
            "msg-level" to "all=warn,vd=info",
        )

        when (config.hdr) {
            HdrMode.AUTO -> {
                // Only the patched HWC (dev.streamybox.hdr10_rgb) accepts RGB HDR10.
                options["android-hdr"] = if (hdr10Rgb) "yes" else "no"
                options["target-colorspace-hint"] = "yes"
            }
            HdrMode.HDR10 -> {
                options["android-hdr"] = "yes"
                options["target-colorspace-hint"] = "yes"
            }
            HdrMode.SDR -> {
                options["android-hdr"] = "no"
                options["target-colorspace-hint"] = "yes"
            }
        }

        // Without a 10-bit EGL config mpv cannot create a GL context at all; 8-bit SDR still plays.
        if (!rgb10a2) {
            options.remove("egl-output-format")
            options["android-hdr"] = "no"
        }

        if (config.passthrough == AudioPassthrough.AUTO && spdifCodecs.isNotEmpty()) {
            options["audio-spdif"] = spdifCodecs.joinToString(",")
        }
        if (config.audioLanguage.isNotBlank()) options["alang"] = config.audioLanguage
        if (config.subtitleLanguage.isNotBlank()) options["slang"] = config.subtitleLanguage

        when (config.subtitleMode) {
            SubtitleMode.AUTO -> {
                options["sub-auto"] = "fuzzy"
                options["sub-visibility"] = "yes"
            }
            SubtitleMode.FORCED -> {
                options["sub-auto"] = "fuzzy"
                options["sub-visibility"] = "yes"
            }
            SubtitleMode.OFF -> {
                options["sub-auto"] = "no"
                options["sid"] = "no"
            }
        }
        return options
    }
}

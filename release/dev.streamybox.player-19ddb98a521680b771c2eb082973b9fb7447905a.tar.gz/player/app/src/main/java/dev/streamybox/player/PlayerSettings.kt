package dev.streamybox.player

import android.content.Context

enum class HdrMode { AUTO, HDR10, SDR }
enum class HwDecode { MEDIACODEC, COPY, SOFTWARE }
enum class AudioPassthrough { AUTO, PCM }
enum class NetworkCache { AUTO, OFF }
enum class SubtitleMode { AUTO, FORCED, OFF }

/** User facing defaults, stored per box in SharedPreferences. */
data class PlayerConfig(
    val hdr: HdrMode = HdrMode.AUTO,
    val hwdecode: HwDecode = HwDecode.MEDIACODEC,
    val passthrough: AudioPassthrough = AudioPassthrough.AUTO,
    val cache: NetworkCache = NetworkCache.AUTO,
    val rememberPosition: Boolean = true,
    val audioLanguage: String = "",
    val subtitleLanguage: String = "",
    val subtitleMode: SubtitleMode = SubtitleMode.AUTO,
)

class PlayerSettings(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("player", Context.MODE_PRIVATE)

    var config: PlayerConfig
        get() = PlayerConfig(
            hdr = enum(prefs.getString(KEY_HDR, null), HdrMode.AUTO),
            hwdecode = enum(prefs.getString(KEY_HWDEC, null), HwDecode.MEDIACODEC),
            passthrough = enum(prefs.getString(KEY_PASSTHROUGH, null), AudioPassthrough.AUTO),
            cache = enum(prefs.getString(KEY_CACHE, null), NetworkCache.AUTO),
            rememberPosition = prefs.getBoolean(KEY_REMEMBER, true),
            audioLanguage = prefs.getString(KEY_AUDIO_LANGUAGE, "").orEmpty(),
            subtitleLanguage = prefs.getString(KEY_SUBTITLE_LANGUAGE, "").orEmpty(),
            subtitleMode = enum(prefs.getString(KEY_SUBTITLE_MODE, null), SubtitleMode.AUTO),
        )
        set(value) {
            prefs.edit()
                .putString(KEY_HDR, value.hdr.name)
                .putString(KEY_HWDEC, value.hwdecode.name)
                .putString(KEY_PASSTHROUGH, value.passthrough.name)
                .putString(KEY_CACHE, value.cache.name)
                .putBoolean(KEY_REMEMBER, value.rememberPosition)
                .putString(KEY_AUDIO_LANGUAGE, value.audioLanguage)
                .putString(KEY_SUBTITLE_LANGUAGE, value.subtitleLanguage)
                .putString(KEY_SUBTITLE_MODE, value.subtitleMode.name)
                .apply()
        }

    fun change(block: (PlayerConfig) -> PlayerConfig): PlayerConfig = block(config).also { config = it }

    private inline fun <reified T : Enum<T>> enum(value: String?, fallback: T): T =
        value?.let { runCatching { enumValueOf<T>(it) }.getOrNull() } ?: fallback

    private companion object {
        const val KEY_HDR = "hdr"
        const val KEY_HWDEC = "hwdec"
        const val KEY_PASSTHROUGH = "passthrough"
        const val KEY_CACHE = "cache"
        const val KEY_REMEMBER = "remember_position"
        const val KEY_AUDIO_LANGUAGE = "audio_language"
        const val KEY_SUBTITLE_LANGUAGE = "subtitle_language"
        const val KEY_SUBTITLE_MODE = "subtitle_mode"
    }
}

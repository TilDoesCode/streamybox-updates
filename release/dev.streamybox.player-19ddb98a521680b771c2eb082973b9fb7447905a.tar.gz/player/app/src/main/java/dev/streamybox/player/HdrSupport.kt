package dev.streamybox.player

import android.content.Context

/**
 * System features that describe the box's display pipeline. They are declared by
 * Streamybox OS in `dev.streamybox.tv.xml`; a missing feature means an older image.
 */
object HdrSupport {
    const val FEATURE_HDR10_RGB = "dev.streamybox.hdr10_rgb"
    const val FEATURE_DOLBY_VISION = "dev.streamybox.dolby_vision"

    fun rgbHdr10(context: Context): Boolean =
        context.packageManager.hasSystemFeature(FEATURE_HDR10_RGB, 1)

    fun dolbyVision(context: Context): Boolean =
        context.packageManager.hasSystemFeature(FEATURE_DOLBY_VISION, 1)

    fun outputKind(context: Context, mode: HdrMode): HdrKind =
        if (EglSupport.rgb10a2) outputKind(rgbHdr10(context), mode) else HdrKind.SDR

    /** Pure form for tests: what the VO requests for an HDR/DV source. */
    fun outputKind(hdr10Rgb: Boolean, mode: HdrMode): HdrKind = when (mode) {
        HdrMode.HDR10 -> HdrKind.HDR10
        HdrMode.SDR -> HdrKind.SDR
        HdrMode.AUTO -> if (hdr10Rgb) HdrKind.HDR10 else HdrKind.SDR
    }
}

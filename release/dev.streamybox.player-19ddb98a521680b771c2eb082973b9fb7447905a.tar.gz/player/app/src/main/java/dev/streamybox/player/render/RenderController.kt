package dev.streamybox.player.render

import android.content.Context
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import dev.streamybox.player.BuildConfig
import dev.streamybox.player.EngineInfo
import dev.streamybox.player.HdrKind
import dev.streamybox.player.HdrSupport
import dev.streamybox.player.MpvEngine
import dev.streamybox.player.MpvOwner
import dev.streamybox.player.PassthroughProbe
import dev.streamybox.player.Phase
import dev.streamybox.player.PlaybackStatus
import dev.streamybox.player.PlayerEngine
import dev.streamybox.player.PlayerSettings
import dev.streamybox.player.Track
import dev.streamybox.player.VideoStatus
import dev.streamybox.player.mpv.MPVLib

/**
 * The embedded session on the main thread: one client callback, an optional client Surface and a
 * headless [MpvEngine]. The service validates session ids before posting here.
 */
class RenderController(private val context: Context, private val sessions: RenderSessions) : PlayerEngine.Listener {
    private val handler = Handler(Looper.getMainLooper())
    private val settings = PlayerSettings(context)
    private val mapper = RenderEventMapper { SystemClock.elapsedRealtime() }
    private val privateDirs = listOfNotNull(
        context.applicationInfo.dataDir,
        context.dataDir.absolutePath,
        context.filesDir.parentFile?.absolutePath,
        runCatching { context.createDeviceProtectedStorageContext().dataDir.absolutePath }.getOrNull(),
    ).flatMap { listOf(it, runCatching { java.io.File(it).canonicalPath }.getOrDefault(it)) }.distinct()

    private var session = 0
    private var callback: IRenderCallback? = null
    private var death: IBinder.DeathRecipient? = null
    private var engine: MpvEngine? = null
    private var surface: Surface? = null
    private var surfaceWidth = 0
    private var surfaceHeight = 0
    // mpv drew into the current surface since the last SDR blank.
    private var dirty = false
    private var loadSerial = 0
    private var muted = false
    private var output = HdrKind.SDR
    private var latestStatus = PlaybackStatus()
    private var latestVideo = VideoStatus()
    private var latestTracks: List<Track> = emptyList()
    private var latestInfo = EngineInfo()

    // PlayerActivity started playing: mpv is per process, so this session gives it up.
    private val holder = MpvOwner.Holder {
        Log.i(TAG, "session $session: PlayerActivity took over mpv")
        releaseEngine()
        blankSurface()
        sendAll(mapper.error("preempted", fatal = true, status = null, message = "PlayerActivity started playback"))
    }

    // mpv reports track properties one by one while loading; send one settled `tracks` event.
    private val tracksTick = Runnable {
        if (engine != null) mapper.tracks(latestTracks, latestVideo, output)?.let(::send)
    }

    private val statsTick = object : Runnable {
        override fun run() {
            val current = engine ?: return
            mapper.stats(latestInfo, latestVideo, current.frameNumber(), playing = isPlaying())?.let(::send)
            handler.postDelayed(this, RenderEventMapper.STATS_INTERVAL_MS)
        }
    }

    fun attach(id: Int, client: IRenderCallback) {
        // A newer attach already won on the binder thread; this one is stale.
        if (!sessions.isCurrent(id)) {
            runCatching { client.onEvent(RenderEvents.error("replaced", fatal = true)) }
            return
        }
        if (session != 0 && session != id) {
            Log.i(TAG, "session $session replaced by $id")
            val old = callback
            teardown(blank = true)
            runCatching { old?.onEvent(RenderEvents.error("replaced", fatal = true)) }
        }
        session = id
        callback = client
        val recipient = IBinder.DeathRecipient { handler.post { clientDied(id) } }
        if (runCatching { client.asBinder().linkToDeath(recipient, 0) }.isFailure) {
            clientDied(id)
            return
        }
        death = recipient
        // A fresh session is idle by contract; the first state event is `loading`.
        mapper.reset()
        mapper.markIdle()
    }

    fun setSurface(id: Int, next: Surface?, width: Int, height: Int) {
        if (!current(id)) { next?.release(); return }
        if (next == null || !next.isValid) { next?.release(); clearSurface(id); return }
        val old = surface
        surface = next
        surfaceWidth = width.coerceIn(0, MAX_SIZE)
        surfaceHeight = height.coerceIn(0, MAX_SIZE)
        dirty = false
        engine?.let {
            if (old != null) it.detachSurface()
            attachTo(it)
        }
        old?.release()
    }

    fun clearSurface(id: Int) {
        if (!current(id)) return
        engine?.let {
            it.pause()
            it.detachSurface()
        }
        surface?.release()
        surface = null
        dirty = false
    }

    fun load(id: Int, url: String?, optionsJson: String?) {
        if (!current(id)) return
        loadSerial++
        mapper.reset()
        val result = RenderOptions.request(url, optionsJson, privateDirs, muted)
        if (result is LoadResult.Invalid) {
            Log.w(TAG, "session $id: rejected load (${result.reason}: ${result.detail})")
            releaseEngine()
            blankSurface()
            sendAll(mapper.error(result.reason, fatal = true, status = null, message = result.detail))
            return
        }
        val request = (result as LoadResult.Ok).request
        muted = request.muted
        if (BuildConfig.DEBUG) PassthroughProbe.debugSpdif = RenderOptions.debugSpdif(optionsJson)
        if (!MPVLib.available) {
            sendAll(mapper.error("engine_unavailable", fatal = true, status = null, message = "libmpv is not packaged"))
            return
        }
        val current = engine ?: createEngine()
        latestStatus = PlaybackStatus()
        latestVideo = VideoStatus()
        latestTracks = emptyList()
        latestInfo = EngineInfo()
        mapper.forceState("loading")?.let(::send)
        current.prepare(request)
    }

    fun play(id: Int) { if (current(id)) engine?.play() }

    fun pause(id: Int) { if (current(id)) engine?.pause() }

    fun seek(id: Int, positionMs: Long) { if (current(id)) engine?.seekTo(positionMs.coerceAtLeast(0L)) }

    fun setAudioTrack(id: Int, track: Int) { if (current(id) && track >= 1) engine?.selectAudio(track.toString()) }

    fun setSubtitleTrack(id: Int, track: Int) {
        if (!current(id)) return
        when {
            track < 0 -> engine?.selectSubtitle("no")
            track >= 1 -> engine?.selectSubtitle(track.toString())
        }
    }

    fun setMuted(id: Int, value: Boolean) {
        if (!current(id)) return
        muted = value
        engine?.setMuted(value)
    }

    fun stop(id: Int) {
        if (!current(id)) return
        loadSerial++
        releaseEngine()
        blankSurface()
        mapper.reset()
        mapper.forceState("idle")?.let(::send)
    }

    fun detach(id: Int) {
        if (!current(id)) return
        teardown(blank = true)
        sessions.detach(id)
    }

    /** Service unbound or destroyed: nothing may keep mpv or the client's surface. */
    fun shutdown() {
        val id = session
        if (id != 0) Log.i(TAG, "session $id: service unbound, releasing")
        teardown(blank = true)
        if (id != 0) sessions.detach(id)
    }

    private fun clientDied(id: Int) {
        if (session != id) return
        Log.i(TAG, "session $id: client died")
        // The client's process owned the layer; SurfaceFlinger already dropped it.
        teardown(blank = false)
        sessions.detach(id)
    }

    private fun teardown(blank: Boolean) {
        releaseEngine()
        if (blank) blankSurface()
        surface?.release()
        surface = null
        dirty = false
        death?.let { recipient -> runCatching { callback?.asBinder()?.unlinkToDeath(recipient, 0) } }
        death = null
        callback = null
        session = 0
    }

    private fun createEngine(): MpvEngine {
        MpvOwner.acquire(holder)
        val config = settings.config
        output = HdrSupport.outputKind(context, config.hdr)
        val created = MpvEngine(context, config, embedded = true)
        created.setListener(this)
        attachTo(created)
        engine = created
        handler.removeCallbacks(statsTick)
        handler.postDelayed(statsTick, RenderEventMapper.STATS_INTERVAL_MS)
        return created
    }

    private fun releaseEngine() {
        handler.removeCallbacks(statsTick)
        handler.removeCallbacks(tracksTick)
        val current = engine ?: return
        engine = null
        current.release()
        MpvOwner.release(holder)
        Log.i(TAG, "session $session: engine released")
    }

    private fun attachTo(target: MpvEngine) {
        val next = surface ?: return
        target.attachSurface(next, surfaceWidth, surfaceHeight)
        dirty = true
    }

    /** After mpv released the surface: replace its last PQ frame with SDR black so the box leaves HDR. */
    private fun blankSurface() {
        val target = surface ?: return
        if (!dirty || engine != null) return
        dirty = false
        val ok = runCatching { SdrBlank.blank(target) }.getOrDefault(false)
        Log.i(TAG, "session $session: SDR blank ${if (ok) "queued" else "failed"}")
    }

    /** Playback is over (ended / fatal error): free mpv and leave HDR, unless a new load already started. */
    private fun finishPlayback() {
        val serial = loadSerial
        handler.post {
            if (serial != loadSerial || engine == null) return@post
            releaseEngine()
            blankSurface()
        }
    }

    private fun scheduleTracks() {
        handler.removeCallbacks(tracksTick)
        handler.postDelayed(tracksTick, TRACKS_SETTLE_MS)
    }

    private fun current(id: Int) = id != 0 && id == session && sessions.isCurrent(id)

    private fun isPlaying() = latestStatus.phase == Phase.PLAYING && !latestStatus.paused

    private fun send(json: String) {
        val client = callback ?: return
        try {
            client.onEvent(json)
        } catch (failure: Exception) {
            Log.w(TAG, "callback failed: ${failure.message}")
        }
    }

    private fun sendAll(events: List<String>) = events.forEach(::send)

    // ---- PlayerEngine.Listener (main thread) ------------------------------------------------

    override fun onStatus(status: PlaybackStatus) {
        if (engine == null) return
        latestStatus = status
        sendAll(mapper.status(status, latestInfo.cacheSeconds))
    }

    override fun onVideo(status: VideoStatus) {
        if (engine == null) return
        latestVideo = status
        scheduleTracks()
    }

    override fun onTracks(tracks: List<Track>) {
        if (engine == null) return
        latestTracks = tracks
        scheduleTracks()
    }

    override fun onInfo(info: EngineInfo) {
        if (engine == null) return
        val hwdecChanged = info.hwdec != latestInfo.hwdec
        latestInfo = info
        if (hwdecChanged) mapper.stats(info, latestVideo, null, playing = false)?.let(::send)
    }

    override fun onFileLoaded() = Unit

    override fun onEnded() {
        if (engine != null) finishPlayback()
    }

    override fun onFirstFrame() {
        if (engine == null) return
        // The client sizes its surface from tracks.video; let it see the settled tracks first.
        handler.removeCallbacks(tracksTick)
        tracksTick.run()
        send(RenderEvents.firstFrame())
    }

    override fun onError(detail: String?) {
        if (engine == null) return
        // The status with the HTTP code is published right after this callback.
        val serial = loadSerial
        handler.post {
            if (engine == null || serial != loadSerial) return@post
            sendAll(mapper.error("load_failed", fatal = true, status = latestStatus.httpStatus, message = detail))
            finishPlayback()
        }
    }

    private companion object {
        const val TAG = "SbRenderService"
        const val MAX_SIZE = 8192
        const val TRACKS_SETTLE_MS = 100L
    }
}

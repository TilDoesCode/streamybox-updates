package dev.streamybox.player

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import dev.streamybox.design.ControllerNavigation
import dev.streamybox.design.Glyph
import dev.streamybox.design.Motion
import dev.streamybox.design.SharedState
import dev.streamybox.design.TextField
import dev.streamybox.design.TvDesign
import dev.streamybox.player.mpv.MPVLib
import dev.streamybox.player.ui.PlayerIcon

/** Launcher entry: open a URL, resume history or reach the player settings. */
class MainActivity : Activity() {
    private lateinit var ui: TvDesign
    private lateinit var settings: PlayerSettings
    private lateinit var resumeStore: ResumeStore
    private lateinit var urlField: TextField
    private lateinit var recentList: LinearLayout
    private lateinit var rendererChip: TextView
    private lateinit var warning: LinearLayout
    private lateinit var warningTitle: TextView
    private lateinit var warningDetail: TextView
    private lateinit var playButton: TextView

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val shared = runCatching { SharedState.read(this) }.getOrDefault(Bundle())
        ui = TvDesign(this, shared.getBoolean("light", false))
        settings = PlayerSettings(this)
        resumeStore = ResumeStore(this)
        ControllerNavigation.install(window, menu = { openSettings() })
        build()
        refreshRecent()
        updateRenderer()
        immersive()
        rootPost()
    }

    private fun build() {
        val root = FrameLayout(this)
        root.setBackgroundDrawable(ui.backdrop())
        setContentView(root)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            isFocusable = false
            isFocusableInTouchMode = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            clipToPadding = false
        }
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(64f), ui.dp(44f), ui.dp(64f), ui.dp(36f))
            clipChildren = false
            clipToPadding = false
        }
        scroll.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        Motion.enter(content, dy = ui.dp(14f).toFloat())

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = ImageView(this).apply {
            setImageDrawable(Glyph(Glyph.Kind.BRAND, ui.accent))
            contentDescription = null
        }
        header.addView(brand, LinearLayout.LayoutParams(ui.dp(38f), ui.dp(38f)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(14f), 0, 0, 0)
        }
        titles.addView(ui.text(getString(R.string.app_name), 15f, ui.foreground, weight = 650))
        titles.addView(ui.text(getString(R.string.app_tagline), 12f, ui.muted, weight = 500).apply {
            setPadding(0, ui.dp(3f), 0, 0)
        })
        header.addView(titles)
        header.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        rendererChip = ui.chip("", ui.muted, ui.chip)
        header.addView(rendererChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        content.addView(ui.text(getString(R.string.open_title), TvDesign.TYPE_DISPLAY, ui.foreground, weight = 650).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, ui.dp(30f), 0, 0)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(ui.text(getString(R.string.open_subtitle), 15f, ui.muted, weight = 400).apply {
            maxLines = 2
            setLineSpacing(ui.dp(4f).toFloat(), 1f)
            setPadding(0, ui.dp(10f), 0, 0)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val columns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            isBaselineAligned = false
            clipChildren = false
            setPadding(0, ui.dp(26f), 0, 0)
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
        columns.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.08f))
        columns.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, .92f).apply { marginStart = ui.dp(34f) })

        val lastUrl = getSharedPreferences("open", MODE_PRIVATE).getString("last_url", "").orEmpty()
        urlField = TextField(ui, getString(R.string.open_url_label), getString(R.string.open_url_hint), value = lastUrl).apply {
            check = { raw -> PlayRequestParser.validateAddress(raw)?.let { requestErrorText(this@MainActivity, it) } }
            onSubmit = { play(it) }
            action(TextField.Action.GO, getString(R.string.open_play))
        }
        left.addView(urlField, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, ui.dp(14f), 0, 0)
        }
        playButton = ui.key(getString(R.string.open_play), 2) { play(urlField.text) }.apply {
            setPadding(ui.dp(30f), 0, ui.dp(30f), 0)
        }
        actions.addView(playButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui.dp(52f)))
        val settingsButton = ui.key(getString(R.string.open_settings), 1) { openSettings() }.apply {
            setPadding(ui.dp(24f), 0, ui.dp(24f), 0)
        }
        actions.addView(settingsButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui.dp(52f)).apply { marginStart = ui.dp(12f) })
        left.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        warning = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(18f), ui.dp(15f), ui.dp(18f), ui.dp(15f))
            background = ui.shape(ui.surface, TvDesign.RADIUS_M, ui.danger)
            visibility = View.GONE
        }
        val warningIcon = ImageView(this).apply { setImageDrawable(PlayerIcon(PlayerIcon.Kind.WARNING, ui.danger)) }
        warning.addView(warningIcon, LinearLayout.LayoutParams(ui.dp(26f), ui.dp(26f)).apply { marginEnd = ui.dp(14f) })
        val warningText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        warningTitle = ui.text(getString(R.string.open_engine_missing), 14f, ui.danger, weight = 600)
        warningDetail = ui.text(getString(R.string.open_engine_missing_detail), 12.5f, ui.muted).apply {
            setPadding(0, ui.dp(4f), 0, 0)
            setLineSpacing(ui.dp(3f).toFloat(), 1f)
        }
        warningText.addView(warningTitle)
        warningText.addView(warningDetail)
        warning.addView(warningText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        left.addView(warning, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ui.dp(16f) })

        right.addView(ui.header(getString(R.string.open_recent)))
        recentList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
        right.addView(recentList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(columns, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        content.addView(ui.text("${BuildConfig.VERSION_NAME}  ·  ${getString(R.string.open_footer)}", 12f, ui.faint).apply {
            setPadding(0, ui.dp(26f), 0, 0)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun rootPost() {
        playButton.post { playButton.requestFocus() }
    }

    private fun play(raw: String) {
        val error = PlayRequestParser.validateAddress(raw)
        if (error != null) {
            urlField.problem(requestErrorText(this, error))
            urlField.edit()
            return
        }
        val parsed = PlayRequestParser.parse(IntentValues(action = PlayRequestParser.ACTION_PLAY, extraUrl = raw))
        val request = when (parsed) {
            is ParseResult.Ok -> parsed.request
            is ParseResult.Invalid -> {
                urlField.problem(requestErrorText(this, parsed.error))
                return
            }
        }
        getSharedPreferences("open", MODE_PRIVATE).edit().putString("last_url", request.url).apply()
        startActivity(PlayerIntents.toIntent(this, request, PlayerActivity::class.java))
    }

    private fun openRecent(entry: ResumeEntry) {
        val request = entry.toRequest() ?: return
        startActivity(PlayerIntents.toIntent(this, request, PlayerActivity::class.java))
    }

    private fun refreshRecent() {
        recentList.removeAllViews()
        val entries = resumeStore.list().take(6)
        if (entries.isEmpty()) {
            recentList.addView(ui.text(getString(R.string.open_recent_empty), 13.5f, ui.muted).apply {
                setLineSpacing(ui.dp(4f).toFloat(), 1f)
                setPadding(ui.dp(4f), ui.dp(4f), 0, 0)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        entries.forEach { entry ->
            val detail = if (entry.durationMs > 0) {
                getString(R.string.open_recent_position, TimeFormat.clock(entry.positionMs), TimeFormat.clock(entry.durationMs))
            } else TimeFormat.clock(entry.positionMs)
            val row = ui.item(entry.title, detail, trail = TvDesign.Trail.CHEVRON) { openRecent(entry) }
            recentList.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        ui.group(recentList)
    }

    private fun updateRenderer() {
        val ready = MPVLib.available
        rendererChip.text = getString(if (ready) R.string.open_engine_ready else R.string.open_engine_missing)
        rendererChip.setTextColor(if (ready) ui.accent else ui.danger)
        rendererChip.background = ui.shape(ui.chip, TvDesign.PILL)
        warning.visibility = if (ready) View.GONE else View.VISIBLE
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    override fun onResume() {
        super.onResume()
        refreshRecent()
        updateRenderer()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        val decor = runCatching { window.decorView }.getOrNull() ?: return
        decor.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }
}

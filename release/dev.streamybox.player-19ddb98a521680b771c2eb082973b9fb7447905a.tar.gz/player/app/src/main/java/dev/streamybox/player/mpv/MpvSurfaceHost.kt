/*
 * Adapted from mpv-android (https://github.com/mpv-android/mpv-android), BaseMPVView.kt.
 * Copyright (c) 2016 Ilya Zhuravlev, sfan5 <sfan5@live.de>, MIT licensed.
 * Modifications for Streamybox: window-independent host for any Android Surface.
 *
 * This file is part of the Streamybox Player, licensed GPL-3.0-or-later.
 */
package dev.streamybox.player.mpv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface

/**
 * libmpv client plus one Android [Surface]. It owns no View or Window, so the PlayerActivity's
 * SurfaceView and the embedded render service (a client's Surface over Binder) share it.
 * Main thread only.
 */
class MpvSurfaceHost(private val context: Context) {
    private val handler = Handler(Looper.getMainLooper())
    private var initialized = false
    private var attached: Surface? = null
    private var pending: Load? = null
    private var generation = 0

    private data class Load(val url: String, val headers: String)

    val surfaceAttached: Boolean get() = attached != null

    fun initialize(options: Map<String, String>, configDir: String, cacheDir: String) {
        if (initialized) return
        MPVLib.create(context.applicationContext)
        MPVLib.setOptionString("config", "no")
        MPVLib.setOptionString("config-dir", configDir)
        MPVLib.setOptionString("gpu-shader-cache-dir", "$cacheDir/shaders")
        MPVLib.setOptionString("icc-cache-dir", "$cacheDir/icc")

        for ((name, value) in options) {
            val result = MPVLib.setOptionString(name, value)
            if (result < 0) Log.w(TAG, "mpv rejected option $name=$value ($result)")
        }
        MPVLib.init()

        // A missing surface must not make mpv exit; loadfile is queued until a surface is attached.
        MPVLib.setOptionString("force-window", "no")
        MPVLib.setOptionString("idle", "yes")
        initialized = true
    }

    /** Hands [surface] to mpv as its `wid`; the HDR dataspace is set by mpv on this window. */
    fun attach(surface: Surface, width: Int = 0, height: Int = 0) {
        if (!initialized) return
        if (attached != null) detach()
        Log.d(TAG, "attaching surface ${width}x$height")
        MPVLib.attachSurface(surface)
        attached = surface
        if (width > 0 && height > 0) MPVLib.setPropertyString("android-surface-size", "${width}x$height")
        MPVLib.setOptionString("force-window", "yes")
        MPVLib.setPropertyString("vo", "gpu-next")
        val token = ++generation
        // Let the first frame finish attaching the BufferQueue before loadfile.
        handler.post { if (initialized && token == generation && attached != null) startPending() }
    }

    fun resize(width: Int, height: Int) {
        if (initialized && attached != null && width > 0 && height > 0) {
            MPVLib.setPropertyString("android-surface-size", "${width}x$height")
        }
    }

    /** Releases the VO (EGL surface, ANativeWindow) before the JNI reference to the surface. */
    fun detach() {
        if (!initialized || attached == null) return
        Log.d(TAG, "detaching surface")
        generation++
        runCatching { MPVLib.setPropertyString("vo", "null") }
        runCatching { MPVLib.setPropertyString("force-window", "no") }
        attached = null
        runCatching { MPVLib.detachSurface() }
    }

    fun requestLoad(url: String, headers: String) {
        pending = Load(url, headers)
        if (attached != null) startPending()
    }

    fun destroy() {
        if (!initialized) return
        pending = null
        detach()
        initialized = false
        runCatching { MPVLib.destroy() }
    }

    private fun startPending() {
        if (attached == null) return
        val load = pending ?: return
        pending = null
        MPVLib.setPropertyString("http-header-fields", load.headers)
        Log.i(TAG, "loadfile with surface attached: ${load.url}")
        MPVLib.command(arrayOf("loadfile", load.url, "replace"))
    }

    private companion object { const val TAG = "SbPlayerMpv" }
}

package dev.streamybox.player

import android.view.View

/** Honest fallback: no surface, no fake frames. The activity shows the renderer error instead. */
class MissingEngine : PlayerEngine {
    override val available: Boolean = false
    override val surface: View? = null
    private var listener: PlayerEngine.Listener? = null

    override fun setListener(listener: PlayerEngine.Listener) { this.listener = listener }
    override fun prepare(request: PlayRequest) { listener?.onError(null) }
    override fun play() = Unit
    override fun pause() = Unit
    override fun togglePause() = Unit
    override fun seekBy(deltaMs: Long) = Unit
    override fun seekTo(positionMs: Long) = Unit
    override fun selectAudio(id: String) = Unit
    override fun selectSubtitle(id: String) = Unit
    override fun release() { listener = null }
}

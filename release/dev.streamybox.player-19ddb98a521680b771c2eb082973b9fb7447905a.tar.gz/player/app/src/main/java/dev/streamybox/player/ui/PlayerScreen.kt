package dev.streamybox.player.ui

import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import dev.streamybox.design.FocusStyle
import dev.streamybox.design.Motion
import dev.streamybox.design.TvDesign
import dev.streamybox.design.card
import dev.streamybox.player.HdrKind
import dev.streamybox.player.PlaybackStatus
import dev.streamybox.player.Phase
import dev.streamybox.player.R
import dev.streamybox.player.ResumeEntry
import dev.streamybox.player.TimeFormat
import dev.streamybox.player.Track
import dev.streamybox.player.TrackKind
import dev.streamybox.player.VideoStatus

/** Full player chrome: title and HDR badges, transport, progress, modals and track dialogs. */
class PlayerScreen(
    private val context: Context,
    private val ui: TvDesign,
    private val callbacks: Callbacks,
) {
    interface Callbacks {
        fun onPlayPause()
        fun onSeekBack()
        fun onSeekForward()
        fun onAudio()
        fun onSubtitles()
        fun onInfo()
        fun onSettings()
        fun onClose()
        fun onResume()
        fun onStartOver()
        fun onRetry()
        fun onReplay()
    }

    private enum class ModalKind { NONE, RESUME, ERROR, ENDED, TRACKS, INFO }

    val root = FrameLayout(context)
    private val handler = Handler(Looper.getMainLooper())
    private val surfaceHost = FrameLayout(context)
    private val chrome = FrameLayout(context)
    private val modalHost = FrameLayout(context)

    private lateinit var titleView: TextView
    private lateinit var sourceView: TextView
    private lateinit var badgeRow: LinearLayout
    private lateinit var progressLine: ProgressLine
    private lateinit var positionView: TextView
    private lateinit var durationView: TextView
    private lateinit var playIcon: ImageView
    private lateinit var playButton: FrameLayout
    private lateinit var loadingBox: LinearLayout
    private lateinit var loadingText: TextView
    private lateinit var bufferingBox: LinearLayout
    private lateinit var seekHud: TextView
    private lateinit var seekBack: FrameLayout
    private lateinit var seekForward: FrameLayout

    private var badgeSignature: List<String> = emptyList()
    private var controlsVisible = true
    private var paused = false
    private var phase = Phase.LOADING
    private var buffering = false
    private var modalKind = ModalKind.NONE
    private var infoDialog: Dialog? = null
    private var trackDialog: Dialog? = null
    private var currentPosition = 0L
    private var currentDuration = 0L

    private data class Badge(val text: String, val tint: Int, val fill: Int)

    private val autoHide = Runnable {
        if (controlsVisible && !paused && phase == Phase.PLAYING && !hasModal) setControlsVisible(false)
    }
    private val hideSeek = Runnable { seekHud.animate().alpha(0f).setDuration(Motion.EXIT).start() }

    private val hasModal: Boolean get() = modalKind != ModalKind.NONE
    val blockingModal: Boolean get() = modalKind == ModalKind.RESUME || modalKind == ModalKind.ERROR || modalKind == ModalKind.ENDED

    init {
        root.setBackgroundColor(Color.BLACK)
        root.clipChildren = false
        surfaceHost.setBackgroundColor(Color.BLACK)
        root.addView(surfaceHost, frame())

        chrome.visibility = View.VISIBLE
        root.addView(chrome, frame())
        buildTop()
        buildBottom()

        buildStatusOverlays()
        root.addView(modalHost, frame())
        modalHost.visibility = View.GONE
        modalHost.isClickable = true
        root.post { focusPlay() }
    }

    // ---- construction ---------------------------------------------------------------------

    private fun buildTop() {
        val topScrim = View(context).apply { background = gradient(GradientDrawable.Orientation.TOP_BOTTOM, Color.argb(225, 0, 0, 0), Color.TRANSPARENT) }
        chrome.addView(topScrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(230f), Gravity.TOP))

        val topBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(44f), ui.dp(28f), ui.dp(44f), 0)
        }
        val titles = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        titleView = ui.text("", 26f, ui.foreground, weight = 600).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        sourceView = ui.text("", 12.5f, ui.muted, weight = 500).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
            setPadding(0, ui.dp(5f), 0, 0)
        }
        titles.addView(titleView)
        titles.addView(sourceView)
        topBar.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        badgeRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topBar.addView(badgeRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = ui.dp(20f) })

        val close = iconButton(PlayerIcon.Kind.CLOSE, context.getString(R.string.controls_close), 46f) { callbacks.onClose() }
        topBar.addView(close, LinearLayout.LayoutParams(ui.dp(46f), ui.dp(46f)).apply { marginStart = ui.dp(20f) })
        chrome.addView(topBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
    }

    private fun buildBottom() {
        val bottomScrim = View(context).apply {
            background = gradient(GradientDrawable.Orientation.TOP_BOTTOM, Color.TRANSPARENT, Color.argb(235, 0, 0, 0))
        }
        chrome.addView(bottomScrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(320f), Gravity.BOTTOM))

        val bottom = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(44f), 0, ui.dp(44f), ui.dp(28f))
        }
        progressLine = ProgressLine(context, ui)
        bottom.addView(progressLine, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(24f)))

        val times = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        positionView = ui.text("0:00", 13f, ui.foreground, weight = 500).apply { fontFeatureSettings = "tnum" }
        durationView = ui.text("0:00", 13f, ui.muted, weight = 500).apply { fontFeatureSettings = "tnum" }
        times.addView(positionView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        times.addView(durationView)
        bottom.addView(times, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val actions = FrameLayout(context).apply { setPadding(0, ui.dp(8f), 0, 0) }
        val transport = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        seekBack = iconButton(PlayerIcon.Kind.REWIND, context.getString(R.string.controls_seek_back), 54f) { callbacks.onSeekBack() }
        playButton = iconButton(PlayerIcon.Kind.PLAY, context.getString(R.string.controls_play), 66f, primary = true) { callbacks.onPlayPause() }
        playIcon = playButton.getChildAt(0) as ImageView
        seekForward = iconButton(PlayerIcon.Kind.FORWARD, context.getString(R.string.controls_seek_forward), 54f) { callbacks.onSeekForward() }
        transport.addView(seekBack, LinearLayout.LayoutParams(ui.dp(54f), ui.dp(54f)))
        transport.addView(playButton, LinearLayout.LayoutParams(ui.dp(66f), ui.dp(66f)).apply { marginStart = ui.dp(18f); marginEnd = ui.dp(18f) })
        transport.addView(seekForward, LinearLayout.LayoutParams(ui.dp(54f), ui.dp(54f)))
        actions.addView(transport, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val pills = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        addPill(pills, PlayerIcon.Kind.AUDIO, context.getString(R.string.controls_audio), context.getString(R.string.controls_audio_short)) { callbacks.onAudio() }
        addPill(pills, PlayerIcon.Kind.SUBTITLES, context.getString(R.string.controls_subtitles), context.getString(R.string.controls_subtitles_short)) { callbacks.onSubtitles() }
        addPill(pills, PlayerIcon.Kind.INFO, context.getString(R.string.controls_info), context.getString(R.string.controls_info_short)) { callbacks.onInfo() }
        pills.addView(
            iconButton(PlayerIcon.Kind.GEAR, context.getString(R.string.controls_settings), 48f) { callbacks.onSettings() },
            LinearLayout.LayoutParams(ui.dp(48f), ui.dp(48f)).apply { marginStart = ui.dp(10f) },
        )
        actions.addView(pills, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL))

        bottom.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(74f)))
        chrome.addView(bottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        linkFocus()
    }

    private fun buildStatusOverlays() {
        loadingBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        val spinner = ProgressBar(context).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(ui.accent)
        }
        loadingText = ui.text(context.getString(R.string.player_loading), 16f, ui.foreground, weight = 500).apply {
            gravity = Gravity.CENTER
            setPadding(0, ui.dp(16f), 0, 0)
        }
        loadingBox.addView(spinner, LinearLayout.LayoutParams(ui.dp(44f), ui.dp(44f)))
        loadingBox.addView(loadingText)
        root.addView(loadingBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        bufferingBox = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(18f), ui.dp(9f), ui.dp(20f), ui.dp(9f))
            background = ui.shape(Color.argb(210, 16, 20, 28), TvDesign.PILL)
            visibility = View.GONE
        }
        bufferingBox.addView(ProgressBar(context).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(ui.accent)
        }, LinearLayout.LayoutParams(ui.dp(22f), ui.dp(22f)))
        bufferingBox.addView(ui.text(context.getString(R.string.player_buffering), 13f, ui.foreground, weight = 500).apply {
            setPadding(ui.dp(12f), 0, 0, 0)
        })
        root.addView(bufferingBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = ui.dp(170f)
        })

        seekHud = ui.text("", 14f, ui.foreground, weight = 600).apply {
            gravity = Gravity.CENTER
            setPadding(ui.dp(22f), ui.dp(10f), ui.dp(22f), ui.dp(10f))
            background = ui.shape(Color.argb(225, 26, 32, 48), TvDesign.PILL)
            alpha = 0f
        }
        root.addView(seekHud, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = ui.dp(120f)
        })
    }

    private fun linkFocus() {
        seekBack.id = View.generateViewId()
        playButton.id = View.generateViewId()
        seekForward.id = View.generateViewId()
        playButton.nextFocusLeftId = seekBack.id
        playButton.nextFocusRightId = seekForward.id
        seekBack.nextFocusRightId = playButton.id
        seekForward.nextFocusLeftId = playButton.id
    }

    // ---- public state ---------------------------------------------------------------------

    /** Clears stale badges/progress when a new intent arrives before playback starts. */
    fun resetPlayback() {
        badgeSignature = emptyList()
        badgeRow.removeAllViews()
        progressLine.setProgress(0L, 0L)
        positionView.text = TimeFormat.clock(0)
        durationView.text = TimeFormat.clock(0)
        bufferingBox.visibility = View.GONE
        loadingBox.visibility = View.GONE
        setPaused(true)
    }

    fun bindSurface(surface: View?) {
        surfaceHost.removeAllViews()
        if (surface != null) surfaceHost.addView(surface, frame())
    }

    fun setTitle(title: String, source: String) {
        titleView.text = title
        sourceView.text = source
    }

    fun setVideo(status: VideoStatus) {
        val hdr = status.hdr
        val badges = ArrayList<Badge>()
        when (hdr.kind) {
            HdrKind.DV -> badges += Badge(
                context.getString(R.string.badge_dv, hdr.dvLabel ?: context.getString(R.string.badge_dv_generic)),
                ui.onAccent,
                ui.accent,
            )
            HdrKind.HDR10 -> badges += Badge(context.getString(R.string.badge_hdr10), ui.foreground, ui.chip)
            HdrKind.HLG -> badges += Badge(context.getString(R.string.badge_hlg), ui.foreground, ui.chip)
            HdrKind.SDR -> badges += Badge(context.getString(R.string.badge_sdr), ui.muted, ui.chip)
            HdrKind.UNKNOWN -> Unit
        }
        if (hdr.kind == HdrKind.DV || hdr.kind == HdrKind.HDR10 || hdr.kind == HdrKind.HLG) {
            val out = status.outputOverride ?: status.outputHdr.kind
            badges += when (out) {
                HdrKind.HDR10 -> Badge(context.getString(R.string.badge_hdr10_out), ui.muted, ui.chip)
                HdrKind.HLG -> Badge(context.getString(R.string.badge_hlg_out), ui.muted, ui.chip)
                else -> Badge(context.getString(R.string.badge_sdr_out), ui.muted, ui.chip)
            }
        }
        status.resolution?.let { badges += Badge(it, ui.muted, ui.chip) }
        status.fpsText?.let { badges += Badge(context.getString(R.string.info_fps_value, it), ui.muted, ui.chip) }
        if (!status.hwdec.isNullOrBlank() && status.hwdec != "no") badges += Badge(context.getString(R.string.badge_hwdec), ui.muted, ui.chip)

        val signature = badges.map { it.text }
        if (signature == badgeSignature) return
        badgeSignature = signature
        badgeRow.removeAllViews()
        badges.forEach { badge ->
            badgeRow.addView(ui.chip(badge.text, badge.tint, badge.fill), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = ui.dp(6f) })
        }
    }

    fun setStatus(status: PlaybackStatus) {
        phase = status.phase
        paused = status.paused || status.phase == Phase.ENDED
        buffering = status.buffering
        setProgress(status.positionMs, status.durationMs)
        setPaused(paused)
        bufferingBox.visibility = if (buffering && status.phase == Phase.PLAYING) View.VISIBLE else View.GONE
        when (status.phase) {
            Phase.LOADING -> setLoading(true)
            Phase.PLAYING, Phase.ENDED -> setLoading(false)
            Phase.ERROR -> setLoading(false)
            Phase.IDLE -> Unit
        }
        kick()
    }

    fun setProgress(positionMs: Long, durationMs: Long) {
        // At EOF mpv drops time-pos/duration; keep the last known values for the ended card.
        val shownDuration = if (durationMs > 0) durationMs else currentDuration
        val shownPosition = if (phase == Phase.ENDED && positionMs == 0L && currentPosition > 0L) currentPosition else positionMs
        currentPosition = shownPosition
        currentDuration = shownDuration
        progressLine.setProgress(shownPosition, shownDuration)
        positionView.text = TimeFormat.clock(shownPosition)
        durationView.text = if (shownDuration > 0) TimeFormat.clock(shownDuration) else context.getString(R.string.player_live)
    }

    fun setPaused(paused: Boolean) {
        this.paused = paused
        playIcon.setImageDrawable(PlayerIcon(if (paused) PlayerIcon.Kind.PLAY else PlayerIcon.Kind.PAUSE, ui.onAccent))
        playButton.contentDescription = context.getString(if (paused) R.string.controls_play else R.string.controls_pause)
        if (paused) handler.removeCallbacks(autoHide) else kick()
    }

    fun setLoading(show: Boolean, text: String? = null) {
        loadingText.text = text ?: context.getString(R.string.player_loading)
        loadingBox.visibility = if (show) View.VISIBLE else View.GONE
    }

    fun flashSeek(deltaMs: Long, targetMs: Long) {
        val prefix = context.getString(if (deltaMs < 0) R.string.seek_hud_back else R.string.seek_hud_forward)
        seekHud.text = "$prefix   ${TimeFormat.clock(targetMs)}"
        handler.removeCallbacks(hideSeek)
        seekHud.animate().cancel()
        seekHud.visibility = View.VISIBLE
        seekHud.alpha = 1f
        seekHud.translationY = 0f
        handler.postDelayed(hideSeek, 1_000)
    }

    fun showResume(entry: ResumeEntry, title: String) {
        if (hasModal) return
        val remaining = (entry.durationMs - entry.positionMs).coerceAtLeast(0)
        showModal(
            ModalKind.RESUME,
            context.getString(R.string.player_resume_eyebrow),
            context.getString(R.string.player_resume_title, TimeFormat.clock(entry.positionMs)),
            "$title · ${context.getString(R.string.player_resume_detail, TimeFormat.clock(entry.positionMs), TimeFormat.clock(remaining))}",
            context.getString(R.string.player_resume_continue),
            { callbacks.onResume() },
            context.getString(R.string.player_resume_start),
            { callbacks.onStartOver() },
        )
    }

    fun showError(title: String, detail: String, retryable: Boolean) {
        if (hasModal) return
        showModal(
            ModalKind.ERROR,
            null,
            title,
            detail,
            if (retryable) context.getString(R.string.player_retry) else null,
            { callbacks.onRetry() },
            context.getString(R.string.player_close),
            { callbacks.onClose() },
        )
    }

    fun showEnded(title: String) {
        if (hasModal) return
        showModal(
            ModalKind.ENDED,
            null,
            context.getString(R.string.player_ended_title),
            title,
            context.getString(R.string.player_replay),
            { callbacks.onReplay() },
            context.getString(R.string.player_close),
            { callbacks.onClose() },
        )
    }

    fun dismissModal() {
        if (!hasModal) return
        infoDialog?.dismiss()
        infoDialog = null
        trackDialog?.dismiss()
        trackDialog = null
        modalKind = ModalKind.NONE
        modalHost.visibility = View.GONE
        modalHost.removeAllViews()
        if (controlsVisible) playButton.post { playButton.requestFocus() }
        kick()
    }

    fun setControlsVisible(visible: Boolean, animate: Boolean = true) {
        if (visible == controlsVisible) {
            if (visible) kick()
            return
        }
        controlsVisible = visible
        handler.removeCallbacks(autoHide)
        if (!animate || !Motion.animated) {
            chrome.animate().cancel()
            chrome.visibility = if (visible) View.VISIBLE else View.GONE
            chrome.alpha = if (visible) 1f else 0f
            chrome.translationY = 0f
            if (visible) focusPlay()
            return
        }
        if (visible) {
            chrome.visibility = View.VISIBLE
            chrome.alpha = 0f
            chrome.translationY = ui.dp(10f).toFloat()
            chrome.animate().alpha(1f).translationY(0f).setStartDelay(0).setDuration(Motion.STANDARD)
                .setInterpolator(Motion.decelerate).withLayer().start()
            focusPlay()
            kick()
        } else {
            (root.findFocus() as? View)?.clearFocus()
            chrome.animate().alpha(0f).translationY(ui.dp(-6f).toFloat()).setDuration(Motion.EXIT)
                .setInterpolator(Motion.accelerate).withLayer()
                .withEndAction { if (!controlsVisible) chrome.visibility = View.GONE }.start()
        }
    }

    val controlsShown: Boolean get() = controlsVisible

    fun kick() {
        handler.removeCallbacks(autoHide)
        if (controlsVisible && !paused && phase == Phase.PLAYING && !hasModal) {
            handler.postDelayed(autoHide, 4_500)
        }
    }

    fun showTrackDialog(kind: TrackKind, tracks: List<Track>, onSelect: (String?) -> Unit) {
        if (hasModal) return
        val title = context.getString(if (kind == TrackKind.AUDIO) R.string.tracks_audio_title else R.string.tracks_subtitle_title)
        val options = ArrayList<Pair<String, () -> Unit>>()
        val autoSelected = tracks.none { it.selected }
        options += (if (autoSelected) "✓  " else "") + context.getString(R.string.track_auto) to { onSelect(null) }
        if (kind == TrackKind.SUBTITLE) {
            options += context.getString(R.string.track_off) to { onSelect("no") }
        }
        tracks.filter { it.kind == kind }.forEach { track ->
            options += (if (track.selected) "✓  " else "") + track.label to { onSelect(track.id) }
        }
        val dialog = ui.card(title, options, focus = 0)
        trackDialog = dialog
        modalKind = ModalKind.TRACKS
        handler.removeCallbacks(autoHide)
        dialog.setOnDismissListener {
            trackDialog = null
            if (modalKind == ModalKind.TRACKS) modalKind = ModalKind.NONE
            kick()
        }
    }

    fun showInfo(lines: List<Pair<String, String>>) {
        if (hasModal) return
        val dialog = Dialog(context).apply { requestWindowFeature(android.view.Window.FEATURE_NO_TITLE) }
        val body = ui.dialogBody()
        body.addView(ui.eyebrow(context.getString(R.string.info_title)))
        body.addView(ui.text(context.getString(R.string.info_title), 24f, ui.foreground, weight = 600).apply {
            setPadding(0, ui.dp(8f), 0, ui.dp(14f))
        })
        lines.forEach { (label, value) ->
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, ui.dp(7f), 0, ui.dp(7f))
            }
            row.addView(ui.text(label, 12.5f, ui.muted, weight = 500), LinearLayout.LayoutParams(ui.dp(190f), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(ui.text(value, 14f, ui.foreground, weight = 500).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            body.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val close = cardAction(context.getString(R.string.player_close), primary = true) { dialog.dismiss() }
        body.addView(close, LinearLayout.LayoutParams(ui.dp(160f), ui.dp(46f)).apply { topMargin = ui.dp(18f); gravity = Gravity.END })
        dialog.setContentView(body)
        ui.present(dialog, 720f, body)
        infoDialog = dialog
        modalKind = ModalKind.INFO
        handler.removeCallbacks(autoHide)
        dialog.setOnDismissListener {
            infoDialog = null
            if (modalKind == ModalKind.INFO) modalKind = ModalKind.NONE
            if (controlsVisible) playButton.post { playButton.requestFocus() }
            kick()
        }
        close.requestFocus()
    }

    // ---- helpers --------------------------------------------------------------------------

    private fun showModal(
        kind: ModalKind,
        eyebrow: String?,
        title: String,
        message: String,
        primaryLabel: String?,
        primaryAction: () -> Unit,
        secondaryLabel: String?,
        secondaryAction: () -> Unit,
    ) {
        modalKind = kind
        handler.removeCallbacks(autoHide)
        modalHost.removeAllViews()
        modalHost.addView(View(context).apply { setBackgroundColor(ui.scrim(if (ui.light) 150 else 200)) }, frame())

        val card = ui.dialogBody().apply { clipChildren = false }
        if (!eyebrow.isNullOrBlank()) card.addView(ui.eyebrow(eyebrow))
        card.addView(ui.text(title, 24f, ui.foreground, weight = 600).apply {
            setPadding(0, if (eyebrow.isNullOrBlank()) 0 else ui.dp(8f), 0, 0)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })
        if (message.isNotBlank()) card.addView(ui.text(message, 14f, ui.muted).apply {
            setPadding(0, ui.dp(12f), 0, 0)
            setLineSpacing(ui.dp(4f).toFloat(), 1f)
        })

        val buttons = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, ui.dp(22f), 0, 0) }
        if (secondaryLabel != null) {
            buttons.addView(cardAction(secondaryLabel, primary = false, action = secondaryAction), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui.dp(46f)))
        }
        if (primaryLabel != null) {
            buttons.addView(cardAction(primaryLabel, primary = true, action = primaryAction), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui.dp(46f)).apply {
                if (secondaryLabel != null) marginStart = ui.dp(12f)
            })
        }
        card.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        modalHost.addView(card, FrameLayout.LayoutParams(ui.dp(760f), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply {
            leftMargin = ui.dp(24f); rightMargin = ui.dp(24f)
        })
        modalHost.visibility = View.VISIBLE
        modalHost.post {
            val index = if (primaryLabel != null && secondaryLabel != null) 1 else 0
            (buttons.getChildAt(index) ?: buttons.getChildAt(0))?.requestFocus()
        }
        if (Motion.animated) {
            card.alpha = 0f
            card.scaleX = .97f; card.scaleY = .97f
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(Motion.EMPHASIZED).setInterpolator(Motion.decelerate).start()
        }
    }

    private fun focusPlay() {
        root.post {
            if (controlsVisible && !hasModal) playButton.requestFocus()
        }
    }

    private fun iconButton(kind: PlayerIcon.Kind, description: String, size: Float, primary: Boolean = false, action: () -> Unit): FrameLayout {
        val button = FrameLayout(context).apply {
            contentDescription = description
            isFocusable = true
            isFocusableInTouchMode = true
            isClickable = true
            clipChildren = false
            val fill = if (primary) ui.accent else ui.chip
            val focusFill = if (primary) ui.accent else ui.chipFocus
            ui.style(this, FocusStyle(fill, null, focusFill, ui.radii(TvDesign.PILL), 1.06f, ui.ring, 1.5f))
            setOnFocusChangeListener { view, focused -> ui.focus(view, focused); if (focused) kick() }
            setOnClickListener { ui.press(this); kick(); action() }
        }
        val image = ImageView(context).apply {
            contentDescription = description
            setImageDrawable(PlayerIcon(kind, if (primary) ui.onAccent else ui.foreground))
        }
        button.addView(image, FrameLayout.LayoutParams(ui.dp(size * .48f), ui.dp(size * .48f), Gravity.CENTER))
        return button
    }

    private fun pill(kind: PlayerIcon.Kind, label: String, action: () -> Unit): LinearLayout {        val pill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(14f), 0, ui.dp(16f), 0)
            contentDescription = label
            isFocusable = true
            isFocusableInTouchMode = true
            isClickable = true
            ui.style(this, FocusStyle(ui.chip, null, ui.chipFocus, ui.radii(TvDesign.PILL), 1.05f, ui.ring, 1.4f))
            setOnFocusChangeListener { view, focused -> ui.focus(view, focused); if (focused) kick() }
            setOnClickListener { ui.press(this); kick(); action() }
        }
        val icon = ImageView(context).apply { contentDescription = label; setImageDrawable(PlayerIcon(kind, ui.foreground)) }
        pill.addView(icon, LinearLayout.LayoutParams(ui.dp(20f), ui.dp(20f)).apply { marginEnd = ui.dp(8f) })
        pill.addView(ui.text(label, 13f, ui.foreground, weight = 500).apply { maxLines = 1 })
        return pill
    }

    private fun addPill(container: LinearLayout, kind: PlayerIcon.Kind, description: String, label: String, action: () -> Unit) {
        container.addView(pill(kind, label, action).apply { contentDescription = description }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        ).apply { if (container.childCount > 0) marginStart = ui.dp(10f) })
    }

    private fun cardAction(label: String, primary: Boolean, action: () -> Unit): TextView = ui.text(
        label,
        14f,
        if (primary) ui.onAccent else ui.foreground,
        weight = 600,
    ).apply {
        gravity = Gravity.CENTER
        maxLines = 1
        setPadding(ui.dp(22f), 0, ui.dp(22f), 0)
        isFocusable = true
        isFocusableInTouchMode = true
        isClickable = true
        ui.style(this, FocusStyle(
            if (primary) ui.accent else ui.surfaceHigh,
            null,
            if (primary) ui.accent else ui.chipFocus,
            ui.radii(TvDesign.RADIUS_M),
            1.04f,
            ui.ring,
            1.4f,
        ))
        setOnFocusChangeListener { view, focused -> ui.focus(view, focused) }
        setOnClickListener { ui.press(this); action() }
    }

    private fun gradient(orientation: GradientDrawable.Orientation, vararg colors: Int) = GradientDrawable(orientation, colors)

    private fun frame() = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
}

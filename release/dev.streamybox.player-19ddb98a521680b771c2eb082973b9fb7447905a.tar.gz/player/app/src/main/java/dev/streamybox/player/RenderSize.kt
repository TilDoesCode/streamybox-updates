package dev.streamybox.player

/** Picks the SurfaceView buffer size for the current video and display. */
object RenderSize {
    const val UHD_WIDTH = 3840
    const val UHD_HEIGHT = 2160
    const val FHD_WIDTH = 1920
    const val FHD_HEIGHT = 1080

    fun choose(videoWidth: Int, videoHeight: Int, maxWidth: Int, maxHeight: Int): Pair<Int, Int>? {
        if (videoWidth <= 0 || videoHeight <= 0 || maxWidth <= 0 || maxHeight <= 0) return null
        val uhd = videoWidth > FHD_WIDTH || videoHeight > FHD_HEIGHT
        val width = if (uhd) minOf(maxWidth, UHD_WIDTH) else minOf(maxWidth, FHD_WIDTH)
        val height = if (uhd) minOf(maxHeight, UHD_HEIGHT) else minOf(maxHeight, FHD_HEIGHT)
        return width to height
    }
}

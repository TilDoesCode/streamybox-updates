package dev.streamybox.player.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable

/** Line icons in the same 24 dp drawing grid as the shared design Glyph. */
class PlayerIcon(private var kind: Kind, private var tint: Int) : Drawable() {
    enum class Kind { PLAY, PAUSE, REWIND, FORWARD, AUDIO, SUBTITLES, CLOSE, INFO, GEAR, REPLAY, CHECK, WARNING }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        style = Paint.Style.STROKE
        strokeWidth = 1.9f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    private val path = android.graphics.Path()
    private val oval = RectF()

    fun tint(color: Int) {
        if (tint != color) { tint = color; invalidateSelf() }
    }

    override fun draw(canvas: Canvas) {
        val box = bounds
        val unit = minOf(box.width(), box.height()) / 24f
        canvas.save()
        canvas.translate(box.exactCenterX() - 12 * unit, box.exactCenterY() - 12 * unit)
        canvas.scale(unit, unit)
        paint.color = tint
        textPaint.color = tint
        paint.style = Paint.Style.STROKE
        when (kind) {
            Kind.PLAY -> {
                paint.style = Paint.Style.FILL
                path.reset(); path.moveTo(7.5f, 4.5f); path.lineTo(19.5f, 12f); path.lineTo(7.5f, 19.5f); path.close()
                canvas.drawPath(path, paint)
            }
            Kind.PAUSE -> {
                paint.style = Paint.Style.FILL
                canvas.drawRoundRect(6.8f, 4.8f, 10.4f, 19.2f, 1.2f, 1.2f, paint)
                canvas.drawRoundRect(13.6f, 4.8f, 17.2f, 19.2f, 1.2f, 1.2f, paint)
            }
            Kind.REWIND -> seek(canvas, reverse = true)
            Kind.FORWARD -> seek(canvas, reverse = false)
            Kind.AUDIO -> {
                path.reset(); path.moveTo(3.6f, 9.4f); path.lineTo(7.4f, 9.4f); path.lineTo(12f, 5.2f); path.lineTo(12f, 18.8f)
                path.lineTo(7.4f, 14.6f); path.lineTo(3.6f, 14.6f); path.close(); canvas.drawPath(path, paint)
                arc(canvas, 12f, 12f, 4.2f, -45f, 90f)
                arc(canvas, 12f, 12f, 7.8f, -45f, 90f)
            }
            Kind.SUBTITLES -> {
                canvas.drawRoundRect(3.2f, 5.2f, 20.8f, 18.8f, 2.4f, 2.4f, paint)
                canvas.drawLine(6.4f, 12.2f, 10.4f, 12.2f, paint)
                canvas.drawLine(13.2f, 12.2f, 17.6f, 12.2f, paint)
                canvas.drawLine(6.4f, 15.6f, 12.6f, 15.6f, paint)
            }
            Kind.CLOSE -> {
                canvas.drawLine(6f, 6f, 18f, 18f, paint)
                canvas.drawLine(18f, 6f, 6f, 18f, paint)
            }
            Kind.INFO -> {
                canvas.drawCircle(12f, 12f, 8.8f, paint)
                canvas.drawLine(12f, 11f, 12f, 16.4f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(12f, 7.9f, 1.15f, paint)
            }
            Kind.GEAR -> {
                canvas.drawCircle(12f, 12f, 6.2f, paint)
                canvas.drawCircle(12f, 12f, 2.4f, paint)
                paint.strokeWidth = 2.6f
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    canvas.drawLine(
                        12f + 7.4f * Math.cos(a).toFloat(), 12f + 7.4f * Math.sin(a).toFloat(),
                        12f + 9.3f * Math.cos(a).toFloat(), 12f + 9.3f * Math.sin(a).toFloat(), paint,
                    )
                }
                paint.strokeWidth = 1.9f
            }
            Kind.REPLAY -> {
                oval.set(4f, 4f, 20f, 20f); canvas.drawArc(oval, -60f, 300f, false, paint)
                paint.style = Paint.Style.FILL
                path.reset(); path.moveTo(17.2f, 2.6f); path.lineTo(18.2f, 8.6f); path.lineTo(12.4f, 7f); path.close()
                canvas.drawPath(path, paint)
            }
            Kind.CHECK -> {
                paint.strokeWidth = 2.4f
                path.reset(); path.moveTo(5f, 12.4f); path.lineTo(10f, 17.2f); path.lineTo(19f, 6.8f)
                canvas.drawPath(path, paint)
            }
            Kind.WARNING -> {
                path.reset(); path.moveTo(12f, 3.6f); path.lineTo(21.2f, 20f); path.lineTo(2.8f, 20f); path.close()
                canvas.drawPath(path, paint)
                canvas.drawLine(12f, 9f, 12f, 14f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(12f, 17f, 1.1f, paint)
            }
        }
        canvas.restore()
    }

    private fun seek(canvas: Canvas, reverse: Boolean) {
        oval.set(4f, 4f, 20f, 20f)
        canvas.drawArc(oval, if (reverse) 120f else -60f, 300f, false, paint)
        paint.style = Paint.Style.FILL
        path.reset()
        if (reverse) {
            path.moveTo(2.8f, 6.4f); path.lineTo(8.2f, 7.6f); path.lineTo(4.4f, 11.6f)
        } else {
            path.moveTo(21.2f, 6.4f); path.lineTo(15.8f, 7.6f); path.lineTo(19.6f, 11.6f)
        }
        path.close()
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.STROKE
        textPaint.textSize = 7.2f
        canvas.drawText("10", 12f, 14.6f, textPaint)
    }

    private fun arc(canvas: Canvas, x: Float, y: Float, radius: Float, start: Float, sweep: Float) {
        oval.set(x - radius, y - radius, x + radius, y + radius)
        canvas.drawArc(oval, start, sweep, false, paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
        textPaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        paint.colorFilter = colorFilter
        textPaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}

/*
 * Adapted from mpv-android (https://github.com/mpv-android/mpv-android), BaseMPVView.kt.
 * Copyright (c) 2016 Ilya Zhuravlev, sfan5 <sfan5@live.de>, MIT licensed.
 * Modifications for Streamybox: option map, queued load with HTTP headers, no config file.
 *
 * This file is part of the Streamybox Player, licensed GPL-3.0-or-later.
 */
package dev.streamybox.player.mpv

import android.content.Context
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import dev.streamybox.player.RenderSize

/**
 * The PlayerActivity's SurfaceView. mpv itself lives in [MpvSurfaceHost]; this class only adds
 * what needs a window: the SurfaceHolder lifecycle and the 4K buffer size for the current display.
 */
abstract class BaseMPVView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    val host = MpvSurfaceHost(context)
    private var initialized = false
    private var surfaceReady = false
    private var desiredRenderSize: Pair<Int, Int>? = null
    private var appliedRenderSize: Pair<Int, Int>? = null

    fun initialize(options: Map<String, String>, configDir: String, cacheDir: String) {
        if (initialized) return
        host.initialize(options, configDir, cacheDir)
        holder.addCallback(this)
        initialized = true
    }

    /** 4K video gets a 4K buffer; HD stays at the UI size and lets the HWC upscale. */
    fun setRenderSize(videoWidth: Int, videoHeight: Int) {
        val mode = display?.mode ?: return
        val size = RenderSize.choose(videoWidth, videoHeight, mode.physicalWidth, mode.physicalHeight) ?: return
        if (desiredRenderSize == size) return
        desiredRenderSize = size
        applyRenderSize()
    }

    private fun applyRenderSize() {
        if (!surfaceReady) return
        val size = desiredRenderSize ?: return
        if (appliedRenderSize == size) return
        appliedRenderSize = size
        Log.i(TAG, "render buffer ${size.first}x${size.second}")
        holder.setFixedSize(size.first, size.second)
    }

    fun destroy() {
        if (!initialized) return
        holder.removeCallback(this)
        initialized = false
        host.destroy()
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        if (!initialized) return
        surfaceReady = true
        host.attach(holder.surface)
        applyRenderSize()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (initialized) host.resize(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        if (!initialized) return
        surfaceReady = false
        appliedRenderSize = null
        host.detach()
    }

    private companion object { const val TAG = "SbPlayerMpv" }
}

/** Concrete surface view kept close to the mpv-android naming so future upstream patches stay portable. */
class MPVView(context: Context) : BaseMPVView(context)

package dev.streamybox.player.render

import dev.streamybox.player.ExternalSubtitle
import dev.streamybox.player.Header
import dev.streamybox.player.PlayRequest
import dev.streamybox.player.PlayRequestParser
import java.io.File
import java.net.URI
import java.util.Locale

/** `load()` options from the contract, already validated. */
data class LoadOptions(
    val title: String? = null,
    val startPositionMs: Long = 0L,
    val headers: List<Header> = emptyList(),
    val muted: Boolean? = null,
    val audioTrack: Int? = null,
    val subtitleTrack: Int? = null,
    val externalSubtitles: List<ExternalSubtitle> = emptyList(),
)

sealed interface LoadResult {
    data class Ok(val request: PlayRequest) : LoadResult
    data class Invalid(val reason: String, val detail: String? = null) : LoadResult
}

/** Parses and validates `load(url, optionsJson)`; pure, unit tested. */
object RenderOptions {
    const val MAX_SUBTITLES = 16
    const val MAX_TITLE = 200

    private val languagePattern = Regex("^[A-Za-z]{2,8}(-[A-Za-z0-9]{1,8}){0,3}$")

    fun parse(json: String?): Result<LoadOptions> = runCatching {
        if (json.isNullOrBlank()) return@runCatching LoadOptions()
        val root = Json.parse(json) as? Map<*, *> ?: throw IllegalArgumentException("options must be an object")
        val headers = when (val raw = root["headers"]) {
            null -> emptyList()
            is String -> listOf(raw)
            is List<*> -> raw.map { it as? String ?: throw IllegalArgumentException("headers must be strings") }
            else -> throw IllegalArgumentException("headers must be a list")
        }
        val parsedHeaders = when (val result = PlayRequestParser.parseHeaders(headers)) {
            is PlayRequestParser.HeaderResult.Ok -> result.headers
            is PlayRequestParser.HeaderResult.Invalid -> throw IllegalArgumentException("bad header ${result.detail.orEmpty()}")
        }
        val subtitles = (root["externalSubtitles"] as? List<*>).orEmpty().take(MAX_SUBTITLES).mapNotNull { entry ->
            val item = entry as? Map<*, *> ?: return@mapNotNull null
            val url = (item["url"] as? String)?.trim() ?: return@mapNotNull null
            ExternalSubtitle(
                url = url,
                title = (item["title"] as? String)?.trim()?.take(MAX_TITLE)?.takeIf { it.isNotEmpty() }?.let(::clean),
                language = (item["language"] as? String)?.trim()?.takeIf { languagePattern.matches(it) },
            )
        }
        LoadOptions(
            title = (root["title"] as? String)?.trim()?.take(MAX_TITLE)?.takeIf { it.isNotEmpty() },
            startPositionMs = number(root["startPositionMs"])?.coerceIn(0L, PlayRequestParser.MAX_POSITION_MS) ?: 0L,
            headers = parsedHeaders,
            muted = root["muted"] as? Boolean,
            audioTrack = number(root["audioTrack"])?.toInt()?.takeIf { it >= 1 },
            subtitleTrack = number(root["subtitleTrack"])?.toInt()?.takeIf { it == -1 || it >= 1 },
            externalSubtitles = subtitles,
        )
    }

    /**
     * Only http/https/content/file reach mpv. file:// must not point into the player's own data
     * ([privateDirs]): the client could read it back from its own surface.
     */
    fun validateUrl(url: String, privateDirs: List<String>): String? {
        PlayRequestParser.validateAddress(url)?.let { return it.name.lowercase(Locale.ROOT) }
        val uri = URI(url.trim())
        if (uri.scheme.equals("file", ignoreCase = true)) {
            val path = runCatching { File(uri.path).canonicalPath }.getOrNull() ?: return "malformed_url"
            if (privateDirs.any { dir -> path == dir || path.startsWith(dir.trimEnd('/') + "/") }) return "private_path"
        }
        return null
    }

    fun request(url: String?, optionsJson: String?, privateDirs: List<String>, mutedDefault: Boolean): LoadResult {
        val address = url?.trim().orEmpty()
        validateUrl(address, privateDirs)?.let { return LoadResult.Invalid("invalid_url", it) }
        val options = parse(optionsJson).getOrElse { return LoadResult.Invalid("invalid_options", it.message) }
        val subtitles = options.externalSubtitles.filter { validateUrl(it.url, privateDirs) == null }
        return LoadResult.Ok(
            PlayRequest(
                url = address,
                title = options.title ?: PlayRequestParser.deriveTitle(address),
                headers = options.headers,
                startPositionMs = options.startPositionMs,
                externalSubtitles = subtitles,
                audioTrack = options.audioTrack,
                subtitleTrack = options.subtitleTrack,
                muted = options.muted ?: mutedDefault,
            )
        )
    }

    private val spdifNames = setOf("ac3", "eac3", "truehd", "dts", "dts-hd")

    /** Debug builds only: `"debugSpdif":"ac3,eac3"` forces audio-spdif (emulators have no bitstream sink). */
    fun debugSpdif(json: String?): List<String>? {
        val root = runCatching { json?.let { Json.parse(it) } as? Map<*, *> }.getOrNull() ?: return null
        val value = root["debugSpdif"] as? String ?: return null
        return value.split(',').map { it.trim() }.filter { it in spdifNames }.distinct()
    }

    private fun number(value: Any?): Long? = when (value) {
        is Long -> value
        is Int -> value.toLong()
        is Double -> if (value.isFinite()) value.toLong() else null
        is String -> value.trim().toLongOrNull()
        else -> null
    }

    private fun clean(text: String): String = text.filter { !it.isISOControl() }
}

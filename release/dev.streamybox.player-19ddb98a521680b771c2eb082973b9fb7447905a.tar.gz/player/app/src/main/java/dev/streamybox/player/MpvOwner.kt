package dev.streamybox.player

/**
 * mpv-android keeps one libmpv client per process. PlayerActivity and the render service take turns:
 * the newest holder wins and the previous one releases its engine synchronously first. Main thread only.
 */
object MpvOwner {
    fun interface Holder {
        /** Release the engine now (MPVLib.destroy) and stop showing playback. */
        fun yieldMpv()
    }

    private var current: Holder? = null

    val holder: Holder? get() = current

    fun acquire(next: Holder) {
        val previous = current
        if (previous === next) return
        current = null
        previous?.yieldMpv()
        current = next
    }

    fun release(holder: Holder) {
        if (current === holder) current = null
    }
}

/*
 * Streamybox Player libmpv session. Uses the adapted mpv-android JNI bridge.
 * This file is part of the Streamybox Player, licensed GPL-3.0-or-later.
 */
package dev.streamybox.player

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import android.view.View
import dev.streamybox.player.mpv.MPVLib
import dev.streamybox.player.mpv.MPVView
import dev.streamybox.player.mpv.MpvSurfaceHost
import java.io.File
import java.util.Locale

/**
 * Real playback through libmpv. Property observation happens on mpv's event thread and is
 * marshalled to the main thread before the UI listener sees it. [embedded] engines own no View:
 * the render service hands them a client Surface via [attachSurface].
 */
class MpvEngine(
    private val context: Context,
    private val config: PlayerConfig,
    embedded: Boolean = false,
) : PlayerEngine, MPVLib.EventObserver, MPVLib.LogObserver {

    override val available: Boolean = MPVLib.available
    private var view: MPVView? = if (available && !embedded) MPVView(context) else null
    private var host: MpvSurfaceHost? = view?.host ?: if (available) MpvSurfaceHost(context) else null
    override val surface: View? = view
    private val firstFrame = FirstFrameGate()
    private var httpStatus: Int? = null

    /** Unpause once the profile decision is done; false keeps the first frame paused. */
    var playWhenReady = true
        private set

    private val handler = Handler(Looper.getMainLooper())
    private var listener: PlayerEngine.Listener? = null
    private val values = HashMap<String, Any>()
    private var released = false
    private var fileLoaded = false
    private var ended = false
    private var loading = false
    private var lastError: String? = null
    private var pendingStartMs = 0L
    private var forcedSelectionPending = false
    private var decodeSwitchApplied = false
    private var currentHwdec = "mediacodec"
    private var fileFinalized = false
    private var dvFromDecoder = false
    private var seekKeyframes = false
    private var spdifActive = false
    private var spdifCodecs: List<String> = emptyList()
    private var muted = false
    private var stallTicks = 0
    private var stallPosition = -1L
    private var ignoreEndFile = false
    private var version: String? = null
    private var currentRequest: PlayRequest? = null
    private var softwareRetry = false
    private var retrying = false
    private var externalApplied = false
    private var pendingSubtitleId: Int? = null

    private val timeout = Runnable {
        if (loading && !fileLoaded && !released) {
            loading = false
            lastError = context.getString(R.string.player_error_detail)
            listener?.onError(lastError)
            publishAll()
        }
    }

    init {
        if (available) {
            val mpvDir = File(context.filesDir, "mpv").apply { mkdirs() }
            val cache = File(context.cacheDir, "mpv").apply { mkdirs() }
            val options = MpvOptions.build(config, HdrSupport.rgbHdr10(context), EglSupport.rgb10a2)
            view?.initialize(options, mpvDir.absolutePath, cache.absolutePath)
                ?: host?.initialize(options, mpvDir.absolutePath, cache.absolutePath)
            MPVLib.addObserver(this)
            MPVLib.addLogObserver(this)
            version = MPVLib.getPropertyString("mpv-version")
            observeAll()
        }
    }

    override fun setListener(listener: PlayerEngine.Listener) { this.listener = listener }

    override fun prepare(request: PlayRequest) {
        if (!available) return
        released = false
        fileLoaded = false
        ended = false
        loading = true
        lastError = null
        currentRequest = request
        softwareRetry = false
        retrying = false
        pendingStartMs = request.startPositionMs
        seekKeyframes = false
        forcedSelectionPending = config.subtitleMode == SubtitleMode.FORCED
        externalApplied = false
        pendingSubtitleId = null
        decodeSwitchApplied = false
        currentHwdec = desiredHwdec(0)
        fileFinalized = false
        dvFromDecoder = false
        ignoreEndFile = false
        httpStatus = null
        playWhenReady = true
        firstFrame.arm()
        values.clear()
        stallTicks = 0
        muted = request.muted
        // The route can change between loads (HDMI replugged); mpv applies audio-spdif when the track opens.
        applySpdif(passthroughCodecs())
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, LOAD_TIMEOUT_MS)
        // Start paused so the profile decision happens before the first visible frame.
        MPVLib.setPropertyBoolean("pause", true)
        MPVLib.setPropertyBoolean("mute", request.muted)
        host?.requestLoad(request.url, request.headerFields())
        publishStatus()
    }

    override fun play() {
        playWhenReady = true
        if (fileFinalized && !loading) setPause(false)
    }

    override fun pause() {
        playWhenReady = false
        setPause(true)
    }

    override fun togglePause() {
        if (fileFinalized && !loading) {
            val paused = values["pause"] as? Boolean ?: false
            playWhenReady = paused
            setPause(!paused)
        } else {
            playWhenReady = !playWhenReady
        }
    }

    /** A bitstream ignores volume and mute, so muted playback always decodes to PCM. */
    fun setMuted(muted: Boolean) {
        if (!available || released) return
        MPVLib.setPropertyBoolean("mute", muted)
        if (muted == this.muted) return
        this.muted = muted
        val codecs = passthroughCodecs()
        if (codecs == spdifCodecs) return
        Log.i(TAG, "mute=$muted: audio-spdif ${spdifCodecs.joinToString(",")} -> ${codecs.joinToString(",")}")
        applySpdif(codecs)
        if (spdifActive && fileFinalized) startStallWatch()
        publishAll()
    }

    // Setting audio-spdif at runtime only reinitialises mpv's audio chain (UPDATE_AD), the video keeps running.
    private fun applySpdif(codecs: List<String>) {
        spdifCodecs = codecs
        spdifActive = codecs.isNotEmpty()
        if (!spdifActive) handler.removeCallbacks(stallWatch)
        MPVLib.setPropertyString("audio-spdif", codecs.joinToString(","))
    }

    /** Renders into a Surface owned by another component (embedded mode). */
    fun attachSurface(surface: Surface, width: Int, height: Int) {
        if (!available || released) return
        host?.attach(surface, width, height)
        if (firstFrame.surfaceAttached()) listener?.onFirstFrame()
    }

    fun resizeSurface(width: Int, height: Int) {
        if (available && !released) host?.resize(width, height)
    }

    /** Stops rendering into the current surface; the file stays loaded. */
    fun detachSurface() {
        if (available && !released) host?.detach()
    }

    val surfaceAttached: Boolean get() = host?.surfaceAttached == true

    /** Frames shown so far (mpv's estimate), for the stats event. */
    fun frameNumber(): Long? =
        if (available && !released && fileLoaded) runCatching { MPVLib.getPropertyInt("estimated-frame-number")?.toLong() }.getOrNull() else null

    private fun setPause(paused: Boolean) {
        if (!available) return
        MPVLib.setPropertyBoolean("pause", paused)
    }

    override fun seekBy(deltaMs: Long) {
        if (!available) return
        val delta = deltaMs / 1000.0
        MPVLib.command(arrayOf("seek", String.format(Locale.ROOT, "%.3f", delta), "relative+exact"))
    }

    override fun seekTo(positionMs: Long) {
        if (!available) return
        val seconds = positionMs.coerceAtLeast(0L) / 1000.0
        MPVLib.command(arrayOf("seek", String.format(Locale.ROOT, "%.3f", seconds), "absolute+exact"))
    }

    override fun selectAudio(id: String) {
        if (available) MPVLib.setPropertyString("aid", id)
    }

    override fun selectSubtitle(id: String) {
        if (available) MPVLib.setPropertyString("sid", id)
    }

    override fun release() {
        if (released) return
        released = true
        handler.removeCallbacksAndMessages(null)
        if (available) {
            MPVLib.removeObserver(this)
            MPVLib.removeLogObserver(this)
            view?.destroy() ?: host?.destroy()
        }
        view = null
        host = null
        listener = null
    }

    // ---- property observation -------------------------------------------------------------

    override fun eventProperty(property: String) = post { values.remove(property); publishAll() }

    override fun eventProperty(property: String, value: Long) = post { values[property] = value; changed(property) }

    override fun eventProperty(property: String, value: Boolean) = post { values[property] = value; changed(property) }

    override fun eventProperty(property: String, value: Double) = post { values[property] = value; changed(property) }

    override fun eventProperty(property: String, value: String) = post { values[property] = value; changed(property) }

    override fun event(eventId: Int) = post {
        when (eventId) {
            MPVLib.MpvEvent.MPV_EVENT_FILE_LOADED -> {
                fileLoaded = true
                ended = false
                retrying = false
                handler.postDelayed({ ignoreEndFile = false }, 1_200)
                handler.removeCallbacks(timeout)
                fileFinalized = false
                val profile = int("current-tracks/video/dolby-vision-profile") ?: 0
                val desired = desiredHwdec(profile)
                Log.i(TAG, "file-loaded DV profile=$profile currentHwdec=$currentHwdec desiredHwdec=$desired")
                if (!decodeSwitchApplied && profile != 0 && desired != currentHwdec) {
                    decodeSwitchApplied = true
                    reloadWithHwdec(desired, "DV profile $profile", keyframes = false)
                    return@post
                }
                // The track profile can appear a few ms after file-loaded; keep the frame paused
                // and hidden behind the loading screen until that decision is made.
                handler.postDelayed({ finishFileLoaded() }, PROFILE_WAIT_MS)
            }
            MPVLib.MpvEvent.MPV_EVENT_END_FILE -> {
                // Legacy bridge only forwards the event id; new JNI uses endFile(reason).
                if (released) return@post
                if (retrying || ignoreEndFile) { retrying = false; return@post }
                val eof = values["eof-reached"] as? Boolean ?: false
                handleEndFile(EndFilePolicy.actionForLegacyEof(eof))
            }
            MPVLib.MpvEvent.MPV_EVENT_PLAYBACK_RESTART -> {
                if (firstFrame.playbackRestart(surfaceAttached)) listener?.onFirstFrame()
                publishAll()
            }
            MPVLib.MpvEvent.MPV_EVENT_VIDEO_RECONFIG,
            MPVLib.MpvEvent.MPV_EVENT_AUDIO_RECONFIG -> publishAll()
            MPVLib.MpvEvent.MPV_EVENT_SHUTDOWN -> Log.w(TAG, "libmpv shut down")
        }
    }

    private fun finishFileLoaded() {
        if (!available || released || !fileLoaded || fileFinalized) return
        fileFinalized = true
        val profile = int("current-tracks/video/dolby-vision-profile") ?: 0
        val desired = desiredHwdec(profile)
        if (!decodeSwitchApplied && desired != currentHwdec) {
            decodeSwitchApplied = true
            reloadWithHwdec(desired, "DV profile $profile", keyframes = false)
            return
        }
        if (profile == 5 || desired == "mediacodec-copy") MPVLib.setPropertyString("framedrop", "vo")
        if (pendingStartMs > 0) {
            val seconds = String.format(Locale.ROOT, "%.3f", pendingStartMs / 1000.0)
            firstFrame.seekIssued()
            MPVLib.command(arrayOf("seek", seconds, if (seekKeyframes) "absolute+keyframes" else "absolute+exact"))
            pendingStartMs = 0
        }
        val request = currentRequest
        if (request != null && !externalApplied) {
            externalApplied = true
            // Async: a network subtitle must not block the main thread; ids follow the embedded tracks.
            for (sub in request.externalSubtitles) {
                MPVLib.commandAsync(arrayOf("sub-add", sub.url, "auto", sub.title.orEmpty(), sub.language.orEmpty()))
            }
            request.audioTrack?.let { MPVLib.setPropertyString("aid", it.toString()) }
            request.subtitleTrack?.let {
                forcedSelectionPending = false
                pendingSubtitleId = it
                applyPendingSubtitle()
            }
        }
        if (forcedSelectionPending) {
            forcedSelectionPending = false
            handler.postDelayed(Runnable { applyForcedSubtitles() }, 350)
        }
        MPVLib.setPropertyBoolean("pause", !playWhenReady)
        values["pause"] = !playWhenReady
        loading = false
        listener?.onFileLoaded()
        publishAll()
        if (firstFrame.finalized(surfaceAttached)) listener?.onFirstFrame()
        if (spdifActive) startStallWatch()
    }

    /** The selected track reports what mpv's AO really opened; the others what selecting them would give. */
    private fun audioOutput(codec: String?, channels: Int?, selected: Boolean): String {
        val sinkPcm = PassthroughProbe.lastSink?.reported?.lpcmChannels
        val format = if (selected) string("audio-out-params/format") else null
        if (format != null) {
            if (format.startsWith("spdif-")) return "passthrough:${codec ?: format.removePrefix("spdif-")}"
            return PassthroughPolicy.output(null, int("audio-out-params/channel-count") ?: channels, emptyList(), sinkPcm)
        }
        return PassthroughPolicy.output(codec, channels, spdifCodecs, sinkPcm)
    }

    private fun passthroughCodecs(): List<String> = PassthroughPolicy.effective(config.passthrough, passthroughBroken, muted) {
        PassthroughProbe.debugSpdif ?: PassthroughProbe.codecs(context)
    }

    /** A bitstream the sink silently refuses stalls the audio clock (mpv waits forever); fall back to PCM. */
    private fun startStallWatch() {
        stallTicks = 0
        stallPosition = -1L
        handler.removeCallbacks(stallWatch)
        handler.postDelayed(stallWatch, STALL_TICK_MS)
    }

    private val stallWatch = object : Runnable {
        override fun run() {
            if (released || !spdifActive || !fileFinalized) return
            val running = values["pause"] != true && values["paused-for-cache"] != true && !ended
            val position = seconds("time-pos")
            stallTicks = if (running && position == stallPosition) stallTicks + 1 else 0
            stallPosition = position
            if (stallTicks >= STALL_TICKS) return fallbackToPcm("no audio progress for ${STALL_TICKS * STALL_TICK_MS} ms")
            handler.postDelayed(this, STALL_TICK_MS)
        }
    }

    private fun fallbackToPcm(reason: String) {
        if (!spdifActive || released) return
        passthroughBroken = true
        Log.w(TAG, "audio passthrough failed ($reason); decoding to PCM")
        applySpdif(emptyList())
        publishAll()
    }

    /** External subtitles arrive asynchronously; select the requested id once mpv lists it. */
    private fun applyPendingSubtitle() {
        val id = pendingSubtitleId ?: return
        if (id >= 0 && tracks().none { it.kind == TrackKind.SUBTITLE && it.id == id.toString() }) return
        pendingSubtitleId = null
        MPVLib.setPropertyString("sid", if (id < 0) "no" else id.toString())
    }

    override fun endFile(reason: Int) = post {
        if (released) return@post
        val action = EndFilePolicy.action(reason)
        Log.i(TAG, "end-file reason=$reason action=$action")
        handleEndFile(action)
    }

    private fun handleEndFile(action: EndAction) {
        handler.removeCallbacks(timeout)
        when (action) {
            EndAction.IGNORE -> retrying = false
            EndAction.ENDED -> {
                loading = false
                fileLoaded = false
                ended = true
                lastError = null
                retrying = false
                listener?.onEnded()
                publishAll()
            }
            EndAction.ERROR -> {
                loading = false
                fileLoaded = false
                retrying = false
                listener?.onError(lastError)
                publishAll()
            }
        }
    }

    override fun logMessage(prefix: String, level: Int, text: String) {
        if (level <= MPVLib.MpvLogLevel.MPV_LOG_LEVEL_WARN) {
            HttpStatus.parse(text)?.let { status -> post { httpStatus = status } }
        }
        if (level > MPVLib.MpvLogLevel.MPV_LOG_LEVEL_ERROR) {
            // B's fixtures without a container DOVI record still decode as Dolby Vision.
            if (prefix.startsWith("vd") && text.contains("dolbyvision", ignoreCase = true)) {
                post { if (!dvFromDecoder) { dvFromDecoder = true; publishAll() } }
            }
            return
        }
        // libplacebo reports optional features (LittleCMS) as errors; they do not stop playback.
        if (prefix.contains("libplacebo") || text.contains("LittleCMS")) return
        if (listOf("stream", "file", "demux", "cplayer", "ffmpeg", "vd", "ao", "vo").none { prefix.startsWith(it) }) return
        // Benign first-frame probe of the copy-back MediaCodec path; it does not stop playback.
        if (text.contains("Both surface and native_window are NULL")) return
        // A zero-copy frame flushed by a seek (ENOENT); mpv treats it as rendered.
        if (text.contains("Failed to render buffer: No such file or directory")) return
        val line = text.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(240) ?: return
        Log.w(TAG, "[$prefix] $line")
        // Decoder messages are often recoverable (POC/RPU warnings); only load failures are fatal.
        val decoder = prefix.startsWith("ffmpeg") || prefix == "vd" || prefix.startsWith("vd/")
        if (SPDIF_FAILURES.any { text.contains(it) }) {
            post { fallbackToPcm(line) }
            return
        }
        if (!decoder) post { lastError = line }
        if (!softwareRetry && config.hwdecode == HwDecode.MEDIACODEC &&
            (text.contains("missing PTS") || text.contains("missing picture"))) {
            softwareRetry = true
            post { reloadWithSoftware("MediaCodec PTS error") }
        }
    }

    /** Reloads the current stream with the requested hwdec mode, keeping the position. */
    private fun reloadWithHwdec(mode: String, reason: String, keyframes: Boolean = false) {
        val request = currentRequest ?: return
        if (!available || released) return
        val resumeAt = seconds("time-pos").takeIf { it > 0 } ?: request.startPositionMs
        Log.i(TAG, "$reason: reloading with hwdec=$mode at ${resumeAt}ms")
        MPVLib.setPropertyString("hwdec", mode)
        MPVLib.setPropertyBoolean("pause", true)
        currentHwdec = mode
        values.clear()
        pendingStartMs = resumeAt
        seekKeyframes = keyframes
        ignoreEndFile = true
        externalApplied = false
        firstFrame.reload()
        loading = true
        retrying = true
        fileLoaded = false
        ended = false
        lastError = null
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, LOAD_TIMEOUT_MS)
        listener?.onStatus(PlaybackStatus(phase = Phase.LOADING, positionMs = resumeAt))
        host?.requestLoad(request.url, request.headerFields())
    }

    private fun reloadWithSoftware(reason: String, keyframes: Boolean = false) {
        softwareRetry = true
        reloadWithHwdec("no", reason, keyframes)
    }

    // ---- derived state --------------------------------------------------------------------

    private fun changed(property: String) {
        // Decoded frames carry the RPU (FFmpeg patch); this also catches DV files without a DOVI config record.
        if (property == "video-params/colormatrix" && string(property) == "dolbyvision" && !dvFromDecoder) dvFromDecoder = true
        if (property.startsWith("video-params/") || property.startsWith("current-tracks/video/dolby-vision")) {
            applySourceProfile()
        }
        if (property.startsWith("track-list/") && fileFinalized) applyPendingSubtitle()
        if (property == "time-pos") publishStatus() else publishAll()
    }

    /** Profile 5 must never use the OES zero-copy path; switch it to copy-back once. */
    private fun applySourceProfile() {
        val profile = int("current-tracks/video/dolby-vision-profile") ?: return
        if (profile <= 0 || decodeSwitchApplied) return
        val desired = desiredHwdec(profile)
        if (desired != currentHwdec) {
            decodeSwitchApplied = true
            reloadWithHwdec(desired, "DV profile $profile (late)", keyframes = true)
        }
    }

    private fun desiredHwdec(profile: Int): String =
        DecodePolicy.hwdec(config.hwdecode, profile.takeIf { it > 0 })

    private fun publishStatus() {
        listener?.onStatus(
            PlaybackStatus(
                phase = when {
                    released -> Phase.IDLE
                    ended -> Phase.ENDED
                    lastError != null && !fileLoaded -> Phase.ERROR
                    loading -> Phase.LOADING
                    fileLoaded -> Phase.PLAYING
                    else -> Phase.LOADING
                },
                paused = values["pause"] as? Boolean ?: false,
                buffering = values["paused-for-cache"] as? Boolean ?: false,
                positionMs = seconds("time-pos"),
                durationMs = seconds("duration"),
                error = lastError,
                httpStatus = httpStatus,
            )
        )
    }

    private fun publishAll() {
        publishStatus()
        val video = videoStatus()
        video.width?.let { width -> video.height?.let { height -> view?.setRenderSize(width, height) } }
        listener?.onVideo(video)
        listener?.onTracks(tracks())
        listener?.onInfo(
            EngineInfo(
                version = version,
                videoCodec = string("current-tracks/video/codec"),
                audioCodec = string("current-tracks/audio/codec"),
                audioChannels = string("current-tracks/audio/demux-channels"),
                hwdec = string("hwdec-current"),
                droppedFrames = long("frame-drop-count")?.plus(long("decoder-frame-drop-count") ?: 0L),
                cacheSeconds = double("demuxer-cache-duration"),
            )
        )
    }

    private fun videoStatus() = VideoStatus(
        width = int("current-tracks/video/demux-w") ?: int("video-params/w"),
        height = int("current-tracks/video/demux-h") ?: int("video-params/h"),
        fps = double("current-tracks/video/demux-fps"),
        codec = string("current-tracks/video/codec"),
        hwdec = string("hwdec-current"),
        primaries = string("video-params/primaries"),
        gamma = string("video-params/gamma"),
        dvProfile = int("current-tracks/video/dolby-vision-profile"),
        dvLevel = int("current-tracks/video/dolby-vision-level"),
        sigPeak = double("video-params/sig-peak"),
        targetPrimaries = string("video-target-params/primaries"),
        targetGamma = string("video-target-params/gamma"),
        targetPeak = double("video-target-params/sig-peak"),
        dvDetected = dvFromDecoder,
    )

    private fun tracks(): List<Track> {
        val count = (int("track-list/count") ?: 0).coerceIn(0, MAX_TRACKS)
        val result = ArrayList<Track>(count)
        for (i in 0 until count) {
            val type = string("track-list/$i/type") ?: continue
            val kind = when (type) {
                "audio" -> TrackKind.AUDIO
                "sub" -> TrackKind.SUBTITLE
                else -> continue
            }
            val id = long("track-list/$i/id")?.toString() ?: continue
            val language = string("track-list/$i/lang")?.takeIf { it.isNotBlank() && it != "und" }
            val title = string("track-list/$i/title")?.takeIf { it.isNotBlank() }
            val languageName = language?.let { runCatching { Locale.forLanguageTag(it).displayName }.getOrNull() }?.takeIf { it.isNotBlank() }
            val codec = string("track-list/$i/codec")?.takeIf { it.isNotBlank() }
            val external = values["track-list/$i/external"] as? Boolean ?: false
            val forced = values["track-list/$i/forced"] as? Boolean ?: false
            val base = title ?: languageName ?: context.getString(R.string.track_unknown, i + 1)
            val notes = listOfNotNull(codec, if (external) context.getString(R.string.track_external) else null)
            val label = (listOf(base) + notes).joinToString(" · ")
            val channels = if (kind == TrackKind.AUDIO) int("track-list/$i/demux-channel-count")?.takeIf { it > 0 } else null
            val selected = values["track-list/$i/selected"] as? Boolean ?: false
            val output = if (kind == TrackKind.AUDIO) audioOutput(codec, channels, selected) else null
            result += Track(
                id, kind, label, selected, forced, external,
                language = language, codec = codec, channels = channels, output = output,
            )
        }
        return result
    }

    private fun applyForcedSubtitles() {
        if (!available || released) return
        val subs = tracks().filter { it.kind == TrackKind.SUBTITLE }
        val forced = subs.firstOrNull { it.forced && it.selected } ?: subs.firstOrNull { it.forced }
        if (forced != null) selectSubtitle(forced.id) else selectSubtitle("no")
    }

    private fun observeAll() {
        observe("pause", MPVLib.MpvFormat.MPV_FORMAT_FLAG)
        observe("paused-for-cache", MPVLib.MpvFormat.MPV_FORMAT_FLAG)
        observe("time-pos", MPVLib.MpvFormat.MPV_FORMAT_DOUBLE)
        observe("duration", MPVLib.MpvFormat.MPV_FORMAT_DOUBLE)
        observe("eof-reached", MPVLib.MpvFormat.MPV_FORMAT_FLAG)
        observe("hwdec-current", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("video-params/w", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        observe("video-params/h", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        observe("video-params/primaries", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("video-params/colormatrix", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("video-params/gamma", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("video-params/sig-peak", MPVLib.MpvFormat.MPV_FORMAT_DOUBLE)
        observe("video-target-params/primaries", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("video-target-params/gamma", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("video-target-params/sig-peak", MPVLib.MpvFormat.MPV_FORMAT_DOUBLE)
        observe("current-tracks/video/codec", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("current-tracks/video/demux-w", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        observe("current-tracks/video/demux-h", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        observe("current-tracks/video/demux-fps", MPVLib.MpvFormat.MPV_FORMAT_DOUBLE)
        observe("current-tracks/video/dolby-vision-profile", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        observe("current-tracks/video/dolby-vision-level", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        observe("current-tracks/audio/codec", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("current-tracks/audio/demux-channels", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("audio-out-params/format", MPVLib.MpvFormat.MPV_FORMAT_STRING)
        observe("audio-out-params/channel-count", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        observe("track-list/count", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        observe("demuxer-cache-duration", MPVLib.MpvFormat.MPV_FORMAT_DOUBLE)
        observe("frame-drop-count", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        observe("decoder-frame-drop-count", MPVLib.MpvFormat.MPV_FORMAT_INT64)

        for (i in 0 until MAX_TRACKS) {
            observe("track-list/$i/type", MPVLib.MpvFormat.MPV_FORMAT_STRING)
            observe("track-list/$i/id", MPVLib.MpvFormat.MPV_FORMAT_INT64)
            observe("track-list/$i/lang", MPVLib.MpvFormat.MPV_FORMAT_STRING)
            observe("track-list/$i/title", MPVLib.MpvFormat.MPV_FORMAT_STRING)
            observe("track-list/$i/codec", MPVLib.MpvFormat.MPV_FORMAT_STRING)
            observe("track-list/$i/selected", MPVLib.MpvFormat.MPV_FORMAT_FLAG)
            observe("track-list/$i/forced", MPVLib.MpvFormat.MPV_FORMAT_FLAG)
            observe("track-list/$i/external", MPVLib.MpvFormat.MPV_FORMAT_FLAG)
            observe("track-list/$i/demux-channel-count", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        }
    }

    private fun observe(name: String, format: Int) {
        runCatching { MPVLib.observeProperty(name, format) }
            .onFailure { Log.w(TAG, "cannot observe $name: ${it.message}") }
    }

    // Events queued before release() must not reach libmpv: it may be gone (exit(1)) or belong to the next owner.
    private fun post(block: () -> Unit) { handler.post { if (!released) block() } }

    private fun seconds(name: String): Long = ((double(name) ?: 0.0) * 1000.0).toLong().coerceAtLeast(0L)

    private fun string(name: String): String? = values[name] as? String

    private fun int(name: String): Int? = when (val value = values[name]) {
        is Long -> value.toInt()
        is Int -> value
        is Double -> value.toInt()
        is String -> value.toIntOrNull()
        else -> null
    }

    private fun long(name: String): Long? = when (val value = values[name]) {
        is Long -> value
        is Int -> value.toLong()
        is Double -> value.toLong()
        is String -> value.toLongOrNull()
        else -> null
    }

    private fun double(name: String): Double? = when (val value = values[name]) {
        is Double -> value
        is Long -> value.toDouble()
        is Int -> value.toDouble()
        is String -> value.toDoubleOrNull()
        else -> null
    }

    private companion object {
        const val TAG = "SbPlayerMpv"
        const val MAX_TRACKS = 32
        const val LOAD_TIMEOUT_MS = 25_000L
        const val PROFILE_WAIT_MS = 180L
        const val STALL_TICK_MS = 1_000L
        const val STALL_TICKS = 4
        val SPDIF_FAILURES = listOf("spdif mux error", "libavformat spdif initialization failed", "Failed to create AudioTrack")

        /** A sink that stalled once on a bitstream does so again; PCM for the rest of the process. */
        @Volatile var passthroughBroken = false
    }
}

package dev.streamybox.player.renderclient

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.PixelCopy
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import dev.streamybox.player.render.IRenderCallback
import dev.streamybox.player.render.IRenderService
import org.json.JSONArray
import org.json.JSONObject

/**
 * Plays like Streamarr will: owns the SurfaceView and the overlay, the player process only renders.
 * Extras: url (required), startPositionMs, subtitle (external URL), script (default true), loop (reload on end),
 * muted, debugSpdif (debug player builds: force audio-spdif, e.g. "ac3").
 * Log tag SbRenderClient: EVENT/STEP/CHECK/FAIL lines and "SCRIPT DONE" for scripts/test-render-service.sh.
 */
class RenderClientActivity : Activity(), SurfaceHolder.Callback {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var surfaceView: SurfaceView
    private lateinit var logView: TextView
    private val lines = ArrayDeque<String>()

    private var service: IRenderService? = null
    private var session = 0
    private var surfaceSize: Pair<Int, Int>? = null
    private var surfaceReady = false
    private var loaded = false
    private var url = ""
    private var startMs = 0L
    private var subtitle: String? = null
    private var script = true
    private var loop = false
    private var debugSpdif: String? = null
    private var paused = false
    private var muted = false
    private var positionMs = 0L
    private var durationMs = 0L
    private var endedSeen = false
    private var firstFrames = 0
    private var frameRate = 0f
    private var audioIds = emptyList<Int>()
    private val timeStamps = ArrayDeque<Long>()
    private var maxTimeRate = 0
    private var states = mutableListOf<String>()
    private var replacedSeen = false
    private var externalSeen = false
    private var audioRequested: Int? = null
    private var audioSwitched = false

    private val callback = Callback("primary")

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val remote = IRenderService.Stub.asInterface(binder)
            service = remote
            val api = remote.apiVersion()
            if (api < 1) return fail("apiVersion $api")
            check("apiVersion=$api")
            session = remote.attach(callback)
            if (session <= 0) return fail("attach returned $session")
            check("attached session=$session")
            sendSurface(force = true)
            loadIfReady()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            fail("service disconnected")
            service = null
            session = 0
        }
    }

    private inner class Callback(val tag: String) : IRenderCallback.Stub() {
        override fun onEvent(json: String) {
            main.post { onEvent(tag, json) }
        }
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        url = intent.getStringExtra("url").orEmpty()
        startMs = intent.getLongExtra("startPositionMs", 0L)
        subtitle = intent.getStringExtra("subtitle")
        script = intent.getBooleanExtra("script", true)
        loop = intent.getBooleanExtra("loop", false)
        debugSpdif = intent.getStringExtra("debugSpdif")
        muted = intent.getBooleanExtra("muted", false)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        logView = TextView(this).apply {
            setTextColor(getColor(R.color.client_log_fg))
            setBackgroundColor(getColor(R.color.client_log_bg))
            textSize = 11f
            setPadding(16, 12, 16, 12)
            text = getString(R.string.client_hint)
        }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(surfaceView, FrameLayout.LayoutParams(-1, -1))
        root.addView(logView, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        if (url.isEmpty()) return fail("no url extra")
        val intent = Intent("dev.streamybox.player.RENDER").setPackage("dev.streamybox.player")
        if (packageManager.queryIntentServices(intent, 0).isEmpty()) return fail("render service not resolvable")
        if (!bindService(intent, connection, BIND_AUTO_CREATE)) fail("bindService returned false")
        step("bind")
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        runCatching { service?.detach(session) }
        runCatching { unbindService(connection) }
        super.onDestroy()
    }

    // ---- surface (the client owns the window: size, frame rate) ------------------------------

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceReady = true
        surfaceSize = null
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (surfaceSize == width to height) return
        surfaceSize = width to height
        sendSurface(force = true)
        loadIfReady()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
        surfaceSize = null
        val remote = service ?: return
        val started = SystemClock.elapsedRealtime()
        remote.clearSurface(session)
        step("clearSurface returned after ${SystemClock.elapsedRealtime() - started} ms")
    }

    private fun sendSurface(force: Boolean) {
        val remote = service ?: return
        val size = surfaceSize ?: return
        if (!surfaceReady || !force) return
        remote.setSurface(session, surfaceView.holder.surface, size.first, size.second)
        step("setSurface ${size.first}x${size.second}")
    }

    private fun loadIfReady() {
        val remote = service ?: return
        if (loaded || !surfaceReady || surfaceSize == null) return
        loaded = true
        remote.load(session, url, options(startMs))
        step("load $url start=$startMs")
    }

    private fun options(start: Long): String = JSONObject().apply {
        put("title", "Render client")
        put("startPositionMs", start)
        put("muted", muted)
        debugSpdif?.let { put("debugSpdif", it) }
        subtitle?.let { put("externalSubtitles", JSONArray().put(JSONObject().put("url", it).put("title", "External").put("language", "de"))) }
    }.toString()

    // ---- events -------------------------------------------------------------------------------

    private fun onEvent(tag: String, json: String) {
        val event = JSONObject(json)
        val type = event.optString("type")
        if (type != "time") log("EVENT[$tag] $json") else Log.v(TAG, "EVENT[$tag] $json")
        if (tag != "primary" && tag != "second") return
        when (type) {
            "state" -> {
                states += event.getString("state")
                paused = event.getString("state") == "paused"
            }
            "time" -> {
                positionMs = event.getLong("positionMs")
                durationMs = event.optLong("durationMs", durationMs)
                val now = SystemClock.elapsedRealtime()
                timeStamps.addLast(now)
                while (timeStamps.isNotEmpty() && now - timeStamps.first() >= 1_000) timeStamps.removeFirst()
                maxTimeRate = maxOf(maxTimeRate, timeStamps.size)
            }
            "firstFrame" -> {
                firstFrames++
                check("firstFrame #$firstFrames at state=${states.lastOrNull()}")
                if (script) onFirstFrame()
            }
            "tracks" -> onTracks(event)
            "ended" -> {
                endedSeen = true
                if (loop) {
                    service?.load(session, url, options(0))
                    step("loop: load again")
                }
            }
            "error" -> {
                if (event.optString("reason") == "replaced" && tag == "primary") {
                    replacedSeen = true
                    check("old callback got replaced")
                } else if (event.optString("reason") == "preempted") {
                    check("preempted by PlayerActivity")
                } else if (event.optBoolean("fatal")) {
                    fail("fatal error $json")
                }
            }
        }
    }

    private fun onTracks(event: JSONObject) {
        val audio = event.optJSONArray("audio") ?: JSONArray()
        audioIds = (0 until audio.length()).map { audio.getJSONObject(it).getInt("id") }
        val selected = (0 until audio.length()).map { audio.getJSONObject(it) }.firstOrNull { it.optBoolean("selected") }?.optInt("id")
        if (!audioSwitched && audioRequested != null && selected == audioRequested) {
            audioSwitched = true
            check("audio track $selected selected")
        }
        val subs = event.optJSONArray("subtitles") ?: JSONArray()
        if (!externalSeen && (0 until subs.length()).any { subs.getJSONObject(it).optBoolean("external") }) {
            externalSeen = true
            check("external subtitle listed")
        }
        val video = event.optJSONObject("video") ?: return
        val fps = video.optDouble("frameRate", 0.0).toFloat()
        if (fps > 0 && fps != frameRate && surfaceReady) {
            frameRate = fps
            runCatching { surfaceView.holder.surface.setFrameRate(fps, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE) }
            step("client setFrameRate $fps")
        }
        val width = video.optInt("width")
        val mode = display?.mode
        if (width > 1920 && mode != null && mode.physicalWidth >= 3840) {
            surfaceView.holder.setFixedSize(minOf(mode.physicalWidth, 3840), minOf(mode.physicalHeight, 2160))
        }
    }

    // ---- scripted check (scripts/test-render-service.sh) ---------------------------------------

    private fun onFirstFrame() {
        when (firstFrames) {
            1 -> {
                at(2_000) { service?.pause(session); step("pause") }
                at(3_500) {
                    expectState("paused")
                    val target = seekTarget()
                    service?.seek(session, target)
                    step("seek to $target ms (duration $durationMs ms)")
                }
                at(4_500) { service?.play(session); step("play") }
                at(6_500) { expectState("playing"); service?.setMuted(session, true); step("mute") }
                at(7_000) { service?.setMuted(session, false); service?.setSubtitleTrack(session, -1); step("unmute, subtitles off") }
                at(7_500) {
                    audioIds.lastOrNull()?.takeIf { audioIds.size > 1 }?.let {
                        audioRequested = it
                        service?.setAudioTrack(session, it)
                        step("audio track $it")
                    }
                }
                at(8_500) { step("hide surface"); surfaceView.visibility = View.GONE }
                at(10_500) { expectState("paused"); step("show surface"); surfaceView.visibility = View.VISIBLE }
                at(12_000) { service?.play(session); step("play after surface") }
                at(13_500) { if (shortEnded()) skip("picture before stop") else checkSurface(black = false, "picture before stop") }
                at(14_000) { expectState("playing"); service?.stop(session); step("stop") }
                at(15_000) {
                    expectState("idle")
                    service?.load(session, url, options(0))
                    step("load again")
                }
            }
            2 -> at(3_000) {
                check("time events max/s=$maxTimeRate")
                if (maxTimeRate > 4) fail("time rate $maxTimeRate > 4 Hz")
                val second = Callback("second")
                val next = service?.attach(second) ?: 0
                step("second attach session=$next (old=$session)")
                session = next
                sendSurface(force = true)
                service?.load(session, url, options(startMs))
            }
            3 -> at(2_000) {
                if (!replacedSeen) fail("old callback never got replaced")
                if (subtitle != null && !externalSeen) fail("external subtitle never listed")
                if (audioRequested != null && !audioSwitched) fail("audio track $audioRequested never selected")
                log("SCRIPT DONE")
            }
        }
    }

    /** +15 s, but at most a third into the file so short clips (4–6 s DV fixtures) do not end on the seek. */
    private fun seekTarget(): Long {
        val forward = positionMs + 15_000
        return if (durationMs > 0) minOf(forward, durationMs / 3) else forward
    }

    /** A short file may end before a scripted step; that is the file, not the player. */
    private fun shortEnded() = endedSeen && durationMs in 1 until SHORT_FILE_MS

    private fun expectState(state: String) {
        when {
            states.lastOrNull() == state -> check("state=$state")
            shortEnded() -> skip("state=$state (got ${states.lastOrNull()})")
            else -> fail("expected state $state, got ${states.lastOrNull()}")
        }
    }

    private fun skip(what: String) = log("CHECK skip $what: short file ($durationMs ms) already ended")

    /** Reads the SurfaceView's last queued buffer (only while the player is connected). */
    private fun checkSurface(black: Boolean, what: String) {
        val size = surfaceSize ?: return fail("$what: no surface")
        val bitmap = Bitmap.createBitmap(size.first / 8, size.second / 8, Bitmap.Config.ARGB_8888)
        PixelCopy.request(surfaceView, bitmap, { result ->
            if (result != PixelCopy.SUCCESS) return@request fail("$what: PixelCopy $result")
            var lit = 0
            for (y in 0 until bitmap.height step 4) for (x in 0 until bitmap.width step 4) {
                val p = bitmap.getPixel(x, y)
                if (Color.red(p) + Color.green(p) + Color.blue(p) > 48) lit++
            }
            if ((lit == 0) == black) check("$what (lit samples $lit)") else fail("$what: lit samples $lit")
        }, main)
    }

    private fun at(delayMs: Long, block: () -> Unit) {
        main.postDelayed({ if (!isDestroyed) block() }, delayMs)
    }

    // ---- remote keys --------------------------------------------------------------------------

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val remote = service ?: return super.onKeyDown(keyCode, event)
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ->
                if (paused) remote.play(session) else remote.pause(session)
            KeyEvent.KEYCODE_DPAD_LEFT -> remote.seek(session, (positionMs - 10_000).coerceAtLeast(0))
            KeyEvent.KEYCODE_DPAD_RIGHT -> remote.seek(session, positionMs + 10_000)
            KeyEvent.KEYCODE_MENU -> { muted = !muted; remote.setMuted(session, muted) }
            KeyEvent.KEYCODE_MEDIA_STOP -> { remote.stop(session); step("stop (key)") }
            KeyEvent.KEYCODE_BACK -> { remote.detach(session); finish() }
            else -> return super.onKeyDown(keyCode, event)
        }
        return true
    }

    private fun step(text: String) = log("STEP $text")
    private fun check(text: String) = log("CHECK ok $text")
    private fun fail(text: String) = log("FAIL $text")

    private fun log(text: String) {
        Log.i(TAG, text)
        lines.addLast(text.take(200))
        while (lines.size > 14) lines.removeFirst()
        logView.text = lines.joinToString("\n")
    }

    private companion object {
        const val TAG = "SbRenderClient"
        const val SHORT_FILE_MS = 60_000L
    }
}

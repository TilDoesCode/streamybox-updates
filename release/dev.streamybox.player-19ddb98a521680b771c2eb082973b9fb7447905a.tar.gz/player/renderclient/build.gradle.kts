// Debug-only test client for the embedded RenderService: a second app (own uid) that passes its
// SurfaceView Surface over Binder exactly like Streamarr. Not shipped; see scripts/test-render-service.sh.
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.streamybox.player.renderclient"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.streamybox.player.renderclient"
        minSdk = 34
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures { aidl = true }
    sourceSets["main"].aidl.srcDirs("../app/src/main/aidl")

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

# Third-party notices

The Streamybox Player is GPL-3.0-or-later (see `LICENSE`). It contains or links against:

## mpv-android (MIT)

`app/src/main/java/dev/streamybox/player/mpv/MPVLib.kt`, `MpvView.kt` and
`app/src/main/jni/*` are adapted from
[mpv-android](https://github.com/mpv-android/mpv-android), Copyright (c) 2016 Ilya Zhuravlev and
sfan5 <sfan5@live.de>, MIT licensed. The adapted files keep an origin header. Changes:
Streamybox package/JNI names, option map, queued load with HTTP headers, null-guarded property
events, runtime FFmpeg JNI lookup.

## mpv client API header (ISC)

`app/src/main/jni/include/mpv/client.h` is the mpv client API header, Copyright (C) 2017 the mpv
developers, ISC licensed (text is in the file).

## libmpv, FFmpeg, libplacebo

The prebuilt `libmpv.so`, FFmpeg and libplacebo shared libraries are **not** in this repository;
`player/scripts/sync-mpv-libs.sh` copies them from the dv-mpv AAR
(`$SB_WORK/dv-mpv/out/libmpv-arm64-hdr-dv.aar`, dv-mpv phase-2 commit `84ccb238`). Their licences are determined
by that build (libmpv is GPLv2+ unless built with `-Dgpl=false`; FFmpeg and libplacebo have their
own LGPL/GPL options). Ship the corresponding source archive with any APK that contains them.

## Inter (SIL OFL 1.1)

The shared `design` module bundles the Inter variable font
(`design/src/main/assets/fonts/Inter.ttf`, `Inter-OFL.txt`).

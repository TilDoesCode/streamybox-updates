#!/usr/bin/env bash
# Copy the dv-mpv arm64 libmpv tree into the player's jniLibs.
# Usage: scripts/sync-mpv-libs.sh [OUT_DIR]
# Default OUT_DIR: $DV_MPV_OUT or /Volumes/DevSSD/Development/streamybox-work/dv-mpv/out
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEFAULT_AAR="/Volumes/DevSSD/Development/streamybox-work/dv-mpv/out/libmpv-arm64-hdr-dv-spdif.aar"
SRC="${1:-${DV_MPV_OUT:-$DEFAULT_AAR}}"
DEST="$ROOT/app/src/main/jniLibs/arm64-v8a"
TMP=""

if [[ -f "$SRC" && "$SRC" == *.aar ]]; then
    TMP="$(mktemp -d)"
    unzip -q "$SRC" 'jni/arm64-v8a/*.so' -d "$TMP"
    SRC="$TMP/jni/arm64-v8a"
elif [[ -f "$SRC" && "$SRC" == *.so ]]; then
    TMP="$(mktemp -d)"
    cp -L "$SRC" "$TMP/libmpv.so"
    SRC="$TMP"
fi
if [[ ! -d "$SRC" ]]; then
    echo "error: libmpv AAR/out directory not found: $SRC" >&2
    echo "       build feat/dv-mpv first or pass an .aar / directory as the first argument" >&2
    exit 1
fi

mkdir -p "$DEST"
rm -f "$DEST"/*.so 2>/dev/null || true

count=0
while IFS= read -r file; do
    case "$file" in
        *armeabi-v7a*|*x86_64*|*x86/*|*/x86/*|*i686*) continue ;;
        */libplayer.so) continue ;; # our own JNI bridge, built by CMake
    esac
    cp -L "$file" "$DEST/$(basename "$file")"
    count=$((count + 1))
done < <(find "$SRC" -type f -name '*.so' | sort)

if [[ ! -f "$DEST/libc++_shared.so" ]]; then
    STL="$(find "${ANDROID_HOME:-$HOME/Library/Android/sdk}/ndk" -path '*/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so' 2>/dev/null | sort -V | tail -1)"
    if [[ -n "$STL" && -f "$STL" ]]; then
        cp "$STL" "$DEST/libc++_shared.so"
        echo "added NDK libc++_shared.so (required by the AAR libmpv)"
    fi
fi

if [[ ! -f "$DEST/libmpv.so" ]]; then
    echo "error: libmpv.so was not found below $SRC" >&2
    echo "       expected out/lib/libmpv.so or out/libmpv.so" >&2
    exit 1
fi

[[ -n "$TMP" ]] && echo "extracted from $(basename "$1" 2>/dev/null || true)"
echo "copied $count library file(s) to $DEST"
ls -lh "$DEST"/libmpv.so "$DEST"/*.so 2>/dev/null | sed 's/^/  /'

READELF="$(find "${ANDROID_HOME:-$HOME/Library/Android/sdk}/ndk" -path '*/toolchains/llvm/prebuilt/*/bin/llvm-readelf' 2>/dev/null | sort -V | tail -1)"
if [[ -x "$READELF" ]]; then
    echo "libmpv dependencies:"
    "$READELF" -d "$DEST/libmpv.so" | awk '/NEEDED/ {gsub(/\[|\]/, "", $5); print "  " $5}'
fi

echo
echo "Now build and install:"
echo "  cd $ROOT && ./gradlew assembleRelease"
echo "  scripts/install-player.sh"

#!/usr/bin/env bash
# Build and install the Streamybox Player on the ROCK 4D (or any userdebug device).
# Usage: ANDROID_SERIAL=100.117.41.108:5555 scripts/install-player.sh [--no-build] [--url URL]
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."
export ANDROID_SERIAL="${ANDROID_SERIAL:-100.117.41.108:5555}"
source ../scripts/env.sh

BUILD=1
DEBUG=0
URL=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-build) BUILD=0; shift ;;
        --debug) DEBUG=1; shift ;;
        --url) URL="${2:-}"; shift 2 ;;
        *) echo "unknown argument: $1" >&2; exit 2 ;;
    esac
done

if [[ "$DEBUG" == 1 ]]; then
    [[ "$BUILD" == 1 ]] && ./gradlew :app:assembleDebug
    APK="$PWD/app/build/outputs/apk/debug/app-debug.apk"
else
    [[ "$BUILD" == 1 ]] && ./gradlew :app:assembleRelease
    APK="$PWD/app/build/outputs/apk/release/app-release.apk"
fi
[[ -f "$APK" ]] || { echo "error: $APK not found" >&2; exit 1; }

if ! lockf -t 1800 "$SB_LOCK_FILE" "$ADB" -s "$ANDROID_SERIAL" install -r -g "$APK"; then
    echo "install failed. A debug-signed build on the box needs one uninstall:" >&2
    echo "  adb -s $ANDROID_SERIAL uninstall dev.streamybox.player" >&2
    exit 1
fi
if [[ -n "$URL" ]]; then
    lockf -t 1800 "$SB_LOCK_FILE" "$ADB" -s "$ANDROID_SERIAL" shell am start \
        -a dev.streamybox.player.PLAY \
        --es url "$URL" \
        --es title "Stream" \
        -n dev.streamybox.player/.PlayerActivity
else
    lockf -t 1800 "$SB_LOCK_FILE" "$ADB" -s "$ANDROID_SERIAL" shell am start -n dev.streamybox.player/.MainActivity
fi
echo "installed $APK on $ANDROID_SERIAL"

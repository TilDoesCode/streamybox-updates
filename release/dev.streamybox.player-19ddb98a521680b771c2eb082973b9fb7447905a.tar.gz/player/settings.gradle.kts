pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "streamybox-player"
include(":app", ":renderclient", ":design", ":remote-contract")
project(":design").projectDir = file("../design")
project(":remote-contract").projectDir = file("../remote-contract")

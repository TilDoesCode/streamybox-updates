# Streamybox Player

Native TV player for the Streamybox box (`dev.streamybox.player`). It is the C work package
(`docs/57-software-dv-player.md`): D-pad UI, intent handoff, resume, tracks and the libmpv
renderer that will tone map Dolby Vision with libplacebo.

## Status

| Part | State |
| --- | --- |
| TV UI (open screen, player chrome, settings) | real, installable |
| D-pad, media keys, auto-hide, resume prompt | real |
| `ACTION_VIEW video/*` and `dev.streamybox.player.PLAY` | real, validated, unit tested |
| Embedded renderer `RenderService` (client Surface over Binder, contract v1) | real; emulator-tested, box re-test open (`docs/59`) |
| libmpv options (`gpu-next`, `gpu-context=android`, `target-colorspace-hint`, …) | real mapping, tested |
| JNI bridge (`MPVLib`, `BaseMPVView`, `MPVView`, `cpp/`) | real, GPL source |
| libmpv / FFmpeg / libplacebo binaries | supplied by `feat/dv-mpv`; not in git |
| Playback without binaries | `MissingEngine`: visible renderer error, no fake video |
| DV P8.1 1080p24/4K24 zero-copy + SDR tone mapping | verified on the box with B's phase-2 AAR |
| DV P5 copy-back + SDR tone mapping | verified; zero-copy is deliberately disabled for P5 |
| HDR10 output | verified on boxes with the patched HWC (`dev.streamybox.hdr10_rgb`), SDR tone mapping otherwise |

## Build

```bash
source scripts/env.sh
cd player
./gradlew :app:assembleRelease :app:testDebugUnitTest
```

APK: `player/app/build/outputs/apk/release/app-release.apk` (arm64-v8a, minSdk 34, targetSdk 34).
Package: `dev.streamybox.player`. The app includes `:design` and `:remote-contract`, so it looks
like launcher/settings and follows the shared motion/light rules.

The shared `gradle/streamybox-release.gradle` sets `versionCode`/`versionName` from
`gradle/streamybox-version.properties` and signs every build type with the Streamybox release key
(`$SB_WORK/keys/streamybox-release.properties` or `STREAMYBOX_SIGNING_PROPERTIES`). A release
install over the old debug-signed build needs one `adb uninstall dev.streamybox.player` first;
`scripts/install-player.sh` prints that hint when the signature changes.

Install on the ROCK 4D:

```bash
cd player
ANDROID_SERIAL=100.117.41.108:5555 scripts/install-player.sh
# debug build for on-box testing with run-as:
ANDROID_SERIAL=100.117.41.108:5555 scripts/install-player.sh --debug
```

The script builds, installs and starts the open screen. It uses `lockf` and never touches
partitions or the bootloader.

## UI

* **Open screen** (`MainActivity`): stream/file address with the shared inline `TextField`, play
  and settings actions, "Continue watching" from the local resume store, renderer status warning.
* **Player** (`PlayerActivity` + `ui/PlayerScreen`): title, host, HDR/DV/resolution/fps/HW badges,
  progress line, position/duration, −10 s / play-pause / +10 s, audio, subtitles, info, settings,
  close. Controls hide after 4.5 s while playing; any key brings them back. With controls hidden,
  left/right seek ±10 s and a short HUD shows the target time. Back hides controls, then exits.
* **Resume prompt** before opening a stream with a saved position (30 s … duration−15 s).
* **Error/loading/buffering/ended** states are part of the same screen; the error state is also
  what the app shows honestly when `libmpv` is not packaged.
* **Settings** (`SettingsActivity`): HDR mode, hardware decode, network cache, resume, HDMI
  passthrough, audio/subtitle language, subtitle mode, engine/license info.

German and English strings live in `app/src/main/res/values*/strings.xml`. Dark is the player
default; open/settings follow the launcher's light preference via `SharedState`.

## Intent contract

Jellyfin (or any other app) can hand a stream to the player:

```kotlin
val intent = Intent("dev.streamybox.player.PLAY").apply {
    setPackage("dev.streamybox.player")
    putExtra("url", streamUrl)                       // required
    putExtra("headers", arrayOf(                     // optional
        "Authorization: MediaBrowser Token=\"…\"",
        "X-Emby-Token: …",
    ))
    putExtra("start_position_ms", 125_000L)           // optional, milliseconds
    putExtra("title", "Blade Runner 2049")            // optional
}
startActivity(intent)
```

| Extra | Type | Meaning |
| --- | --- | --- |
| `url` | `String` | `http(s)`, `file`, `content` (Jellyfin/HTTP is the main path). Also accepts `Intent.data` for `ACTION_VIEW`. |
| `headers` | `String[]` or `String` | `Name: value` lines. A single string may contain CRLF/LF separated lines. Names are HTTP tokens, values must not contain CR/LF/NUL. Max 32 headers. |
| `start_position_ms` | `long` or numeric `String` | Start position in ms, clamped to `0..7 days`. |
| `title` | `String` | Display title; otherwise derived from the URL path. |

`ACTION_VIEW` with `video/*` works the same way for file managers and Jellyfin's external-player
setting. `android.intent.extra.TITLE` and `android.intent.extra.START_POSITION` are accepted as
fallbacks. `javascript:`, `data:` and unknown schemes are rejected before they reach mpv.

Example:

```bash
adb shell am start -a dev.streamybox.player.PLAY \
  --es url 'https://example.test/movie.mkv' \
  --es title 'Movie' \
  --el start_position_ms 120000 \
  -n dev.streamybox.player/.PlayerActivity
```

## Embedded renderer (`RenderService`, contract v1)

Streamarr keeps its own UI and overlay and lets the player render only the video plane: the client owns a
`SurfaceView`, passes its `Surface` over Binder and the player process draws mpv into it (DV P8.x zero-copy,
P5 copy-back, HDR10 dataspace on the surface when `dev.streamybox.hdr10_rgb`, SDR tone mapping otherwise).
Binding contract: `$SB_WORK/dv-player/embedded-contract.md`; the AIDL files are
`app/src/main/aidl/dev/streamybox/player/render/I{RenderService,RenderCallback}.aidl` — copy them verbatim
(they need `import android.view.Surface;`).

```kotlin
val intent = Intent("dev.streamybox.player.RENDER").setPackage("dev.streamybox.player")
bindService(intent, connection, Context.BIND_AUTO_CREATE)     // manifest: <queries><package …player/></queries>
val session = service.attach(callback)                          // > 0
service.setSurface(session, holder.surface, width, height)      // surfaceCreated / real size change
service.load(session, url, """{"startPositionMs":120000,"headers":["X-Emby-Token: …"]}""")
// surfaceDestroyed: service.clearSurface(session) — returns once mpv has left the surface (≤ 1 s)
```

| Call | Behaviour |
| --- | --- |
| `apiVersion()` | `1` |
| `attach(cb)` | new session id; a previous session gets `{"type":"error","reason":"replaced","fatal":true}` and is torn down. `linkToDeath` on `cb`: a dead client stops, detaches and releases mpv. |
| `setSurface` | attaches the surface (`android-surface-size` = width×height). A second call re-attaches (brief VO re-init), so only call it on create or a real size change. |
| `clearSurface` | pauses, releases the VO/EGL surface and the `ANativeWindow`, then returns. `setSurface` again shows the paused frame; the client calls `play()`. |
| `load(url, json)` | `http`/`https`/`content`/`file` only (not the player's own data dir). Options: `title`, `startPositionMs`, `headers` (`Name: value`, max 32), `muted`, `audioTrack`, `subtitleTrack` (`-1` off), `externalSubtitles` `[{url,title,language}]` (max 16, async `sub-add`). Plays as soon as the first frame is ready. Invalid input → `error` `invalid_url`/`invalid_options`. |
| `play`/`pause`/`seek(ms)` | exact seek |
| `setAudioTrack`/`setSubtitleTrack` | mpv `aid`/`sid` from the `tracks` event, `-1` = subtitles off |
| `setMuted`, `stop`, `detach` | muted always means PCM (bitstream ignores mute; switches without reload); `stop` releases mpv and the decoders, the session stays; `detach` ends it |
| end of playback | `stop`, `ended`, a fatal `error`, `detach`, `replaced` and `preempted` release mpv and queue one black SDR frame into the surface, so the box leaves HDR while the client's UI stays; the next `load` renders into the same surface again |

Calls with a stale session id or from another uid than the one that attached are ignored. Events (JSON):
`state` (`idle|loading|playing|paused|buffering|ended|error`), `time` (`positionMs`, `durationMs`,
`bufferedMs` = absolute buffered position, ≤ 4 Hz), `buffering`, `firstFrame` (once per load, after the
start-position seek, only with a surface), `tracks` (`audio` with `output` = `passthrough:<codec>`\|`pcm:<channels>` since 1.5.6, `subtitles`, `video{width,height,codec,frameRate,
range,dolbyVisionProfile?,dolbyVision?,output,hwdec}`, settled 100 ms after mpv changes; `dolbyVision:true` also
for files without a DOVI config record, sent in a second `tracks` event once decoded frames show DV, the profile
number then stays absent), `stats` (every 2 s and on hwdec
changes), `ended`, `error` (`reason`, `fatal`, `status?` HTTP code, `message?` mpv detail). Error reasons:
`load_failed`, `invalid_url`, `invalid_options`, `engine_unavailable`, `replaced`, `preempted`.

**Display duties of the client** (the player has no window): `Surface.setFrameRate(tracks.video.frameRate,
FRAME_RATE_COMPATIBILITY_FIXED_SOURCE)` and/or `preferredDisplayModeId`; for video wider than 1920 on a 4K
display `holder.setFixedSize(3840, 2160)` and `setSurface` with the new size, like `RenderSize` does for the
activity. HDR10 needs nothing from the client: mpv sets `BT2020_PQ` on the surface's buffers, and the player
puts an SDR frame there when playback ends. A client that draws its own content into the SurfaceView must
`detach` (or `stop`) first.

**One mpv per process:** `MpvOwner` hands mpv to the newest user. A service `load` makes a playing
`PlayerActivity` release mpv and finish; starting `PlayerActivity` sends the session
`{"type":"error","reason":"preempted","fatal":true}`.

Test client: `renderclient/` (debug-only app `dev.streamybox.player.renderclient`, own uid, same AIDL), driven by
`scripts/test-render-service.sh` in the repo root; see `docs/59-player-embedded-render.md`.

## libmpv integration

`feat/dv-mpv` delivers
`$SB_WORK/dv-mpv/out/libmpv-arm64-hdr-dv.aar` (2026-10-28, 37,218,841 bytes, SHA-256
`ef591e4b…b3ac5`, dv-mpv phase-2 commit `84ccb238`; libmpv 0.41 + FFmpeg + libplacebo +
headers). The sync script accepts the AAR, a directory, or a single `libmpv.so` (binary,
git-ignored):

```bash
cd player
scripts/sync-mpv-libs.sh
# explicit: scripts/sync-mpv-libs.sh /path/to/libmpv-arm64-hdr-dv.aar
```

The script populates `app/src/main/jniLibs/arm64-v8a/` with `libmpv.so`, FFmpeg, libplacebo,
their dependencies and the NDK `libc++_shared.so` the AAR requires. `app/build.gradle.kts` detects
`libmpv.so` and then configures `externalNativeBuild`, which compiles:

* `app/src/main/jni/{main,render,property,event,jni_utils,log}.cpp` → `libplayer.so`
* `app/src/main/jni/include/mpv/client.h` (vendored ISC header)

**Exact integration point:** `dev.streamybox.player.mpv.MPVLib` + `MpvView` +
`app/src/main/jni`. Everything above it is `PlayerEngine` (`MpvEngine`), so the UI never talks to
JNI directly. To change the renderer, replace the native bridge/libs but keep the
`PlayerEngine` contract. Our `libplayer.so` is still built from this repo because the JNI symbol
prefix is `Java_dev_streamybox_player_mpv_MPVLib_*`.

### Player options

`MpvOptions` (unit tested) sets, among others:

```
vo=gpu-next
gpu-api=opengl
gpu-context=android
hwdec=mediacodec            # zero-copy for P8/non-DV; P5 switches to mediacodec-copy
egl-output-format=rgb10_a2
target-colorspace-hint=yes
android-hdr=no              # SDR verified; yes = experimental HDR10 request
tone-mapping=bt.2390
hdr-compute-peak=yes
audio-spdif=<probed>        # passthrough=Automatic, see below
cache=yes / demuxer-max-bytes=192MiB
save-position-on-quit=no     # the app owns resume, per URL
```

HDR modes: **Automatic (SDR)** uses `android-hdr=no`, `target-colorspace-hint=yes` and libplacebo
tone mapping to the SDR surface. **SDR** forces the same target; **HDR10 (experimental)** sets
`android-hdr=yes`, but the RK3576 HWC does not switch its HDMI output for RGB/GL layers, so the app
labels the actual output SDR.

Hardware decode follows B's phase-2 policy: **P8.1/P8.4/non-DV use `mediacodec` zero-copy**;
**P5 uses `mediacodec-copy`** automatically (never the OES zero-copy path, which turns P5 blue).
The profile is read at file-loaded while playback is paused behind the black loading screen; a
late profile triggers one copy-back reload before the first visible frame. The settings also offer
manual copy-back and software decode. MediaCodec PTS failures fall back to software once.

The JNI bridge is adapted from mpv-android (MIT). Modifications and the player itself are
GPL-3.0-or-later; see `LICENSE` and `THIRD-PARTY.md`.

**Audio passthrough (Automatic, since 1.5.6).** Surround on a sink whose LPCM is stereo only works as bitstream.
`audio-spdif` is set per load for the codecs the routed output takes (`PassthroughProbe`/`PassthroughPolicy`):

| Codec | Needs | IEC 61937 frames |
| --- | --- | --- |
| AC-3 | digital route, HAL direct AC3/IEC, EDID AC-3 (or no EDID known) | 2 ch, 48 kHz |
| E-AC-3 incl. JOC (Atmos) | as above with E-AC-3 | 2 ch, 192 kHz |
| TrueHD incl. Atmos | EDID TrueHD/MLP **and** IEC 8 ch 192 kHz | 8 ch (7.1), 192 kHz |
| DTS / DTS-HD | EDID DTS / DTS-HD (never without EDID) | 2 ch 48 kHz / 8 ch 192 kHz |

EDID sources, in order: `AudioDeviceInfo.getAudioDescriptors()`, Settings.Global `streamybox_hdmi_audio_sads`
(hex SADs written by the OS HDMI guard, `device/rock4d/hdmi`; apps cannot read the EDID on this BSP). Bare
`AudioDeviceInfo.getEncodings()` is not trusted (it can mirror the HAL's static profile, incl. DTS).
Muted playback is always PCM (a bitstream ignores volume and mute); `setMuted` switches at runtime by changing
`audio-spdif`, which only reinitialises mpv's audio chain. A bitstream that stalls 4 s, or an IEC AudioTrack that
cannot be opened, falls back to PCM for the rest of the process. Native side: FFmpeg `spdif` muxer and mpv patch
`0002-ao-audiotrack-iec61937-hbr` (192 kHz IEC rate, 7.1 IEC tracks for TrueHD/DTS-HD MA).

## Tests

```bash
cd player
./gradlew :app:testDebugUnitTest
```

Covers URL/header/position validation, time formatting, HDR/DV badge detection, the mpv option
mapping and the render contract (JSON, load options, event mapping/throttling, sessions, first-frame gate,
mpv ownership). On-device checks are in `docs/58-player-app.md` (`## Box re-test`).

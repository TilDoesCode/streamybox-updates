# Streamybox Player — corresponding source

* Package: `dev.streamybox.player`, Streamybox 1.6.1 (10033)
* Commit: `19ddb98a521680b771c2eb082973b9fb7447905a` (also in `SOURCE_COMMIT`)
* Licence: GPL-3.0, see `LICENSE`. GPL-3.0 player. Its native core is GPL-3.0-or-later: mpv, FFmpeg (--enable-gpl --enable-version3), libplacebo and the pinned release tarballs are recorded in device/rock4d/player/native-sources.json (see NOTICE.md).

Every file is unchanged from that commit, except `player/settings.gradle.kts`, which lists only the
modules this app is built from.

## Build

Requirements: JDK 17 or newer, Android SDK with platform 36 and build-tools 36.0.0 (`ANDROID_HOME`).

1. Create your own PKCS12 signing key and a properties file:
   `storeFile=/path/key.p12`, `storePassword=…`, `keyAlias=streamybox` (optional `keyPassword=…`).
2. Put the SHA-256 fingerprint of your certificate into `device/rock4d/store/streamybox-repo.json`
   (`fingerprint`); the build refuses any other certificate.
3. `cd player && STREAMYBOX_SIGNING_PROPERTIES=/path/key.properties ./gradlew :app:assembleRelease`

Output: `player/app/build/outputs/apk/release/app-release.apk`.

## Native core

The APK ships `libmpv.so` and FFmpeg's shared libraries. Their complete corresponding source is in `third_party/`:
every pinned checkout, release tarball and patch, the build script `third_party/player-native-build.sh` and
`third_party/PLAYER-NATIVE.md` (pins, licences, FFmpeg configuration). The same data is machine-readable in
`device/rock4d/player/native-sources.json`.

1. Unpack the checkouts and tarballs into the paths named in `PLAYER-NATIVE.md`, apply `third_party/patches/`
   in the listed order and run the build script. It writes `libmpv-arm64-hdr-dv-spdif.aar`.
2. `player/scripts/sync-mpv-libs.sh /path/libmpv-arm64-hdr-dv-spdif.aar` copies the libraries into
   `player/app/src/main/jniLibs/arm64-v8a`; the build below packages them.

The shipped libraries come from the AAR with SHA-256 `09c6c2a41c638e7996e928607461931669df4ea668d2fd83603ee83bb26c3ada` (37240170 bytes).

## Install a modified version

APKs signed with another key cannot update the shipped app. Change `applicationId` in
`player/app/build.gradle.kts` and install your build alongside. Streamybox boxes are userdebug builds with `adb root`, so the system copy (`/product/app/StreamyboxPlayer`) can also be replaced.

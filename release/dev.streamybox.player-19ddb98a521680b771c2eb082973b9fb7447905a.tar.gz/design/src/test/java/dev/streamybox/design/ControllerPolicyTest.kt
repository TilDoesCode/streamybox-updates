package dev.streamybox.design

import org.junit.Assert.*
import org.junit.Test

class ControllerPolicyTest {
    @Test fun rejectVirtualRemotesAndKeyboardBits() {
        assertFalse(ControllerIdentity.eligible(true, true, true, true, true))
        assertFalse(ControllerIdentity.eligible(false, true, false, false, true))
        assertFalse(ControllerIdentity.eligible(false, true, false, true, false))
        assertFalse(ControllerIdentity.eligible(false, false, false, true, true))
        assertTrue(ControllerIdentity.eligible(false, true, true, true, true))
    }
    @Test fun identifyRequestedVendors() {
        assertEquals("Xbox Series", ControllerIdentity.model(0x045e, 0x0b13, "").name)
        assertEquals("DualSense", ControllerIdentity.model(0x054c, 0x0ce6, "").name)
        assertEquals("DualShock 4", ControllerIdentity.model(0x054c, 0x09cc, "").name)
        assertEquals(ControllerIdentity.Brand.SWITCH, ControllerIdentity.model(0x057e, 0x2009, "").brand)
        assertEquals(ControllerIdentity.Brand.EIGHTBITDO, ControllerIdentity.model(0x2dc8, 0, "").brand)
        assertEquals(ControllerIdentity.Brand.GENERIC, ControllerIdentity.model(0, 0, "USB pad").brand)
    }
    @Test fun filterClassicAndBleWithoutHeadphonesOrRemotes() {
        assertTrue(ControllerIdentity.bluetoothCandidate("Xbox Wireless Controller", 0))
        assertTrue(ControllerIdentity.bluetoothCandidate(null, 0x508))
        assertTrue(ControllerIdentity.bluetoothCandidate(null, 0, 0x03c4))
        assertFalse(ControllerIdentity.bluetoothCandidate("TV remote", 0x540))
        assertFalse(ControllerIdentity.bluetoothCandidate("Headphones", 0x404))
        assertFalse(ControllerIdentity.bluetoothCandidate("Xbox Wireless Headset", 0x404))
    }
    @Test fun stickDeadZoneHysteresisAndDominantDirection() {
        assertEquals(0, StickDirection.key(.29f, 0f, false))
        assertEquals(android.view.KeyEvent.KEYCODE_DPAD_RIGHT, StickDirection.key(.29f, 0f, true))
        assertEquals(0, StickDirection.key(.17f, 0f, true))
        assertEquals(android.view.KeyEvent.KEYCODE_DPAD_UP, StickDirection.key(.4f, -.8f, false))
    }
    @Test fun stableSlotsAndOverflowPromotion() {
        val s = PlayerSlots()
        assertEquals(mapOf("a" to 1, "b" to 2), s.update(listOf("a", "b")))
        assertEquals(mapOf("b" to 2, "c" to 1), s.update(listOf("b", "c")))
        assertEquals(0, s.update(listOf("b", "c", "d", "e", "f"))["f"])
        assertEquals(2, s.update(listOf("c", "d", "e", "f"))["f"])
    }
}

package dev.streamybox.design

import org.junit.Assert.assertEquals
import org.junit.Test

class NetworkTransportTest {
    @Test fun ethernetWinsAndOfflineIsExplicit() {
        assertEquals(NetworkTransport.ETHERNET, NetworkTransport.of(connected = true, ethernet = true, wifi = false))
        assertEquals(NetworkTransport.ETHERNET, NetworkTransport.of(connected = true, ethernet = true, wifi = true))
        assertEquals(NetworkTransport.WIFI, NetworkTransport.of(connected = true, ethernet = false, wifi = true))
        assertEquals(NetworkTransport.OTHER, NetworkTransport.of(connected = true, ethernet = false, wifi = false))
        assertEquals(NetworkTransport.OFFLINE, NetworkTransport.of(connected = false, ethernet = true, wifi = true))
    }
    @Test fun glyphsFollowTransport() {
        assertEquals(Glyph.Kind.ETHERNET, NetworkTransport.ETHERNET.glyph)
        assertEquals(Glyph.Kind.WIFI, NetworkTransport.WIFI.glyph)
        assertEquals(Glyph.Kind.OFFLINE, NetworkTransport.OFFLINE.glyph)
    }
}

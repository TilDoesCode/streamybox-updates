package dev.streamybox.design

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Rect
import android.os.Build
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout

/** Inline text field row (label, plain EditText, reason line) living in the page itself; OK opens the system keyboard in place. */
class TextField(private val ui: TvDesign, label: String, hint: String = "", private val secret: Boolean = false, value: String = "") : LinearLayout(ui.context) {
    enum class Action(val id: Int) { DONE(EditorInfo.IME_ACTION_DONE), GO(EditorInfo.IME_ACTION_GO), SEARCH(EditorInfo.IME_ACTION_SEARCH), NEXT(EditorInfo.IME_ACTION_NEXT) }
    /** Returns why a value cannot be submitted; the field then keeps the keyboard and shows the reason under it. */
    var check: ((String) -> String?)? = null
    /** Called with the value when the keyboard's action key (or a real keyboard's Enter) is used. */
    var onSubmit: ((String) -> Unit)? = null
    /** Called after every change, e.g. for live search. */
    var onChange: ((String) -> Unit)? = null
    /** Field that [Action.NEXT] moves to; the keyboard stays open. */
    var next: TextField? = null
    private val imm get() = context.getSystemService(InputMethodManager::class.java)
    private val caption = ui.text(label, 12.5f, ui.muted, weight = 500).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; if (label.isEmpty()) visibility = View.GONE }
    private val reason = ui.text("", 12.5f, ui.danger, weight = 500).apply { visibility = View.GONE; setPadding(0, ui.dp(6f), 0, 0) }
    private val edge = ui.dp(11f)
    private var pending = false
    private var typed = false
    val editor: EditText = Input()
    val text: String get() = editor.text.toString()

    init {
        orientation = VERTICAL; gravity = Gravity.CENTER_VERTICAL; minimumHeight = ui.dp(54f); clipChildren = false
        // The row's bottom edge lives in the editor's padding: the keyboard pan follows the editor, so the whole row stays visible.
        setPadding(ui.dp(20f), edge, ui.dp(16f), 0); setAddStatesFromChildren(true)
        // Focusable so page code that focuses rows finds it; focus always lands on the EditText inside.
        isFocusable = true; descendantFocusability = FOCUS_AFTER_DESCENDANTS
        addView(caption, LayoutParams(-1, -2).apply { bottomMargin = ui.dp(6f) })
        addView(editor, LayoutParams(-1, -2))
        addView(reason, LayoutParams(-1, -2))
        editor.apply {
            id = View.generateViewId(); background = null; setPadding(0, 0, 0, edge); minHeight = ui.dp(26f) + edge
            textSize = 17f * ui.scale; includeFontPadding = false; isSingleLine = true
            setTextColor(ui.foreground); setHintTextColor(ui.faint); this.hint = hint; gravity = Gravity.CENTER_VERTICAL or Gravity.START
            textCursorDrawable = ui.shape(ui.accent, 1f).apply { setSize(ui.dp(2f), -1) }
            highlightColor = android.graphics.Color.argb(80, android.graphics.Color.red(ui.accent), android.graphics.Color.green(ui.accent), android.graphics.Color.blue(ui.accent))
            inputType = InputType.TYPE_CLASS_TEXT or if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            // After inputType: a password variation would otherwise switch the field to monospace.
            typeface = Fonts.get(context, 500)
            action(Action.DONE)
            setText(value); setSelection(value.length)
            setOnEditorActionListener { _, action, event ->
                when {
                    event == null -> { if (action == EditorInfo.IME_ACTION_NEXT && next != null) advance() else submit(); true }
                    event.keyCode != KeyEvent.KEYCODE_ENTER && event.keyCode != KeyEvent.KEYCODE_NUMPAD_ENTER -> false
                    // TextView only reports the release of an Enter press it saw, so stray releases never submit.
                    event.action == KeyEvent.ACTION_UP -> { submit(); true }
                    else -> true
                }
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) { problem(null); onChange?.invoke(s?.toString().orEmpty()) }
            })
        }
        setTag(R.id.sb_item, true)
        ui.style(this, FocusStyle(ui.raised, if (ui.light) ui.border else null, ui.raisedFocus, ui.radii(TvDesign.RADIUS_M), 1f, ui.softRing))
    }

    /** Sets the keyboard's action key; [label] replaces its default text (e.g. "Verbinden"). */
    fun action(action: Action, label: String? = null) {
        editor.imeOptions = action.id or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
        editor.setImeActionLabel(label, if (label == null) 0 else action.id)
    }
    fun setText(value: String) { editor.setText(value); editor.setSelection(editor.text.length) }
    /** Focuses the field and opens the keyboard once; a missed show waits for window focus instead of retrying. */
    fun edit() {
        if (!editor.isFocused) editor.requestFocus()
        pending = true
        editor.post(::show)
    }
    fun close() { pending = false; imm.hideSoftInputFromWindow(editor.windowToken, 0) }
    /** Shows [text] under the field (null hides it). */
    fun problem(text: String?) {
        reason.text = text.orEmpty(); reason.visibility = if (text == null) View.GONE else View.VISIBLE
        // The reason is drawn over the editor's bottom padding too, so the keyboard pan keeps it visible.
        val room = edge + if (text == null) 0 else reason.run { measure(MeasureSpec.makeMeasureSpec(editor.width, if (editor.width > 0) MeasureSpec.AT_MOST else MeasureSpec.UNSPECIFIED), MeasureSpec.UNSPECIFIED); measuredHeight }
        if (editor.paddingBottom != room) { editor.setPadding(0, 0, 0, room); reason.layoutParams = (reason.layoutParams as LayoutParams).apply { topMargin = -room } }
        if (text != null) editor.post { editor.bringPointIntoView(editor.selectionEnd.coerceAtLeast(0)) }
    }

    private fun show() {
        if (!pending || !editor.isAttachedToWindow || !editor.isFocused || !editor.hasWindowFocus()) return
        pending = false
        imm.showSoftInput(editor, 0)
    }
    private fun submit() {
        val value = text
        val why = check?.invoke(value)
        problem(why)
        if (why != null) return
        close(); onSubmit?.invoke(value)
    }
    private fun advance() { val target = next ?: return; if (check?.invoke(text)?.also { problem(it) } != null) return; target.edit() }
    private fun keyboardUp() = Build.VERSION.SDK_INT >= 30 && editor.rootWindowInsets?.isVisible(WindowInsets.Type.ime()) == true

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // The keyboard covers the lower part of the screen; the page pans so this field stays above it.
        activity(context)?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
    }
    // Pages link rows by id; the EditText inside follows the same links.
    override fun setNextFocusUpId(id: Int) { super.setNextFocusUpId(id); editor.nextFocusUpId = id }
    override fun setNextFocusDownId(id: Int) { super.setNextFocusDownId(id); editor.nextFocusDownId = id }
    override fun setNextFocusLeftId(id: Int) { super.setNextFocusLeftId(id); editor.nextFocusLeftId = id }
    override fun setNextFocusRightId(id: Int) { super.setNextFocusRightId(id); editor.nextFocusRightId = id }
    private fun activity(context: Context?): Activity? = when (context) { is Activity -> context; is ContextWrapper -> activity(context.baseContext); else -> null }

    private inner class Input : EditText(ui.context) {
        private var okDown = false
        private var enterDown = false
        private fun ok(code: Int) = code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER || code == KeyEvent.KEYCODE_BUTTON_A
        private fun enter(code: Int) = code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER
        private fun arrow(code: Int) = code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT || code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN
        // A real keyboard that typed here keeps its Enter; remote OK and controller A open the keyboard instead.
        private fun opens(code: Int) = ok(code) && !keyboardUp() && !(typed && code != KeyEvent.KEYCODE_DPAD_CENTER && code != KeyEvent.KEYCODE_BUTTON_A)
        override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
            if (opens(keyCode)) { if (event.repeatCount == 0) okDown = true; return true }
            if (arrow(keyCode) && !keyboardUp()) return false
            if (event.isPrintingKey) typed = true
            if (enter(keyCode)) enterDown = true
            return super.onKeyDown(keyCode, event)
        }
        override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
            if (ok(keyCode) && okDown) { okDown = false; if (!event.isCanceled) edit(); return true }
            if (enter(keyCode) && enterDown) { enterDown = false; return super.onKeyUp(keyCode, event) }
            // The keyboard forgets its OK press when it closes; that release must not reopen it or move focus.
            if (ok(keyCode)) return true
            if (arrow(keyCode) && !keyboardUp()) return false
            return super.onKeyUp(keyCode, event)
        }
        override fun onFocusChanged(focused: Boolean, direction: Int, previous: Rect?) {
            super.onFocusChanged(focused, direction, previous)
            if (!focused) {
                pending = false; okDown = false; enterDown = false; typed = false
                // Moving to another field (Next) keeps the keyboard; anything else closes it.
                val token = windowToken
                rootView.post { if (rootView.findFocus()?.onCheckIsTextEditor() != true) imm.hideSoftInputFromWindow(token, 0) }
            }
        }
        // D-pad navigation measures the whole field like a row, not TextView's caret rect at its left edge.
        override fun getFocusedRect(r: Rect) = getDrawingRect(r)
        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            super.onWindowFocusChanged(hasWindowFocus)
            if (hasWindowFocus && pending) post(::show)
        }
        override fun onDetachedFromWindow() {
            pending = false
            if (isFocused) imm.hideSoftInputFromWindow(windowToken, 0)
            if (secret) text.clear()
            super.onDetachedFromWindow()
        }
    }
}

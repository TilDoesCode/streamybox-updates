package dev.streamybox.design

import java.util.Locale

object ControllerIdentity {
    enum class Brand { XBOX, PLAYSTATION, SWITCH, EIGHTBITDO, LOGITECH, GENERIC }
    data class Model(val brand: Brand, val name: String)
    fun model(vendor: Int, product: Int, name: String): Model = when (vendor) {
        0x045e -> Model(Brand.XBOX, if (product in setOf(0x0b13, 0x0b12)) "Xbox Series" else "Xbox Wireless Controller")
        0x054c -> Model(Brand.PLAYSTATION, if (product in setOf(0x0ce6, 0x0df2)) "DualSense" else "DualShock 4")
        0x057e -> Model(Brand.SWITCH, "Nintendo Switch Pro")
        0x2dc8 -> Model(Brand.EIGHTBITDO, name.ifBlank { "8BitDo" })
        0x046d -> Model(Brand.LOGITECH, name.ifBlank { "Logitech Gamepad" })
        else -> Model(Brand.GENERIC, name.ifBlank { "Gamepad" })
    }
    fun eligible(virtual: Boolean, gamepad: Boolean, joystick: Boolean, faceButtons: Boolean, directional: Boolean) =
        !virtual && (gamepad || joystick) && faceButtons && directional
    fun bluetoothCandidate(name: String?, deviceClass: Int?, appearance: Int? = null): Boolean {
        val n = name.orEmpty().lowercase(Locale.ROOT)
        val known = listOf("xbox", "dualsense", "dualshock", "wireless controller", "pro controller", "8bitdo", "gamepad", "game pad", "game controller").any(n::contains)
        val advertised = appearance == 0x03c4 || deviceClass?.and(0xffc) in setOf(0x504, 0x508)
        val otherPeripheral = listOf("headset", "headphone", "remote", "keyboard", "mouse").any(n::contains)
        return advertised || known && !otherPeripheral
    }
}

class PlayerSlots {
    private val slots = linkedMapOf<String, Int>()
    @Synchronized fun update(connected: List<String>): Map<String, Int> {
        slots.keys.retainAll(connected.toSet())
        connected.forEach { if (it !in slots) slots[it] = 0 }
        slots.keys.toList().forEach { key ->
            if (slots[key] == 0) slots[key] = (1..4).firstOrNull { it !in slots.values } ?: 0
        }
        return slots.toMap()
    }
}

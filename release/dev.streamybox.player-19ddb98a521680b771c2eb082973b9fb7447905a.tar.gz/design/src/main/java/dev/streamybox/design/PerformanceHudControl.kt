package dev.streamybox.design

import android.content.Context
import android.net.Uri

object PerformanceHudControl {
    private val uri = Uri.parse("content://dev.streamybox.settings.performance")
    fun enabled(context: Context) = context.contentResolver.call(uri, "state", null, null)?.getBoolean("enabled") == true
    fun set(context: Context, enabled: Boolean) {
        check(context.contentResolver.call(uri, "set", if (enabled) "1" else "0", null)?.getBoolean("ok") == true)
    }
}

package dev.streamybox.design

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable

class ControllerGlyph(private val color: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.7f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; this.color = this@ControllerGlyph.color }
    override fun draw(canvas: Canvas) {
        val save = canvas.save(); canvas.translate(bounds.left.toFloat(), bounds.top.toFloat()); canvas.scale(bounds.width() / 24f, bounds.height() / 24f)
        canvas.drawPath(Path().apply { moveTo(7f, 6f); lineTo(17f, 6f); cubicTo(21f, 6f, 23f, 17f, 20f, 19f); cubicTo(18f, 20f, 16f, 16f, 15f, 15f); lineTo(9f, 15f); cubicTo(8f, 16f, 6f, 20f, 4f, 19f); cubicTo(1f, 17f, 3f, 6f, 7f, 6f); close() }, paint)
        canvas.drawLine(5.5f, 10.5f, 10.5f, 10.5f, paint); canvas.drawLine(8f, 8f, 8f, 13f, paint)
        canvas.drawCircle(16f, 9f, .65f, paint); canvas.drawCircle(19f, 12f, .65f, paint); canvas.restoreToCount(save)
    }
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter }
    @Suppress("DEPRECATION") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

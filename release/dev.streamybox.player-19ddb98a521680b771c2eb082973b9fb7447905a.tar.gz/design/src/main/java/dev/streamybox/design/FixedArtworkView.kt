package dev.streamybox.design

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.widget.ImageView
import java.util.IdentityHashMap

class FixedArtworkView(context: Context) : ImageView(context) {
    private var replacing = false
    private val bitmaps = IdentityHashMap<Bitmap, BitmapDrawable>()
    override fun setImageDrawable(drawable: Drawable?) {
        replacing = isLaidOut && layoutParams?.let { it.width > 0 && it.height > 0 } == true
        try { super.setImageDrawable(drawable) } finally { replacing = false }
    }
    override fun setImageBitmap(bitmap: Bitmap?) {
        setImageDrawable(bitmap?.let { bitmaps[it] ?: BitmapDrawable(resources, it).also { drawable -> bitmaps[it] = drawable } })
    }
    override fun requestLayout() { if (!replacing) super.requestLayout() }
}

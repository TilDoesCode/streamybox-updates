package dev.streamybox.design

import android.content.Context
import dev.streamybox.remote.contract.RemoteWake
import android.hardware.input.InputManager

object ControllerWake {
    fun request(context: Context) {
        val input = context.getSystemService(InputManager::class.java)
        if (input.inputDeviceIds.none { ControllerMonitor.isController(input.getInputDevice(it)) }) return
        RemoteWake.wake(context)
    }
}

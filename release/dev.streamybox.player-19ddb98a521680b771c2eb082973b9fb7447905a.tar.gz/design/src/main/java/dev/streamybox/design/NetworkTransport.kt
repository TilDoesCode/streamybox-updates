package dev.streamybox.design

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** How the box is connected, for status glyphs: Ethernet wins over Wi-Fi when both are up. */
enum class NetworkTransport(val glyph: Glyph.Kind) {
    ETHERNET(Glyph.Kind.ETHERNET), WIFI(Glyph.Kind.WIFI), OTHER(Glyph.Kind.WIFI), OFFLINE(Glyph.Kind.OFFLINE);
    companion object {
        fun of(connected: Boolean, ethernet: Boolean, wifi: Boolean) = when {
            !connected -> OFFLINE
            ethernet -> ETHERNET
            wifi -> WIFI
            else -> OTHER
        }
        fun of(caps: NetworkCapabilities?) = of(caps != null, caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true, caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true)
        @SuppressLint("MissingPermission")
        fun current(context: Context): NetworkTransport {
            val cm = context.getSystemService(ConnectivityManager::class.java) ?: return OFFLINE
            return of(cm.getNetworkCapabilities(cm.activeNetwork))
        }
    }
}

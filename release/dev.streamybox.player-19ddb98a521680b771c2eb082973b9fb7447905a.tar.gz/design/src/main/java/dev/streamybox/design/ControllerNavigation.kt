package dev.streamybox.design

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.Window
import kotlin.math.abs

class ControllerNavigation(private val emit: (KeyEvent) -> Boolean) {
    private val handler = Handler(Looper.getMainLooper())
    private var direction = 0
    private var device = -1
    private var downTime = 0L
    private var repeats = 0
    private val repeat = object : Runnable {
        override fun run() {
            if (direction == 0 || !ControllerMonitor.isController(InputDevice.getDevice(device))) { reset(); return }
            send(KeyEvent.ACTION_DOWN, ++repeats)
            handler.postDelayed(this, ViewConfiguration.getKeyRepeatDelay().toLong())
        }
    }
    fun motion(event: MotionEvent): Boolean {
        if (!event.isFromSource(InputDevice.SOURCE_JOYSTICK) || !ControllerMonitor.isController(event.device)) return false
        if (event.action != MotionEvent.ACTION_MOVE) { reset(); return false }
        val x = axis(event, MotionEvent.AXIS_HAT_X).takeIf { abs(it) > .2f } ?: axis(event, MotionEvent.AXIS_X)
        val y = axis(event, MotionEvent.AXIS_HAT_Y).takeIf { abs(it) > .2f } ?: axis(event, MotionEvent.AXIS_Y)
        val next = StickDirection.key(x, y, direction != 0)
        if (next != direction || event.deviceId != device) {
            reset(); direction = next; device = event.deviceId; repeats = 0; downTime = SystemClock.uptimeMillis()
            if (direction != 0) { send(KeyEvent.ACTION_DOWN, 0); handler.postDelayed(repeat, ViewConfiguration.getKeyRepeatTimeout().toLong()) }
        }
        return true
    }
    private fun axis(e: MotionEvent, axis: Int): Float {
        val value = e.getAxisValue(axis)
        return if (abs(value) <= (e.device?.getMotionRange(axis, e.source)?.flat ?: 0f)) 0f else value
    }
    private fun send(action: Int, repeat: Int) = emit(KeyEvent(downTime, SystemClock.uptimeMillis(), action, direction, repeat, 0, device, 0, 0, InputDevice.SOURCE_DPAD))
    fun reset() { handler.removeCallbacks(repeat); if (direction != 0) send(KeyEvent.ACTION_UP, 0); direction = 0; device = -1 }
    companion object {
        fun mapped(event: KeyEvent): KeyEvent {
            if (!ControllerMonitor.isController(event.device)) return event
            val code = when (event.keyCode) {
                KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_DPAD_CENTER
                KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BACK
                KeyEvent.KEYCODE_BUTTON_START -> KeyEvent.KEYCODE_MENU
                else -> return event
            }
            return KeyEvent(event.downTime, event.eventTime, event.action, code, event.repeatCount, event.metaState, event.deviceId, event.scanCode, event.flags, event.source)
        }
        fun install(window: Window, tab: ((Int) -> Unit)? = null, menu: (() -> Unit)? = null) {
            val decor = window.decorView
            (decor.getTag(R.id.sb_controller_window) as? ControllerWindow)?.close()
            val original = window.callback ?: return
            if (original is ControllerWindow) return
            val controller = ControllerWindow(window, original, tab, menu)
            decor.setTag(R.id.sb_controller_window, controller)
            window.callback = controller
        }
        fun uninstall(window: Window) {
            (window.callback as? ControllerWindow)?.close()
        }
    }
    private class ControllerWindow(private val window: Window, private val original: Window.Callback, private val tab: ((Int) -> Unit)?, private val menu: (() -> Unit)?) : Window.Callback by original {
        private val decor = window.decorView
        private val navigation = ControllerNavigation { event ->
            if (original.dispatchKeyEvent(event)) true else {
                val direction = when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> View.FOCUS_LEFT; KeyEvent.KEYCODE_DPAD_RIGHT -> View.FOCUS_RIGHT
                    KeyEvent.KEYCODE_DPAD_UP -> View.FOCUS_UP; KeyEvent.KEYCODE_DPAD_DOWN -> View.FOCUS_DOWN
                    else -> 0
                }
                if (event.action == KeyEvent.ACTION_DOWN && direction != 0) window.decorView.findFocus()?.focusSearch(direction)?.requestFocus() ?: false else true
            }
        }
        private val attachment = object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) = Unit
            override fun onViewDetachedFromWindow(v: View) { navigation.reset() }
        }
        init { decor.addOnAttachStateChangeListener(attachment) }
        fun close() {
            navigation.reset()
            decor.removeOnAttachStateChangeListener(attachment)
            if (decor.getTag(R.id.sb_controller_window) === this) decor.setTag(R.id.sb_controller_window, null)
            if (window.callback === this) window.callback = original
        }
        override fun dispatchKeyEvent(event: KeyEvent): Boolean {
            if (ControllerMonitor.isController(event.device)) {
                val delta = when (event.keyCode) { KeyEvent.KEYCODE_BUTTON_L1 -> -1; KeyEvent.KEYCODE_BUTTON_R1 -> 1; else -> 0 }
                if (delta != 0 && tab != null) { if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) tab.invoke(delta); return true }
                if (event.keyCode == KeyEvent.KEYCODE_BUTTON_START && menu != null) { if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) menu.invoke(); return true }
            }
            return original.dispatchKeyEvent(mapped(event))
        }
        override fun dispatchGenericMotionEvent(event: MotionEvent) = navigation.motion(event) || original.dispatchGenericMotionEvent(event)
        override fun onWindowFocusChanged(hasFocus: Boolean) { if (!hasFocus) navigation.reset(); original.onWindowFocusChanged(hasFocus) }
    }
}

object StickDirection {
    fun key(x: Float, y: Float, active: Boolean): Int {
        if (maxOf(abs(x), abs(y)) < if (active) .18f else .30f) return 0
        return if (abs(x) >= abs(y)) { if (x < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT }
        else if (y < 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN
    }
}

package dev.streamybox.design

import android.graphics.*
import android.graphics.drawable.Drawable
import kotlin.math.abs

class AppIcon(val kind: Kind, private val ink: Int, private val letter: String = "", private val face: Typeface? = null, private val tone: Int = kind.hue, private val light: Boolean = false) : Drawable() {
    enum class Kind(val hue: Int) {
        YOUTUBE(0xFFE5484D.toInt()), JELLYFIN(0xFF8E63D8.toInt()), DIAGNOSTICS(0xFF7C6CF0.toInt()), BROWSER(0xFF4C8DF6.toInt()),
        FILES(0xFF3FA7E8.toInt()), SETTINGS(0xFF7F92B0.toInt()), SYSTEM(0xFF6A86AC.toInt()), WEB(0xFF2DB59C.toInt()),
        APPS(0xFF5D6E91.toInt()), BRAND(0xFF4FA8EE.toInt()), MEDIA(0xFFE07A45.toInt()), MUSIC(0xFFDB5C9D.toInt()),
        PHOTOS(0xFF34B27D.toInt()), KEYBOARD(0xFFC9A23F.toInt()), PROFILES(0xFF3FB6A8.toInt()), STORE(0xFF4CBF6B.toInt()), FAVORITES(0xFFE0A93A.toInt()), GENERIC(0xFF6C7A93.toInt())
    }
    companion object {
        private val palette = intArrayOf(0xFF5B8DEF.toInt(), 0xFF3FB6A8.toInt(), 0xFFD9824A.toInt(), 0xFFB667D6.toInt(), 0xFFD65B7A.toInt(), 0xFF6CA65A.toInt())
        fun kind(pkg: String): Kind = when {
            pkg == "org.smarttube.stable" || pkg.startsWith("com.liskovsoft") || pkg.startsWith("com.google.android.youtube") -> Kind.YOUTUBE
            pkg.startsWith("org.jellyfin") -> Kind.JELLYFIN
            pkg == "dev.streamybox.diag" -> Kind.DIAGNOSTICS
            pkg == "dev.streamybox.settings" -> Kind.SETTINGS
            pkg == "dev.streamybox.keyboard" -> Kind.KEYBOARD
            pkg == "dev.streamybox.profiles" -> Kind.PROFILES
            pkg == "dev.streamybox.store" -> Kind.STORE
            pkg.startsWith("dev.streamybox.launcher") -> Kind.BRAND
            pkg == "com.android.settings" || pkg == "com.android.tv.settings" -> Kind.SYSTEM
            pkg.contains("webview") -> Kind.WEB
            pkg == "com.android.documentsui" || pkg.contains("filemanager") || pkg.contains(".files") -> Kind.FILES
            pkg.contains("chrom") || pkg.contains("browser") || pkg.contains("firefox") -> Kind.BROWSER
            pkg == "dev.streamarr.app" -> Kind.MEDIA
            pkg.contains("kodi") || pkg.contains("vlc") || pkg.contains("plex") || pkg.contains("mpv") -> Kind.MEDIA
            pkg.contains("music") || pkg.contains("spotify") || pkg.contains("audio") -> Kind.MUSIC
            pkg.contains("photo") || pkg.contains("gallery") -> Kind.PHOTOS
            else -> Kind.GENERIC
        }
        fun tone(kind: Kind, pkg: String) = if (kind == Kind.GENERIC) palette[abs(pkg.hashCode() % palette.size)] else kind.hue
        fun media(kind: Kind) = kind in setOf(Kind.YOUTUBE, Kind.JELLYFIN, Kind.MEDIA, Kind.MUSIC, Kind.PHOTOS)
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val path = Path()
    private val oval = RectF()
    private fun lift(color: Int, amount: Float) = if (light) Ambience.mix(color, Color.BLACK, .08f) else Color.rgb(
        (Color.red(color) + (255 - Color.red(color)) * amount).toInt(), (Color.green(color) + (255 - Color.green(color)) * amount).toInt(), (Color.blue(color) + (255 - Color.blue(color)) * amount).toInt())
    private fun fill(color: Int) { paint.shader = null; paint.style = Paint.Style.FILL; paint.color = color }
    private fun stroke(color: Int, width: Float) { paint.shader = null; paint.style = Paint.Style.STROKE; paint.color = color; paint.strokeWidth = width }
    private fun poly(canvas: Canvas, close: Boolean, vararg p: Float) {
        path.reset(); path.moveTo(p[0], p[1]); var i = 2
        while (i < p.size) { path.lineTo(p[i], p[i + 1]); i += 2 }
        if (close) path.close(); canvas.drawPath(path, paint)
    }
    override fun draw(canvas: Canvas) {
        val box = bounds
        val unit = minOf(box.width(), box.height()) / 24f
        canvas.save()
        canvas.translate(box.exactCenterX() - 12 * unit, box.exactCenterY() - 12 * unit)
        canvas.scale(unit, unit)
        when (kind) {
            Kind.YOUTUBE -> { fill(tone); canvas.drawRoundRect(1.5f, 4.5f, 22.5f, 19.5f, 5.2f, 5.2f, paint); fill(Color.WHITE); poly(canvas, true, 9.8f, 8.6f, 15.8f, 12f, 9.8f, 15.4f) }
            Kind.JELLYFIN -> {
                stroke(Color.WHITE, 2.5f); paint.shader = LinearGradient(3f, 20f, 21f, 4f, 0xFFAA5CC3.toInt(), 0xFF00A4DC.toInt(), Shader.TileMode.CLAMP)
                poly(canvas, true, 12f, 3.8f, 20.8f, 19.4f, 3.2f, 19.4f)
                paint.style = Paint.Style.FILL; poly(canvas, true, 12f, 10.4f, 15.2f, 16.1f, 8.8f, 16.1f)
            }
            Kind.DIAGNOSTICS -> { stroke(lift(tone, .25f), 2.2f); poly(canvas, false, 2.5f, 12.5f, 7f, 12.5f, 9.5f, 6f, 14f, 18f, 16.5f, 12.5f, 21.5f, 12.5f) }
            Kind.BROWSER -> {
                stroke(lift(tone, .2f), 1.9f); canvas.drawCircle(12f, 12f, 9f, paint)
                oval.set(8f, 3f, 16f, 21f); canvas.drawOval(oval, paint); canvas.drawLine(3f, 12f, 21f, 12f, paint)
            }
            Kind.FILES -> { fill(Color.rgb(Color.red(tone) * 3 / 4, Color.green(tone) * 3 / 4, Color.blue(tone) * 3 / 4)); canvas.drawRoundRect(2.5f, 4.5f, 11.5f, 10f, 1.8f, 1.8f, paint); fill(lift(tone, .15f)); canvas.drawRoundRect(2.5f, 7.2f, 21.5f, 19.5f, 2.4f, 2.4f, paint) }
            Kind.SETTINGS -> {
                stroke(lift(tone, .45f), 2.1f); canvas.drawCircle(12f, 12f, 6.2f, paint); canvas.drawCircle(12f, 12f, 2.4f, paint)
                paint.strokeWidth = 3f
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0 + 22.5); val c = Math.cos(a).toFloat(); val s = Math.sin(a).toFloat()
                    canvas.drawLine(12f + 7.4f * c, 12f + 7.4f * s, 12f + 9.2f * c, 12f + 9.2f * s, paint)
                }
            }
            Kind.SYSTEM -> listOf(6.5f to 8.5f, 12f to 15.5f, 17.5f to 7f).forEach { (y, x) ->
                stroke(lift(tone, .35f), 2f); canvas.drawLine(3.5f, y, 20.5f, y, paint); fill(lift(tone, .35f)); canvas.drawCircle(x, y, 2.6f, paint)
            }
            Kind.WEB -> { stroke(lift(tone, .15f), 2.2f); poly(canvas, false, 8f, 6.5f, 2.8f, 12f, 8f, 17.5f); poly(canvas, false, 16f, 6.5f, 21.2f, 12f, 16f, 17.5f); canvas.drawLine(13.6f, 4.5f, 10.4f, 19.5f, paint) }
            Kind.APPS -> { fill(ink); listOf(3.5f to 3.5f, 13f to 3.5f, 3.5f to 13f, 13f to 13f).forEach { (x, y) -> canvas.drawRoundRect(x, y, x + 7.5f, y + 7.5f, 2.2f, 2.2f, paint) } }
            Kind.BRAND -> {
                stroke(lift(tone, .2f), 2.6f); oval.set(3.4f, 3.4f, 20.6f, 20.6f); canvas.drawArc(oval, 20f, 265f, false, paint)
                fill(lift(tone, .2f)); poly(canvas, true, 10.2f, 8.2f, 16.2f, 12f, 10.2f, 15.8f)
            }
            Kind.MEDIA -> { fill(tone); canvas.drawCircle(12f, 12f, 9.5f, paint); fill(Color.WHITE); poly(canvas, true, 10f, 8f, 16f, 12f, 10f, 16f) }
            Kind.MUSIC -> {
                stroke(lift(tone, .15f), 2.2f); poly(canvas, false, 9f, 17f, 9f, 5.5f, 19f, 3.8f, 19f, 15.5f)
                fill(lift(tone, .15f)); canvas.drawCircle(6.6f, 17.2f, 2.7f, paint); canvas.drawCircle(16.6f, 15.6f, 2.7f, paint)
            }
            Kind.PHOTOS -> { fill(tone); canvas.drawRoundRect(2.5f, 4.5f, 21.5f, 19.5f, 3f, 3f, paint); fill(Color.WHITE); poly(canvas, true, 5f, 17f, 10f, 11f, 13f, 14f, 15.5f, 11.5f, 19f, 17f); canvas.drawCircle(16f, 8.6f, 1.7f, paint) }
            Kind.KEYBOARD -> {
                stroke(lift(tone, .45f), 2f); canvas.drawRoundRect(2.5f, 6.5f, 21.5f, 17.5f, 2.6f, 2.6f, paint)
                fill(lift(tone, .45f)); for (x in floatArrayOf(6.5f, 9.25f, 12f, 14.75f, 17.5f)) canvas.drawRect(x - .85f, 9.45f, x + .85f, 11.15f, paint)
                stroke(lift(tone, .45f), 1.9f); canvas.drawLine(8.5f, 14.2f, 15.5f, 14.2f, paint)
            }
            Kind.PROFILES -> {
                stroke(lift(tone, .45f), 2.1f); canvas.drawCircle(12f, 8.4f, 3.6f, paint)
                path.reset(); path.moveTo(5f, 19.6f); path.cubicTo(5f, 15.6f, 8.2f, 13.9f, 12f, 13.9f); path.cubicTo(15.8f, 13.9f, 19f, 15.6f, 19f, 19.6f); canvas.drawPath(path, paint)
            }
            Kind.STORE -> {
                stroke(lift(tone, .45f), 2.1f)
                path.reset(); path.moveTo(7.4f, 8f); path.lineTo(16.6f, 8f); path.quadTo(18.2f, 8f, 18.2f, 9.4f); path.lineTo(19.6f, 18.2f); path.quadTo(19.8f, 20.6f, 17.4f, 20.6f)
                path.lineTo(6.6f, 20.6f); path.quadTo(4.2f, 20.6f, 4.4f, 18.2f); path.lineTo(5.8f, 9.4f); path.quadTo(5.8f, 8f, 7.4f, 8f); path.close(); canvas.drawPath(path, paint)
                oval.set(8.3f, 3.6f, 15.7f, 11f); canvas.drawArc(oval, 180f, 180f, false, paint); canvas.drawLine(8.3f, 7.3f, 8.3f, 8f, paint); canvas.drawLine(15.7f, 7.3f, 15.7f, 8f, paint)
                canvas.drawLine(12f, 11.2f, 12f, 16.9f, paint); poly(canvas, false, 9.5f, 14.4f, 12f, 16.9f, 14.5f, 14.4f)
            }
            Kind.FAVORITES -> {
                stroke(lift(tone, .3f), 2.1f)
                poly(canvas, true, *FloatArray(20) { i -> val a = Math.toRadians(-90.0 + (i / 2) * 36.0); val r = if ((i / 2) % 2 == 0) 9.4 else 4.1; (12 + r * if (i % 2 == 0) Math.cos(a) else Math.sin(a)).toFloat() + if (i % 2 == 1) .8f else 0f })
            }
            Kind.GENERIC -> {
                fill(tone); canvas.drawRoundRect(3f, 3f, 21f, 21f, 5.5f, 5.5f, paint)
                fill(Color.WHITE); paint.textSize = 10.5f; paint.textAlign = Paint.Align.CENTER; paint.typeface = face ?: Typeface.DEFAULT_BOLD
                canvas.drawText(letter, 12f, 12f - (paint.descent() + paint.ascent()) / 2, paint)
            }
        }
        canvas.restore()
    }
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(filter: ColorFilter?) { paint.colorFilter = filter }
    @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

object Ambience {
    fun mix(a: Int, b: Int, t: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(), (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(), (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())
    private fun shift(color: Int, degrees: Float) = FloatArray(3).also { Color.colorToHSV(color, it); it[0] = (it[0] + degrees + 360f) % 360f }.let { Color.HSVToColor(it) }
    private fun alpha(color: Int, value: Int) = Color.argb(value, Color.red(color), Color.green(color), Color.blue(color))
    fun render(hue: Int, light: Boolean, spot: Boolean, width: Int = 320, height: Int = 180): Bitmap {
        val base = mix(if (light) 0xFFF2F4F8.toInt() else 0xFF07090E.toInt(), hue, if (light) .07f else .09f)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap).apply { drawColor(base) }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        fun glow(x: Float, y: Float, r: Float, color: Int, a: Int) {
            val tint = if (light) mix(color, Color.WHITE, .35f) else color
            paint.shader = RadialGradient(x * width, y * height, r * width, intArrayOf(alpha(tint, a), alpha(tint, a * 2 / 5), alpha(tint, 0)), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        }
        glow(.74f, .46f, .6f, hue, if (light) 120 else 125)
        glow(1f, 0f, .42f, shift(hue, 32f), if (light) 80 else 80)
        glow(.38f, 1.05f, .5f, shift(hue, -36f), if (light) 55 else 55)
        if (spot) glow(.74f, .46f, .2f, mix(hue, Color.WHITE, .25f), if (light) 90 else 110)
        return bitmap
    }
}

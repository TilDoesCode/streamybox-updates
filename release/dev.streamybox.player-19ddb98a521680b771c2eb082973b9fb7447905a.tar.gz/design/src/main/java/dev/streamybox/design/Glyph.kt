package dev.streamybox.design

import android.graphics.*
import android.graphics.drawable.Drawable

class Glyph(private val kind: Kind, private var tint: Int) : Drawable() {
    enum class Kind { BRAND, WIFI, OFFLINE, GEAR, GRID, DISPLAY, SOUND, REMOTE, SYSTEM, APPEARANCE, INFO, CODE, CHEVRON, PLAY, HOME, ETHERNET, PROFILE }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val path = Path()
    private val oval = RectF()
    fun tint(color: Int) { if (tint != color) { tint = color; invalidateSelf() } }
    override fun draw(canvas: Canvas) {
        val box = bounds
        val unit = minOf(box.width(), box.height()) / 24f
        canvas.save()
        canvas.translate(box.exactCenterX() - 12 * unit, box.exactCenterY() - 12 * unit)
        canvas.scale(unit, unit)
        paint.color = tint; paint.style = Paint.Style.STROKE; paint.strokeWidth = if (kind == Kind.BRAND) 2.6f else 1.9f
        when (kind) {
            Kind.BRAND -> {
                arc(12f, 12f, 8.6f, 20f, 265f, canvas)
                fill(); path.reset(); path.moveTo(10.2f, 8.2f); path.lineTo(16.2f, 12f); path.lineTo(10.2f, 15.8f); path.close(); canvas.drawPath(path, paint)
            }
            Kind.ETHERNET -> {
                path.reset(); path.moveTo(4f, 6.5f); path.lineTo(20f, 6.5f); path.lineTo(20f, 15.5f); path.lineTo(16f, 15.5f); path.lineTo(16f, 18.5f); path.lineTo(8f, 18.5f); path.lineTo(8f, 15.5f); path.lineTo(4f, 15.5f); path.close(); canvas.drawPath(path, paint)
                listOf(9f, 12f, 15f).forEach { x -> canvas.drawLine(x, 9.6f, x, 11.4f, paint) }
            }
            Kind.WIFI, Kind.OFFLINE -> {
                listOf(3.6f, 7.6f, 11.6f).forEach { r -> arc(12f, 17.6f, r, 225f, 90f, canvas) }
                fill(); canvas.drawCircle(12f, 17.6f, 1.5f, paint)
                if (kind == Kind.OFFLINE) { stroke(); canvas.drawLine(4f, 4f, 20f, 20f, paint) }
            }
            Kind.GEAR -> {
                canvas.drawCircle(12f, 12f, 6.4f, paint); canvas.drawCircle(12f, 12f, 2.6f, paint)
                paint.strokeWidth = 2.8f
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    canvas.drawLine(12f + 7.6f * Math.cos(a).toFloat(), 12f + 7.6f * Math.sin(a).toFloat(), 12f + 9.6f * Math.cos(a).toFloat(), 12f + 9.6f * Math.sin(a).toFloat(), paint)
                }
            }
            Kind.GRID -> listOf(4f to 4f, 13.5f to 4f, 4f to 13.5f, 13.5f to 13.5f).forEach { (x, y) -> canvas.drawRoundRect(x, y, x + 6.5f, y + 6.5f, 2f, 2f, paint) }
            Kind.DISPLAY -> { canvas.drawRoundRect(3f, 4.5f, 21f, 16f, 2.2f, 2.2f, paint); canvas.drawLine(8.5f, 20f, 15.5f, 20f, paint); canvas.drawLine(12f, 16f, 12f, 20f, paint) }
            Kind.SOUND -> {
                path.reset(); path.moveTo(3.5f, 9.5f); path.lineTo(7.5f, 9.5f); path.lineTo(12f, 5.5f); path.lineTo(12f, 18.5f); path.lineTo(7.5f, 14.5f); path.lineTo(3.5f, 14.5f); path.close(); canvas.drawPath(path, paint)
                arc(12f, 12f, 4f, -45f, 90f, canvas); arc(12f, 12f, 7.8f, -45f, 90f, canvas)
            }
            Kind.REMOTE -> {
                canvas.drawRoundRect(7.5f, 2.5f, 16.5f, 21.5f, 3.5f, 3.5f, paint); canvas.drawCircle(12f, 8f, 2.2f, paint)
                fill(); canvas.drawCircle(12f, 14f, 1.1f, paint); canvas.drawCircle(12f, 17.5f, 1.1f, paint)
            }
            Kind.SYSTEM -> listOf(6f to 9f, 12f to 15f, 18f to 7f).forEach { (y, x) ->
                stroke(); canvas.drawLine(4f, y, 20f, y, paint); fill(); canvas.drawCircle(x, y, 2.3f, paint)
            }
            Kind.APPEARANCE -> { canvas.drawCircle(12f, 12f, 8.5f, paint); fill(); oval.set(3.5f, 3.5f, 20.5f, 20.5f); canvas.drawArc(oval, 90f, 180f, true, paint) }
            Kind.INFO -> { canvas.drawCircle(12f, 12f, 9f, paint); canvas.drawLine(12f, 11f, 12f, 16.5f, paint); fill(); canvas.drawCircle(12f, 7.8f, 1.2f, paint) }
            Kind.CODE -> { line(8f, 7f, 3.5f, 12f, 8f, 17f, canvas); line(16f, 7f, 20.5f, 12f, 16f, 17f, canvas); canvas.drawLine(13.5f, 5f, 10.5f, 19f, paint) }
            Kind.CHEVRON -> line(9.5f, 6f, 15.5f, 12f, 9.5f, 18f, canvas)
            Kind.PLAY -> { fill(); path.reset(); path.moveTo(7.5f, 5f); path.lineTo(19f, 12f); path.lineTo(7.5f, 19f); path.close(); canvas.drawPath(path, paint) }
            Kind.PROFILE -> { canvas.drawCircle(12f, 8.4f, 3.9f, paint); arc(12f, 21.5f, 7.6f, 200f, 140f, canvas) }
            Kind.HOME -> { line(3.5f, 11.5f, 12f, 4f, 20.5f, 11.5f, canvas); canvas.drawRoundRect(6f, 10f, 18f, 20f, 2f, 2f, paint) }
        }
        canvas.restore()
    }
    private fun fill() { paint.style = Paint.Style.FILL }
    private fun stroke() { paint.style = Paint.Style.STROKE }
    private fun arc(x: Float, y: Float, r: Float, start: Float, sweep: Float, canvas: Canvas) {
        oval.set(x - r, y - r, x + r, y + r); canvas.drawArc(oval, start, sweep, false, paint)
    }
    private fun line(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, canvas: Canvas) {
        path.reset(); path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(x3, y3); canvas.drawPath(path, paint)
    }
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(filter: ColorFilter?) { paint.colorFilter = filter }
    @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

class SwitchDrawable(val on: Boolean, private val track: Int, private val thumb: Int, private val offTrack: Int = track, private val offThumb: Int = thumb) : Drawable(), android.animation.ValueAnimator.AnimatorUpdateListener {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var progress = if (on) 1f else 0f
    override fun draw(canvas: Canvas) {
        val b = bounds; val r = b.height() / 2f
        paint.color = Ambience.mix(offTrack, track, progress); canvas.drawRoundRect(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), r, r, paint)
        paint.color = Ambience.mix(offThumb, thumb, progress); canvas.drawCircle(b.left + r + (b.width() - 2 * r) * progress, b.exactCenterY(), r * .72f, paint)
    }
    /** Slides the thumb from the opposite state into the current one. */
    fun flip() {
        if (!Motion.animated) return
        android.animation.ValueAnimator.ofFloat(0f, 1f).apply { duration = Motion.STANDARD; interpolator = Motion.standard; addUpdateListener(this@SwitchDrawable) }.start()
    }
    override fun onAnimationUpdate(animation: android.animation.ValueAnimator) { val f = animation.animatedFraction; progress = if (on) f else 1f - f; invalidateSelf() }
    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(filter: ColorFilter?) { paint.colorFilter = filter }
    @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

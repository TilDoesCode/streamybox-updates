package dev.streamybox.design

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable

/** An app's own launcher icon in the tile language: adaptive layers under a rounded-square mask, legacy icons clipped to it. */
class PackageIcon(private val source: Drawable) : Drawable() {
    private val mask = Path()
    private val layer = Rect()
    override fun onBoundsChange(bounds: Rect) {
        mask.reset()
        val r = bounds.width() * .24f
        mask.addRoundRect(bounds.left.toFloat(), bounds.top.toFloat(), bounds.right.toFloat(), bounds.bottom.toFloat(), r, r, Path.Direction.CW)
        if (source is AdaptiveIconDrawable) {
            val inset = bounds.width() / 4
            layer.set(bounds.left - inset, bounds.top - inset, bounds.right + inset, bounds.bottom + inset)
            source.background?.bounds = layer; source.foreground?.bounds = layer
        } else source.bounds = bounds
    }
    override fun draw(canvas: Canvas) {
        val save = canvas.save(); canvas.clipPath(mask)
        if (source is AdaptiveIconDrawable) { source.background?.draw(canvas); source.foreground?.draw(canvas) } else source.draw(canvas)
        canvas.restoreToCount(save)
    }
    override fun setAlpha(alpha: Int) { source.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { source.colorFilter = colorFilter }
    @Suppress("DEPRECATION") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

package dev.streamybox.design

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable

/** Filled gamepad silhouette on the 24-unit status grid (height = 24 units) with an optional knocked-out count badge. */
class ControllerStatusGlyph(private val tint: Int, private val badgeFill: Int, private val badgeInk: Int, face: Typeface? = null) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = face ?: Typeface.DEFAULT_BOLD }
    private val clear = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    private val body = Path().apply {
        fillType = Path.FillType.EVEN_ODD
        moveTo(7.2f, 6.6f); quadTo(12f, 7.7f, 16.8f, 6.6f)
        cubicTo(19.6f, 6.6f, 21.1f, 8.6f, 21.8f, 12.2f); cubicTo(22.4f, 15.4f, 22.3f, 18.6f, 20.2f, 18.9f)
        cubicTo(18.6f, 19.1f, 17.5f, 17.2f, 16.4f, 15.8f); quadTo(16f, 15.3f, 15.3f, 15.3f); lineTo(8.7f, 15.3f)
        quadTo(8f, 15.3f, 7.6f, 15.8f); cubicTo(6.5f, 17.2f, 5.4f, 19.1f, 3.8f, 18.9f)
        cubicTo(1.7f, 18.6f, 1.6f, 15.4f, 2.2f, 12.2f); cubicTo(2.9f, 8.6f, 4.4f, 6.6f, 7.2f, 6.6f); close()
        val x = 7.3f; val y = 10.9f; val a = .85f; val l = 2.3f
        moveTo(x - a, y - l); lineTo(x + a, y - l); lineTo(x + a, y - a); lineTo(x + l, y - a); lineTo(x + l, y + a); lineTo(x + a, y + a)
        lineTo(x + a, y + l); lineTo(x - a, y + l); lineTo(x - a, y + a); lineTo(x - l, y + a); lineTo(x - l, y - a); lineTo(x - a, y - a); close()
        listOf(16.7f to 9.1f, 18.5f to 10.9f, 14.9f to 10.9f, 16.7f to 12.7f).forEach { (cx, cy) -> addCircle(cx, cy, .82f, Path.Direction.CW) }
    }
    private val oval = RectF()
    var count = ""; set(value) { if (field != value) { field = value; invalidateSelf() } }
    var low = false; set(value) { if (field != value) { field = value; invalidateSelf() } }
    val badged get() = count.isNotEmpty()
    override fun draw(canvas: Canvas) {
        val unit = bounds.height() / 24f
        val layer = canvas.saveLayer(bounds.left.toFloat(), bounds.top.toFloat(), bounds.right.toFloat(), bounds.bottom.toFloat(), null)
        canvas.translate(bounds.left.toFloat(), bounds.top.toFloat()); canvas.scale(unit, unit)
        canvas.save(); canvas.translate(3f, 6.6f); canvas.scale(17f / 20.6f, 11.4f / 12.5f); canvas.translate(-1.9f, -6.6f)
        paint.color = tint; canvas.drawPath(body, paint); canvas.restore()
        if (badged) {
            canvas.drawCircle(19.2f, 6.2f, 6.3f, clear)
            paint.color = if (low) LOW else badgeFill; canvas.drawCircle(19.2f, 6.2f, 4.8f, paint)
            text.color = badgeInk; text.textSize = 6.8f
            canvas.drawText(count, 19.2f, 6.2f - (text.descent() + text.ascent()) / 2, text)
        }
        canvas.restoreToCount(layer)
    }
    override fun setAlpha(alpha: Int) { paint.alpha = alpha; text.alpha = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter }
    @Suppress("DEPRECATION") override fun getOpacity() = PixelFormat.TRANSLUCENT
    companion object { const val LOW = 0xFFE9A23B.toInt() }
}

# Shared TV design

Native Android library consumed by launcher and settings. `TvDesign` owns the dark/light
tokens (colours, radii, spacing, type scale), the bundled Inter variable font, the screen
backdrop, focus treatment (ring in `foreground`, tinted elevation glow, 1.025–1.08 scale,
180 ms `View` property animation, no per-frame blur), list items with value chips,
switches and chevrons, grouped cards and section headers, rail pills, tab pills, keys and
choice dialogs. `Glyph` draws the line icons and brand mark in code. `TextField` is the inline text row
(label, plain `EditText`, reason line) that lives on the page itself, styled and grouped like `item`: OK opens
the system IME `:keyboard` (`../keyboard`) once, its action key submits (`onSubmit`, `check` → reason under the
field), Back first hides the keyboard, secrets clear when the row leaves the window. Text entry never opens a
dialog; pages add an explicit action row next to the field (see `docs/14-keyboard.md`).
`SharedState` communicates with the launcher's signature-protected state provider.

Inter is © The Inter Project Authors, SIL OFL 1.1 (`src/main/assets/fonts/Inter-OFL.txt`).

Build via the Gradle project in `../launcher`. GPL-3.0; see [LICENSE](../launcher/LICENSE).

## Motion

`Motion` (in `Motion.kt`) is the single source for timing; global Android scales stay at 1.0
(`scripts/tv-setup.sh`) so the tokens are exact.

| Token | ms | Use |
|---|---|---|
| `MICRO` | 100 | press dip (half), keyboard relayout |
| `FOCUS` | 170 | focus scale/lift, ring and fill crossfade, value pops |
| `STANDARD` | 240 | content enter, stage crossfade, page slides, switch thumb |
| `EMPHASIZED` | 380 | hero backdrop crossfade, dialog scale-in, return-home landing, scroll spring settle |
| `EXIT` | 150 | anything leaving (dialogs, hero text out, settings page ghost) |
| `FOCUS_OUT` | 70 | ring/fill fade on focus loss (no trails during key repeat) |
| `STAGGER` / `STAGGER_MAX` | 18 / 220 | grid entry cascade per diagonal step / cap |
| `SETTLE` | 90 | debounce before the hero follows focus |

Easing (no bounce, no overshoot): `decelerate` (0.05, 0.7, 0.1, 1) for things arriving and
focus gain, `standard` (0.2, 0, 0, 1) for moves/crossfades and focus loss, `accelerate`
(0.3, 0, 0.8, 0.15) for exits. Matching XML interpolators live in `res/interpolator`.

Helpers: `Motion.enter` (fade + optional slide with a hardware layer), `Motion.swap`
(out → change → in, superseded by newer swaps), `Motion.replace` (true crossfade: the old view fades out in the host overlay while its replacement enters; one ghost per slot), `Motion.dialog` (window animations
`SbMotionScrim`: the full-screen modal window fades in 240 ms / out 150 ms; `TvDesign.present` draws
the `scrim()` backdrop and scales the card 0.96 → 1 at full motion), `Glide` (critically damped
spring for scroll offsets: retargets mid-flight keeping velocity, never overshoots, no
per-frame allocations) with `GlideHorizontalScrollView` / `GlideScrollView` (focus changes
never jump; vertical follows focus with a 1/8 margin). `TvDesign.focus` retargets
scale/lift from the current value and skips views already heading there; ring/fill use
`StateListDrawable` fades, so only `focused`/`selected` state changes. `TvDesign.press`
gives the click dip. `SwitchDrawable.flip` slides the thumb and blends the track colour.

Levels (`Motion.preference`, Settings › Appearance › Motion, stored in the launcher state
provider as `motion`): **Full**; **Reduced** – fades only, no slides/scale-ins/staggers/press
dips, durations ×0.75, focus scale kept as the focus cue; **Off** – everything instant,
no window animations. Android's "remove animations" (animator scale 0) forces Off.

Rules: animate only `alpha`/`translation`/`scale`/`translationZ` (no relayout), use
`withLayer()` for multi-child views, never queue — every new target cancels or retargets
the running animation, and the hero only updates after `SETTLE` without a new key.

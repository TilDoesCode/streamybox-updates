#!/usr/bin/env python3
"""Renders the generated app icons and banners to PNG for review: preview.py <out-dir> [module ...] (needs Google Chrome)."""
import pathlib, subprocess, sys, tempfile, xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[2]
A = '{http://schemas.android.com/apk/res/android}'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
MODULES = {'launcher/app': 'launcher', 'settings': 'settings', 'test-app/app': 'diagnostics', 'keyboard': 'keyboard', 'profiles': 'profiles', 'store': 'store'}

def color(value):
    v = value.lstrip('#')
    if len(v) == 6: v = 'FF' + v
    return f'rgba({int(v[2:4], 16)},{int(v[4:6], 16)},{int(v[6:8], 16)},{int(v[0:2], 16) / 255:.3f})'

def svg_body(path, prefix):
    root, defs, out = ET.parse(path).getroot(), [], []
    def walk(node):
        for child in node:
            tag = child.tag.split('}')[-1]
            if tag == 'group':
                g = child.attrib
                out.append(f'<g transform="translate({g.get(A + "translateX", 0)} {g.get(A + "translateY", 0)}) scale({g.get(A + "scaleX", 1)} {g.get(A + "scaleY", 1)})">'); walk(child); out.append('</g>')
            elif tag == 'path':
                a, fill = child.attrib, child.get(A + 'fillColor', '#00000000')
                for attr in child.iter('{http://schemas.android.com/aapt}attr'):
                    grad = attr.find('gradient').attrib; gid = f'{prefix}g{len(defs)}'
                    stops = f'<stop offset="0" stop-color="{color(grad[A + "startColor"])}"/><stop offset="1" stop-color="{color(grad[A + "endColor"])}"/>'
                    if grad[A + 'type'] == 'radial': defs.append(f'<radialGradient id="{gid}" gradientUnits="userSpaceOnUse" cx="{grad[A + "centerX"]}" cy="{grad[A + "centerY"]}" r="{grad[A + "gradientRadius"]}">{stops}</radialGradient>')
                    else: defs.append(f'<linearGradient id="{gid}" gradientUnits="userSpaceOnUse" x1="{grad[A + "startX"]}" y1="{grad[A + "startY"]}" x2="{grad[A + "endX"]}" y2="{grad[A + "endY"]}">{stops}</linearGradient>')
                    fill = f'url(#{gid})'
                stroke = a.get(A + 'strokeColor')
                s = f' stroke="{color(stroke)}" stroke-width="{a.get(A + "strokeWidth", 1)}" stroke-linecap="{a.get(A + "strokeLineCap", "butt")}" stroke-linejoin="{a.get(A + "strokeLineJoin", "miter")}"' if stroke else ''
                out.append(f'<path d="{a[A + "pathData"]}" fill="{fill if fill.startswith("url") else color(fill)}"{s}/>')
    walk(root)
    return root.get(A + 'viewportWidth'), root.get(A + 'viewportHeight'), f'<defs>{"".join(defs)}</defs>' + ''.join(out)

def icon(module, size, shape='square', mono=False):
    res = ROOT / module / 'src/main/res/drawable'
    _, _, bg = svg_body(res / 'sb_app_icon_bg.xml', f'{module.replace("/", "")}{size}b')
    _, _, fg = svg_body(res / ('sb_app_icon_mono.xml' if mono else 'sb_app_icon_fg.xml'), f'{module.replace("/", "")}{size}f')
    clip = '<circle cx="54" cy="54" r="36"/>' if shape == 'circle' else '<rect x="18" y="18" width="72" height="72" rx="17.28"/>'
    cid = f'c{module.replace("/", "")}{size}{shape}{mono}'
    base = '<rect width="108" height="108" fill="#3A4558"/>' if mono else bg
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="18 18 72 72"><clipPath id="{cid}">{clip}</clipPath><g clip-path="url(#{cid})">{base}{fg}</g></svg>'

def banner(module, width, locale=''):
    w, h, body = svg_body(ROOT / module / f'src/main/res/drawable{locale}/sb_app_banner.xml', f'{module.replace("/", "")}{width}{locale}')
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{width * 9 // 16}" viewBox="0 0 {w} {h}" style="border-radius:{width // 22}px">{body}</svg>'

def shoot(html, out, width, height):
    with tempfile.NamedTemporaryFile('w', suffix='.html', delete=False) as f: f.write(html)
    subprocess.run([CHROME, '--headless', '--disable-gpu', '--hide-scrollbars', '--default-background-color=00000000', f'--window-size={width},{height}', f'--screenshot={out}', f'file://{f.name}'], check=True, capture_output=True)

if __name__ == '__main__':
    out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
    page = '<html><body style="margin:0">{}</body></html>'
    for module in sys.argv[2:] or ['store']:
        name = MODULES[module]
        shoot(page.format(icon(module, 512)), out / f'{name}-icon-512.png', 512, 512)
        shoot(page.format(icon(module, 512, 'circle')), out / f'{name}-icon-512-circle.png', 512, 512)
        shoot(page.format(banner(module, 640)), out / f'{name}-banner-640.png', 640, 360)
    row = lambda bg, items: f'<div style="display:flex;gap:28px;align-items:center;padding:28px;background:{bg}">{"".join(items)}</div>'
    family = [m for m in MODULES]
    sheet = row('#07090E', [icon(m, 96) for m in family]) + row('#07090E', [icon(m, 48) for m in family]) + row('#EEF1F5', [icon(m, 96) for m in family]) + row('#EEF1F5', [icon(m, 48, 'circle') for m in family])
    sheet += row('#07090E', [icon(m, 48, mono=True) for m in family]) + row('#07090E', [banner(m, 240) for m in family[:3]]) + row('#07090E', [banner(m, 240) for m in family[3:]])
    shoot(page.format(sheet), out / 'family-sheet.png', 1000, 860)
    print('wrote', out)

# Player native core — corresponding source

Result licence: **GPL-3.0-or-later**
(FFmpeg is built with --enable-gpl --enable-version3 (GPL-3.0-or-later) and linked into mpv (GPL-2.0-or-later). The combined libmpv.so and the APK that ships it are GPL-3.0-or-later; all other libraries are compatible.)

Toolchain: NDK 27.1.12297006, min API 23,
16384-byte pages, ABI arm64-v8a, build script `device/rock4d/player/native/build.sh`
(upstream copy: `tools/dv-mpv/build.sh`).

## Git checkouts (in `third_party/` as `<name>-<commit12>.tar.gz`)

| Component | Pin | Licence | Upstream | $SB_WORK path | Role |
| --- | --- | --- | --- | --- | --- |
| mpv | 0.41.0-dev `ad5877edabdb05c0c62aad444722938d37666e2d` | GPL-2.0-or-later | https://github.com/mpv-player/mpv | `src/mpv` | libmpv (cplayer disabled), vo=gpu-next |
| libplacebo | v7.387.0 `275f7dea27924cdd34ab2e6c20e448b6bc4fab65` | LGPL-2.1-or-later | https://github.com/haasn/libplacebo | `src/libplacebo` | DV display management and tone mapping |
| FFmpeg | n9.0-dev (libavcodec 63.25.101) `16efe6927d850d23766aee15820abedcb1219121` | GPL-3.0-or-later | https://github.com/FFmpeg/FFmpeg | `src/ffmpeg` | demux/decode, hevc_mediacodec DV RPU, spdif (IEC 61937) muxer for audio passthrough |
| mpv-android | 2026-09-17-release (versionCode 48) `3cc4665ed1a38fcaa10b7f400219f21d022d06e9` | MIT | https://github.com/mpv-android/mpv-android | `src/mpv-android` | cross-build scripts and dependency pins (buildscripts/include/depinfo.sh) |
| libass | `f61db567e6593df3470e91594bcd4ad2d0473aff` | ISC | https://github.com/libass/libass | `dv-mpv/src/mpv-android/buildscripts/deps/libass` | subtitle rendering |
| dav1d | `c6f51c881d80b43830b7c1fff2ba0d48599e8073` | BSD-2-Clause | https://code.videolan.org/videolan/dav1d | `dv-mpv/src/mpv-android/buildscripts/deps/dav1d` | AV1 decoding |
| freetype2 | VER-2-15-0 `37515cf56ba3349656049edbed89ffc6f6466f2d` | FTL OR GPL-2.0-or-later | https://gitlab.freedesktop.org/freetype/freetype | `dv-mpv/src/mpv-android/buildscripts/deps/freetype2` | font rasterisation |
| fast_float | `97b54ca9e75f5303507699d27c6b4f4efe4641a1` | Apache-2.0 OR MIT | https://github.com/fastfloat/fast_float | `src/libplacebo/3rdparty/fast_float` | libplacebo submodule (required, not optional) |
| glad | `73db193f853e2ee079bf3ca8a64aa2eaf6459043` | MIT OR Apache-2.0 | https://github.com/Dav1dde/glad | `src/libplacebo/3rdparty/glad` | libplacebo submodule (required, not optional) |
| jinja | `15206881c006c79667fe5154fe80c01c65410679` | BSD-3-Clause | https://github.com/pallets/jinja | `src/libplacebo/3rdparty/jinja` | libplacebo submodule (build-time code generation) |
| markupsafe | `297fc8e356e6836a62087949245d09a28e9f1b13` | BSD-3-Clause | https://github.com/pallets/markupsafe | `src/libplacebo/3rdparty/markupsafe` | libplacebo submodule (build-time code generation) |

## Release tarballs (in `third_party/` unchanged, sha256 pinned)

| Component | Version | Licence | Upstream | Archive |
| --- | --- | --- | --- | --- |
| fontconfig | 2.18.3 | MIT | https://gitlab.freedesktop.org/fontconfig/fontconfig/-/archive/2.18.3/fontconfig-2.18.3.tar.gz | `fontconfig-2.18.3.tar.gz` |
| fribidi | 1.0.17 | LGPL-2.1-or-later | https://github.com/fribidi/fribidi/releases/download/v1.0.17/fribidi-1.0.17.tar.xz | `fribidi-1.0.17.tar.xz` |
| harfbuzz | 14.6.0 | MIT | https://github.com/harfbuzz/harfbuzz/releases/download/14.6.0/harfbuzz-14.6.0.tar.xz | `harfbuzz-14.6.0.tar.xz` |
| libunibreak | 8.0 | Zlib | https://github.com/adah1972/libunibreak/releases/download/libunibreak_8_0/libunibreak-8.0.tar.gz | `libunibreak-8.0.tar.gz` |
| libxml2 | 2.15.4 | MIT | https://gitlab.gnome.org/GNOME/libxml2/-/archive/v2.15.4/libxml2-v2.15.4.tar.gz | `libxml2-v2.15.4.tar.gz` |
| Lua | 5.2.4 | MIT | https://www.lua.org/ftp/lua-5.2.4.tar.gz | `lua-5.2.4.tar.gz` |
| curl | 8.23.0 | curl | https://curl.se/download/curl-8.23.0.tar.gz | `curl-8.23.0.tar.gz` |
| Mbed TLS | 3.6.7 | Apache-2.0 OR GPL-2.0-or-later | https://github.com/Mbed-TLS/mbedtls/releases/download/mbedtls-3.6.7/mbedtls-3.6.7.tar.bz2 | `mbedtls-3.6.7.tar.bz2` |

## Patches (in `third_party/patches/`, applied in this order)

| Patch | Target | sha256 | Change |
| --- | --- | --- | --- |
| `0001-android-hdr10-egl-surface.patch` | mpv `ad5877edabdb` | `890d7e7adb9820c4a814b0781e6897ebd5adaff254e9a0f114816700637f2ff3` | 10-bit EGL surface (BT2020_PQ), ANativeWindow_setBuffersDataSpace, preferred_csp, --android-hdr |
| `0002-ao-audiotrack-iec61937-hbr.patch` | mpv `ad5877edabdb` | `1437b0b85f75834f991a1d60a593db71ec9c9d1bae2d1337e51b427925acab06` | audiotrack AO: IEC 61937 keeps the bitstream rate (192 kHz for E-AC-3/TrueHD/DTS-HD) and opens 8-channel (7.1) tracks for high bit rate formats |
| `0001-libavcodec-mediacodec-attach-DOVI-RPU-metadata.patch` | FFmpeg `16efe6927d85` | `7f77bef7d84f3b3b898c4fc2826461206196c8f6c711e30c8f64e110ac34d136` | MediaCodec decoder attaches AV_FRAME_DATA_DOVI_METADATA from HEVC NAL 62, PTS-matched (from feat/dv-ffmpeg) |
| `0001-local-build-tweaks.patch` | mpv-android `3cc4665ed1a3` | `c1c4e06357dc2e3436a16c0b3a8292f751ce8aa0e39364d7fa48e8766b551794` | NDK r27.1 pin, Gradle --no-configuration-cache |
| `0002-ffmpeg-enable-spdif-muxer.patch` | mpv-android `3cc4665ed1a3` | `19f90644763e3d0dbfc477048b1e167fc4bab3e6c1b5f77c2dcf25958922bdc4` | FFmpeg configure: --enable-muxer=spdif (mpv ad_spdif needs it for passthrough) |

The pinned versions of the release tarballs are selected by
`tools/dv-mpv/build.sh` via mpv-android
`buildscripts/include/depinfo.sh`. Unpack every archive into the `$SB_WORK` path above, apply the patches to the
checkouts, then run the build script. The APK embeds `libmpv.so` plus FFmpeg's shared libraries from this build;
`scripts/lib/source-archive.py` and this file name the exact bytes.

## FFmpeg configuration

```
--target-os=android --enable-cross-compile --cross-prefix=aarch64-linux-android- --arch=aarch64 --cpu=armv8-a --enable-jni --enable-mediacodec --enable-mbedtls --enable-libdav1d --enable-libxml2 --disable-vulkan --disable-static --enable-shared --enable-gpl --enable-version3 --disable-stripping --disable-doc --disable-programs --disable-muxers --disable-encoders --disable-devices --enable-encoder=mjpeg,png --enable-muxer=mov,matroska,mpegts,spdif
```
